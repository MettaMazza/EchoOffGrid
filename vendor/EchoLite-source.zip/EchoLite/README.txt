EchoLite

EchoLite is a persistent local cognitive agent built in Ernos Plain. The native
chat UI, conversation controller, layered memory, embedding recall, editable Me
identity, tool adapters and storage recovery use EP. Model inference uses the
installed native llama.cpp runtime; offline Wikipedia uses native Kiwix.

Start on this Mac

Double-click EchoLite.app, or from the project directory run:
  ./echolite

This opens the dark chat interface with pastel green accents. The runtime
manager starts or reuses the local generation, embedding and Wikipedia services.
Thinking is streamed into a collapsible section; answers stream as drafts before
being saved. Memory and Me views are available from the sidebar.

Network mode is persistent and defaults to Offline. The top-right badge shows
what this launch is using. To allow web access, close the UI and run:
  ./echolite network-mode connected
  ./echolite
To return to offline operation:
  ./echolite network-mode offline
Read the saved/active selection with ./echolite network-mode. Relaunch an open
UI after changing it. The setting lives in the selected ECHOLITE_HOME; a valid
ECHOLITE_NETWORK_MODE environment value can override it for a launch.

Offline launches block direct external network connections from the app and
its child commands through macOS sandbox-exec. Localhost remains available for
local model, embeddings and Wikipedia services. Stored web snapshots can still
be read, including expired copies; receipts disclose their age/staleness and
never claim they were refreshed offline. Uncached URLs return an offline error.
This is an application launch policy, not a machine-wide firewall: unrelated
apps and services are not disabled. Use the app icon or ./echolite entry point
to apply the policy; raw internal binaries are development interfaces.

For the command interface:

  ./echolite init
  ./echolite chat EchoLite "Use the calculator to calculate 43*17."
  ./echolite help

No separate Python worker or second Terminal window is needed for this native
path. Calling ./echolite without arguments opens chat; ./echolite ui explicitly
selects it. Existing command arguments are forwarded directly without a shell.

Build

With the installed Ernos compiler and standard library available:
  ./build
or:
  ./echolite build

The builder itself is EP. It compiles the core, runtime manager, UI, launcher,
isolated PDF/DOCX/image readers and command supervisor.
For a fresh checkout, bootstrap the builder once from the project directory:
  ~/.local/bin/ernos src/build.ep
  ./src/build

The bootstrap installs bin/echolite-build for subsequent ./build invocations.
ERNOS_COMPILER can select another installed compiler executable. The repository's
stdlib link must point to that compiler's standard library. Binaries, generated
compiler C, model/reference downloads and private state are excluded from Git.
The build uses installed local dependencies; it does not download models.

Local state and models

Default state is data/memory.sqlite3 with a projected data/Me.txt. ECHOLITE_HOME
selects another state directory; the launcher creates missing directories with
private defaults. The shared runtime credential defaults to data/native-runtime.token
at the installation root; ECHOLITE_NATIVE_TOKEN_FILE overrides it.

The native generation runtime is configured for Qwen3.5-4B Q4_K_M and a 262144-token
context. MiniLM provides semantic embeddings. Native runtime, model and library
versions are recorded in config/native-*.json. The installed Wikipedia snapshot
is month-dated 2026-06; citations preserve that precision.

ECHOLITE_MAX_OUTPUT_TOKENS defaults to 8192 (128..32768 accepted).
ECHOLITE_REASONING_BUDGET defaults to -1, with no separate thinking cap; a finite
budget must leave at least 128 output tokens for the answer/action. Thinking and
answer share the total output allowance, which is separate from context capacity.

Local image attachments

  ./echolite image-import EchoLite /absolute/photo.png
  ./echolite images EchoLite
  ./echolite chat-image EchoLite IMAGE_ID "Describe this image."

The import returns a memory ID. PNG, JPEG and HEIC still images are normalized
locally in an isolated native reader. Stored image bytes survive source-file
changes and application restarts. Reimporting identical content reuses cached
normalization. Image metadata is searchable; encoded pixels are kept separately.
Forgetting its memory ID also deletes the retained image and dependent turns.
chat-image supplies the retained pixels to the local vision model, preserves
source attribution and records the image-to-answer dependency. In chat, choose
+ Attach image, select a still image, optionally enter a question, then send.
The selected filename appears above the composer; x removes it before sending.
Sending an image without text asks EchoLite to describe it. Saved conversations
retain an image label beside the user message.

Memory and identity

  ./echolite remember semantic EchoLite user "I prefer concise answers."
  ./echolite recall EchoLite "answers"
  ./echolite context EchoLite "How should you answer me?"
  ./echolite timeline EchoLite
  ./echolite me
  ./echolite me-history
  ./echolite reflect EchoLite "Consider verifying numerical answers."
  ./echolite me-set /absolute/draft.txt "Reason" EXPECTED_VERSION
  ./echolite me-rollback OLD_VERSION EXPECTED_CURRENT_VERSION
  ./echolite forget MEMORY_ID

Me changes are versioned. Me.txt projects the authoritative database version;
use me-set or reflection to change it. Its allowance is 1200 tokens measured by the installed Qwen tokenizer, with a
separate 16000-byte storage bound. Counts are cached persistently; multilingual
text is no longer constrained by the old 1200-byte allowance. Me is supplied on every model turn. Recall includes semantic matches
and retained conversational context. Archived records remain accessible through
memory tools. Compaction records provenance and labels its summaries as lossy.
Forgetting deletes dependent records, invalidates caches and revokes recovery
authority so copied old backups cannot restore forgotten state through EchoLite.

Tools and caching

The native action loop currently connects calculator, local dictionary, offline
Wikipedia, local file reading/listing, PDF page reading, DOCX body/table text reading, HTTPS web reading, supervised commands and saved-output reading, memory/session tools, notes, compaction,
Me revisions and task records. Source receipts and calculations are distinguished
from trained memory and inference. The model can chain tool results.
Command output is committed with its receipt by the native supervisor. Later
turns can retrieve it even if the original chat stopped before attaching the
receipt to memory; reading retained output does not rerun the command.
Persistent SQLite caches retain reusable model and tool results. Settings,
source identities and the forgetting epoch participate in cache identity.
Cache hits avoid repeated work; new input or invalidated entries still require
computation. On a response-cache miss, EP restores a validated native slot
snapshot before generation and saves the resulting slot afterward. One native
snapshot is retained for the shared single-slot runtime; the separate exact
response cache retains many prior results. Snapshot manifests bind state path,
model namespace, forgetting epoch and recovery authority, with streaming SHA-256
verification and private files. Forgetting and backup restore take the runtime
lease before clearing native snapshots, preventing concurrent stale publication.
A save failure is recorded in the generation result without discarding its answer.

Storage recovery

  ./echolite doctor
  ./echolite backup-create
  ./echolite backup-list
  ./echolite backup-check BACKUP_ID
  ./echolite backup-restore BACKUP_ID
  ./echolite backup-delete BACKUP_ID

These operations are implemented in EP. Snapshots have exact SHA-256 seals and
independent recovery-generation bindings. Restore requires exclusive state and
worker leases. If interrupted, repeat the same backup-restore command; the
persistent intent prevents ordinary commands from using partly restored state.
Restore recovers Me and marks unfinished external activity as uncertain rather
than automatically rerunning it. Keep at most three managed snapshots.

Validation

Current EP tests live in tests/*.ep; evidence/native-ep-* records focused checks
and real user journeys. For example, compile tests/generation_settings.ep and
run its generated executable to check request settings. Tests that mutate state
require their documented isolated fixture arguments; never point them at data/.
The completed full-context evidence remains in evidence/full-context-packed-20261117.
It is retained evidence from the earlier backend, not a newly repeated benchmark.

Run the offline EP regression suite with a new output directory:
  ~/.local/bin/ernos tests/acceptance.ep
  ./tests/acceptance /absolute/new-output-directory

The runner compiles and checks 22 deterministic suites with separate temporary
state, bounded execution, exit-status checks and saved logs. It does not start a
model, make generation requests or repeat the completed context benchmark.
Other EP integration suites cover real model, UI, process and recovery journeys;
the offline suite is not a substitute for those checks.

The retired Python application, setup scripts, dependency locks and test harness
have been removed. Their last complete source is in Git commit 4e9208c. Historical
benchmark evidence is preserved byte-for-byte, including its original probe
sources; none is imported by the application. The discarded local environment is
outside the checkout. Historical instructions in docs/Legacy-Prototype-Notes.txt
are archival, not installation instructions for the native application.

The wider project work continues on multimodal attachment flows and native
installation tooling.

Stopping a response
While a chat is running, the send arrow becomes a square Stop button. Click it to stop local inference. The user message stays in history, unfinished output is discarded, and the composer becomes available again. Completed tool effects remain recorded and are not undone.

Correcting durable memory
In chat, state the correction and ask EchoLite to update the existing memory.
The memory_correct tool takes a note_id, corrected text and reason. Search/open
results expose notes[].note_id separately from the tool receipt's memory_id.
The old semantic/procedural note stays historical; its replacement becomes
active for passive recall. memory_open on either record shows the correction
link. Original conversation events are retained, and deleting a replacement
does not reactivate the older fact.

Persistent tasks

Ask EchoLite to save a task with an observable success condition, and say when
it should wait for a later conversation. Reopen the app or start a new
conversation and ask it to resume the saved task. Active task checkpoints are
loaded with working memory, including the next action and current revision.
A task can be completed only with a successful recorded work-tool receipt;
failed tools, notes and task bookkeeping do not qualify as completion evidence.
An identical active objective/success-condition pair reuses the existing task.
Tasks with a different condition remain distinct, and terminal tasks are not
reopened by a stale update. You can inspect records with:
  ./echolite tasks EchoLite
  ./echolite task-open EchoLite TASK_ID

Local coding reference

EchoLite receives compact runtime facts: macOS ARM64, actual working/install/
state directories, the configured Ernos compiler and local documentation paths.
It does not copy the environment or credentials into the model prompt.
The installed Ernos language reference lives in library/technical/ernos with
its source revision, snapshot date, SHA-256 and licence. The agent reads it
through the normal bounded file tool when needed. docs/Local-Toolchain.txt
covers EP source, compilation, native execution and supervised host commands.
Missing reference/compiler availability is reported explicitly in runtime facts.
ERNOS_COMPILER overrides the compiler path consistently with the build command.

Retrying repaired commands

A repeated process command normally replays its saved result. When inputs have
changed, process_retry takes the original operation_id (its output_ref) and a
reason describing the change. EP retrieves the original command and checks its
project, epoch and known exit. The same retry intent cannot execute twice;
repeated requests replay the new receipt. This permits repair-and-rebuild work
while protecting interrupted commands from blind repetition. Unknown,
cancelled and timed-out operations require inspection.

Scheduled tasks

Ask EchoLite to save a task and when to do it. Tasks in the sidebar shows the
objective, task status, UTC due time and dispatch result; Cancel removes an
armed schedule. While open and idle, EchoLite dispatches due tasks one at a
time through the same local chat/tool pipeline. Typing or other interaction
interrupts scheduled work and preserves your draft. It does not wake a sleeping
computer or run while closed. Due tasks remain on disk for the next launch.
See docs/Scheduled-Tasks.txt for execution limits, recovery and CLI commands.

Belief assessments and validity
Ask EchoLite to mark a remembered claim disputed, supported or tentative, or to
record known validity dates. It can use memory_assess without rewriting the
original note. Read results expose state, revision, evidence attribution and
history. Expired/future claims leave current recall while remaining inspectable;
unchanged embeddings stay cached. See docs/Belief-Memory.txt and the completed
delivery markers in docs/Delivery-Audit.txt.
