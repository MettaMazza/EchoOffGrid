#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#ifdef __wasm__
#define _SETJMP_H
typedef int jmp_buf[1];
#define setjmp(buf) (0)
#define longjmp(buf, val) abort()

// Mock pthreads for single-threaded WASM
typedef struct { int lock_state; } pthread_mutex_t;
typedef struct { int cond_state; } pthread_cond_t;
typedef struct { int rw_state; } pthread_rwlock_t;
typedef int pthread_t;
typedef int pthread_attr_t;
#define PTHREAD_MUTEX_INITIALIZER {0}
#define PTHREAD_COND_INITIALIZER {0}
#define PTHREAD_RWLOCK_INITIALIZER {0}
#define pthread_mutex_init(m, a) ((void)(a), (m)->lock_state = 0, 0)
#define pthread_mutex_lock(m) ((m)->lock_state = 1, 0)
#define pthread_mutex_unlock(m) ((m)->lock_state = 0, 0)
#define pthread_mutex_trylock(m) ((m)->lock_state == 0 ? ((m)->lock_state = 1, 0) : 1)
#define pthread_mutex_destroy(m) ((void)(m), 0)
#define pthread_cond_init(c, a) ((void)(a), (c)->cond_state = 0, 0)
#define pthread_cond_wait(c, m) ((void)(c), (void)(m), 0)
#define pthread_cond_signal(c) ((void)(c), 0)
#define pthread_cond_broadcast(c) ((void)(c), 0)
#define pthread_cond_destroy(c) ((void)(c), 0)
#define pthread_rwlock_init(r, a) ((void)(a), (r)->rw_state = 0, 0)
#define pthread_rwlock_rdlock(r) ((r)->rw_state = 1, 0)
#define pthread_rwlock_wrlock(r) ((r)->rw_state = 2, 0)
#define pthread_rwlock_unlock(r) ((r)->rw_state = 0, 0)
#define pthread_rwlock_destroy(r) ((void)(r), 0)
#define pthread_create(t, a, f, arg) ((void)(t), (void)(a), (void)(f), (void)(arg), 0)
#define pthread_join(t, r) ((void)(t), (void)(r), 0)
#define pthread_detach(t) ((void)(t), 0)
#else
#include <setjmp.h>
#include <limits.h>
#endif
#include <signal.h>
#include <time.h>
#ifndef _WIN32
#include <unistd.h>
#endif
/* Terminal control for read_key/terminal_columns/terminal_rows: raw keyboard
   input and window size, each with a native path per platform. */
#if defined(_WIN32)
#include <conio.h>
#include <io.h>
#elif !defined(__wasm__)
#include <termios.h>
#include <sys/ioctl.h>
#endif
#if defined(__APPLE__)
#include <mach/mach.h>
#endif
#if defined(__linux__)
#include <sys/random.h>
#endif
#include <fcntl.h>

/* Cryptographically secure random bytes. Uses the OS CSPRNG: arc4random on
   Apple/BSD, getrandom(2) on Linux (falling back to /dev/urandom), and a
   /dev/urandom read elsewhere. Only if all of those are unavailable does it
   fall back to rand() — never on a supported platform. */
static void ep_secure_random_bytes(unsigned char* buf, size_t n) {
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__)
    arc4random_buf(buf, n);
#else
    size_t got = 0;
  #if defined(__linux__)
    while (got < n) {
        ssize_t r = getrandom(buf + got, n - got, 0);
        if (r <= 0) break;
        got += (size_t)r;
    }
  #endif
    if (got < n) {
        FILE* f = fopen("/dev/urandom", "rb");
        if (f) {
            got += fread(buf + got, 1, n - got, f);
            fclose(f);
        }
    }
    while (got < n) {
        buf[got++] = (unsigned char)(rand() & 0xFF);
    }
#endif
}

/* Try/catch infrastructure */
static jmp_buf ep_try_buf;
static volatile int ep_try_active = 0;

static void ep_signal_handler(int sig) {
    if (ep_try_active) {
        ep_try_active = 0;
        longjmp(ep_try_buf, sig);
    }
    /* Outside try: print error and exit */
    const char* name = sig == SIGSEGV ? "segmentation fault (null pointer or invalid memory access)"
                     : sig == SIGFPE  ? "arithmetic error (division by zero)"
                     : sig == SIGABRT ? "aborted"
                     : "unknown signal";
    fprintf(stderr, "\nRuntime Error: %s (signal %d)\n", name, sig);

    /* Write to daemon/general log file if environment variable is set */
    const char* daemon_log = getenv("ERNOS_DAEMON_LOG");
    if (!daemon_log || daemon_log[0] == '\0') {
        daemon_log = getenv("ERNOS_LOG_FILE");
    }
    if (daemon_log && daemon_log[0] != '\0') {
        FILE* f = fopen(daemon_log, "ab");
        if (f) {
            time_t rawtime;
            time(&rawtime);
            struct tm * timeinfo = localtime(&rawtime);
            char time_buf[80];
            if (timeinfo) {
                strftime(time_buf, sizeof(time_buf), "%Y-%m-%d %H:%M:%S", timeinfo);
            } else {
                snprintf(time_buf, sizeof(time_buf), "%lld", (long long)rawtime);
            }
            fprintf(f, "[%s] FATAL: Runtime Error: %s (signal %d)\n", time_buf, name, sig);
            fclose(f);
        }
    }

    _exit(128 + sig);
}

#ifdef _MSC_VER
static void ep_install_signal_handlers(void);
#pragma section(".CRT$XCU", read)
__declspec(allocate(".CRT$XCU")) static void (*_ep_init_signals)(void) = ep_install_signal_handlers;
static void ep_install_signal_handlers(void) {
#else
__attribute__((constructor))
static void ep_install_signal_handlers(void) {
#endif
    signal(SIGFPE, ep_signal_handler);
    signal(SIGSEGV, ep_signal_handler);
    signal(SIGABRT, ep_signal_handler);
#ifdef _WIN32
    { WSADATA wsa; WSAStartup(MAKEWORD(2,2), &wsa); }
#endif
}

#if defined(__wasm__)
  typedef int ep_thread_t;
  typedef int ep_mutex_t;
  typedef int ep_cond_t;
  #define ep_mutex_init(m) (void)(0)
  #define ep_mutex_lock(m) (void)(0)
  #define ep_mutex_unlock(m) (void)(0)
  #define ep_cond_init(c) (void)(0)
  #define ep_cond_wait(c, m) (void)(0)
  #define ep_cond_signal(c) (void)(0)
#elif defined(_WIN32)
  #include <winsock2.h>
  #include <ws2tcpip.h>
  #include <windows.h>
  #pragma comment(lib, "ws2_32.lib")
  typedef HANDLE ep_thread_t;
  typedef CRITICAL_SECTION ep_mutex_t;
  typedef CONDITION_VARIABLE ep_cond_t;
  #define ep_mutex_init(m) InitializeCriticalSection(m)
  #define ep_mutex_lock(m) EnterCriticalSection(m)
  #define ep_mutex_unlock(m) LeaveCriticalSection(m)
  #define ep_cond_init(c) InitializeConditionVariable(c)
  #define ep_cond_wait(c, m) SleepConditionVariableCS(c, m, INFINITE)
  #define ep_cond_signal(c) WakeConditionVariable(c)
#else
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <unistd.h>
  #include <netdb.h>
  #include <fcntl.h>
  #include <errno.h>
  #include <sys/select.h>
  #include <pthread.h>
  typedef pthread_t ep_thread_t;
  typedef pthread_mutex_t ep_mutex_t;
  typedef pthread_cond_t ep_cond_t;
  #define ep_mutex_init(m) pthread_mutex_init(m, NULL)
  #define ep_mutex_lock(m) pthread_mutex_lock(m)
  #define ep_mutex_unlock(m) pthread_mutex_unlock(m)
  #define ep_cond_init(c) pthread_cond_init(c, NULL)
  #define ep_cond_wait(c, m) pthread_cond_wait(c, m)
  #define ep_cond_signal(c) pthread_cond_signal(c)
#endif

/* ========== Ernos Mark-and-Sweep Garbage Collector ========== */

#include <setjmp.h>
#if !defined(__wasm__) && !defined(_WIN32)
#include <pthread.h>
#endif

typedef enum {
    EP_OBJ_LIST,
    EP_OBJ_STRING,
    EP_OBJ_STRUCT,
    EP_OBJ_CLOSURE,
    EP_OBJ_MAP
} EpObjKind;

typedef struct EpGCObject {
    EpObjKind kind;
    int marked;
    void* ptr;                /* actual allocation pointer */
    long long size;           /* payload size for structs */
    long long num_fields;     /* number of fields for structs (each is long long) */
    int generation;           /* 0 = Nursery/young, 1 = Old */
    struct EpGCObject* next;  /* intrusive linked list */
} EpGCObject;

long long ep_time_now_ms(void);
long long ep_sleep_ms(long long ms);

typedef struct EpTask EpTask;
typedef struct {
    long long chan;
    int completed;
    long long value;
    EpTask* waiting_task;
} EpFuture;

static long long ep_await_future(EpFuture* fut);

struct EpTask {
    long long (*step)(void*); /* pointer to step function */
    void* args;               /* pointer to step state arguments */
    long long args_size_bytes; /* size of args struct for GC tracing */
    EpTask* next;             /* run-queue link pointer */
    EpFuture* fut;            /* future associated with this task */
    int state;                /* coroutine execution state */
    int is_cancelled;         /* cancellation flag for structured concurrency */
    struct EpTask* parent;    /* parent task for structured concurrency cancellation */
};

/* Event Loop Scheduler Globals & Functions */
static EpTask* ep_run_queue_head = NULL;
static EpTask* ep_run_queue_tail = NULL;
static EpTask* ep_current_task = NULL;
static int ep_event_loop_fd = -1; /* epoll or kqueue fd */
static int ep_active_io_sources = 0;

static void ep_task_enqueue(EpTask* task) {
    if (!task) return;
    task->next = NULL;
    if (ep_run_queue_tail) {
        ep_run_queue_tail->next = task;
        ep_run_queue_tail = task;
    } else {
        ep_run_queue_head = ep_run_queue_tail = task;
    }
}

static EpTask* ep_task_dequeue(void) {
    if (!ep_run_queue_head) return NULL;
    EpTask* task = ep_run_queue_head;
    ep_run_queue_head = ep_run_queue_head->next;
    if (!ep_run_queue_head) ep_run_queue_tail = NULL;
    return task;
}

#ifndef __wasm__
#ifdef __APPLE__
#include <sys/event.h>
#else
#include <sys/epoll.h>
#endif
#endif

static void ep_async_loop_init(void) {
    if (ep_event_loop_fd != -1) return;
#ifdef __wasm__
    ep_event_loop_fd = 999;
#elif defined(__APPLE__)
    ep_event_loop_fd = kqueue();
#else
    ep_event_loop_fd = epoll_create1(0);
#endif
}

typedef struct EpTimer {
    long long expiry_ms;
    EpTask* task;
    struct EpTimer* next;
} EpTimer;
static EpTimer* ep_timers_head = NULL;

static void ep_async_register_timer(long long timeout_ms, EpTask* task) {
    long long expiry = ep_time_now_ms() + timeout_ms;
    EpTimer* timer = (EpTimer*)malloc(sizeof(EpTimer));
    timer->expiry_ms = expiry;
    timer->task = task;
    timer->next = NULL;

    /* Insert sorted */
    if (!ep_timers_head || expiry < ep_timers_head->expiry_ms) {
        timer->next = ep_timers_head;
        ep_timers_head = timer;
    } else {
        EpTimer* cur = ep_timers_head;
        while (cur->next && cur->next->expiry_ms <= expiry) {
            cur = cur->next;
        }
        timer->next = cur->next;
        cur->next = timer;
    }
}

static long long ep_get_next_timer_timeout(void) {
    if (!ep_timers_head) return -1; /* block indefinitely */
    long long now = ep_time_now_ms();
    long long diff = ep_timers_head->expiry_ms - now;
    return diff < 0 ? 0 : diff;
}

static void ep_process_expired_timers(void) {
    long long now = ep_time_now_ms();
    while (ep_timers_head && ep_timers_head->expiry_ms <= now) {
        EpTimer* expired = ep_timers_head;
        ep_timers_head = ep_timers_head->next;
        ep_task_enqueue(expired->task);
        free(expired);
    }
}

static void ep_async_register_read(int fd, EpTask* task) {
#ifdef __wasm__
    (void)fd;
    (void)task;
#else
    ep_async_loop_init();
    ep_active_io_sources++;
#ifdef __APPLE__
    struct kevent ev;
    EV_SET(&ev, fd, EVFILT_READ, EV_ADD | EV_ONESHOT, 0, 0, task);
    kevent(ep_event_loop_fd, &ev, 1, NULL, 0, NULL);
#else
    struct epoll_event ev;
    ev.events = EPOLLIN | EPOLLONESHOT;
    ev.data.ptr = task;
    if (epoll_ctl(ep_event_loop_fd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        epoll_ctl(ep_event_loop_fd, EPOLL_CTL_MOD, fd, &ev);
    }
#endif
#endif
}

static void ep_async_wait_step(long long timeout) {
#ifdef __wasm__
    if (timeout > 0) {
        ep_sleep_ms(timeout);
    }
#else
#ifdef __APPLE__
    struct kevent events[16];
    struct timespec ts;
    struct timespec* p_ts = NULL;
    if (timeout >= 0) {
        ts.tv_sec = timeout / 1000;
        ts.tv_nsec = (timeout % 1000) * 1000000;
        p_ts = &ts;
    }
    int n = kevent(ep_event_loop_fd, NULL, 0, events, 16, p_ts);
    for (int i = 0; i < n; i++) {
        EpTask* t = (EpTask*)events[i].udata;
        ep_task_enqueue(t);
        ep_active_io_sources--;
    }
#else
    struct epoll_event events[16];
    int n = epoll_wait(ep_event_loop_fd, events, 16, (int)timeout);
    for (int i = 0; i < n; i++) {
        EpTask* t = (EpTask*)events[i].data.ptr;
        ep_task_enqueue(t);
        ep_active_io_sources--;
    }
#endif
#endif
    ep_process_expired_timers();
}

static void ep_async_loop_run(void) {
    ep_async_loop_init();
    while (ep_run_queue_head || ep_timers_head || ep_active_io_sources > 0) {
        /* 1. Run all runnable tasks */
        while (ep_run_queue_head) {
            EpTask* task = ep_task_dequeue();
            if (task->is_cancelled) {
                if (task->fut) {
                    task->fut->completed = 1;
                    task->fut->value = -1;
                }
                free(task->args);
                free(task);
                continue;
            }
            ep_current_task = task;
            long long res = task->step(task->args);
            ep_current_task = NULL;
            if (res != -999999) {
                if (task->fut) {
                    task->fut->value = res;
                    task->fut->completed = 1;
                    if (task->fut->waiting_task) {
                        ep_task_enqueue(task->fut->waiting_task);
                        task->fut->waiting_task = NULL;
                    }
                }
                free(task->args);
                free(task);
            }
        }

        /* 2. If no tasks runnable, wait for I/O / timers */
        if (!ep_run_queue_head) {
            long long timeout = ep_get_next_timer_timeout();
            if (timeout == -1 && !ep_timers_head && ep_active_io_sources == 0) {
                break;
            }

            if (ep_event_loop_fd == -1) {
                if (timeout > 0) {
                    ep_sleep_ms(timeout);
                }
                ep_process_expired_timers();
                continue;
            }

            ep_async_wait_step(timeout);
        }
    }
}

static long long ep_await_future(EpFuture* fut) {
    if (!fut) return 0;
    while (!fut->completed) {
        if (ep_run_queue_head) {
            EpTask* task = ep_task_dequeue();
            if (task) {
                if (task->is_cancelled) {
                    if (task->fut) {
                        task->fut->completed = 1;
                        task->fut->value = -1;
                    }
                    free(task->args);
                    free(task);
                } else {
                    EpTask* saved_current = ep_current_task;
                    ep_current_task = task;
                    long long res = task->step(task->args);
                    ep_current_task = saved_current;
                    if (res != -999999) {
                        if (task->fut) {
                            task->fut->value = res;
                            task->fut->completed = 1;
                            if (task->fut->waiting_task) {
                                ep_task_enqueue(task->fut->waiting_task);
                                task->fut->waiting_task = NULL;
                            }
                        }
                        free(task->args);
                        free(task);
                    }
                }
            }
        } else {
            long long timeout = ep_get_next_timer_timeout();
            if (timeout == -1 && !ep_timers_head && ep_active_io_sources == 0) {
                fprintf(stderr, "Deadlock detected: awaiting incomplete future with no active tasks or timers.\n");
                exit(1);
            }
            if (ep_event_loop_fd == -1) {
                if (timeout > 0) {
                    ep_sleep_ms(timeout);
                }
                ep_process_expired_timers();
            } else {
                ep_async_wait_step(timeout);
            }
        }
    }
    return fut->value;
}

static EpGCObject* ep_gc_register(void* ptr, EpObjKind kind);
long long create_list(void);
long long append_list(long long list_ptr, long long value);

typedef struct {
    EpFuture* futures[128];
    int count;
    int has_error;
} EpTaskGroup;

typedef struct {
    EpFuture* fut;
    int timer_fired;
} EpTimeoutArgs;

static EpTask* ep_find_task_by_future(EpFuture* fut) {
    if (!fut) return NULL;
    EpTask* cur = ep_run_queue_head;
    while (cur) {
        if (cur->fut == fut) return cur;
        cur = cur->next;
    }
    EpTimer* timer = ep_timers_head;
    while (timer) {
        if (timer->task && timer->task->fut == fut) return timer->task;
        timer = timer->next;
    }
    return NULL;
}

static void ep_cancel_task(EpTask* task) {
    if (!task) return;
    task->is_cancelled = 1;
    if (task->fut) {
        task->fut->completed = 1;
        task->fut->value = -1;
    }
    // Cancel children in run queue
    EpTask* cur = ep_run_queue_head;
    while (cur) {
        if (cur->parent == task) {
            ep_cancel_task(cur);
        }
        cur = cur->next;
    }
    // Cancel children in timers queue
    EpTimer* timer = ep_timers_head;
    while (timer) {
        if (timer->task && timer->task->parent == task) {
            ep_cancel_task(timer->task);
        }
        timer = timer->next;
    }
}

static long long create_task_group(void) {
    EpTaskGroup* tg = (EpTaskGroup*)calloc(1, sizeof(EpTaskGroup));
    tg->count = 0;
    tg->has_error = 0;
    { EpGCObject* _go = ep_gc_register(tg, EP_OBJ_STRUCT); if(_go) _go->num_fields = 0; }
    return (long long)tg;
}

static long long add_task_group(long long group_ptr, long long fut_ptr) {
    EpTaskGroup* tg = (EpTaskGroup*)group_ptr;
    EpFuture* fut = (EpFuture*)fut_ptr;
    if (!tg || !fut) return 0;
    if (tg->count < 128) {
        tg->futures[tg->count++] = fut;
        // Associate the task's parent with the current task so it's cancellation-linked
        EpTask* task = ep_find_task_by_future(fut);
        if (task) {
            task->parent = ep_current_task;
        }
    }
    return 0;
}

static long long wait_task_group(long long group_ptr) {
    EpTaskGroup* tg = (EpTaskGroup*)group_ptr;
    if (!tg) return 0;

    long long ep_wait_group_spin = 0;
    int all_done = 0;
    while (!all_done) {
        all_done = 1;
        for (int i = 0; i < tg->count; i++) {
            EpFuture* fut = tg->futures[i];
            if (!fut->completed) {
                all_done = 0;
                break;
            }
        }
        
        if (all_done) break;
        
        if (ep_run_queue_head) {
            EpTask* task = ep_task_dequeue();
            if (task) {
                if (task->is_cancelled) {
                    if (task->fut) {
                        task->fut->completed = 1;
                        task->fut->value = -1;
                    }
                    free(task->args);
                    free(task);
                } else {
                    EpTask* saved_current = ep_current_task;
                    ep_current_task = task;
                    long long res = task->step(task->args);
                    ep_current_task = saved_current;
                    if (res != -999999) {
                        if (task->fut) {
                            task->fut->value = res;
                            task->fut->completed = 1;
                            if (task->fut->waiting_task) {
                                ep_task_enqueue(task->fut->waiting_task);
                                task->fut->waiting_task = NULL;
                            }
                        }
                        free(task->args);
                        free(task);
                    }
                }
            }
        } else {
            long long timeout = ep_get_next_timer_timeout();
            if (timeout == -1 && !ep_timers_head && ep_active_io_sources == 0) {
                /* No coroutine tasks/timers/IO to drive. The futures may still be
                   completed by detached worker THREADS (the self-hosted compiler
                   emits thread-based async), so poll for their completion rather
                   than declaring deadlock. Bounded so a genuinely stuck group
                   still fails instead of hanging forever. */
                ep_sleep_ms(1);
                if (++ep_wait_group_spin > 60000) {
                    fprintf(stderr, "Deadlock detected: waiting on task group with no active tasks or timers.\n");
                    exit(1);
                }
                continue;
            }
            ep_wait_group_spin = 0;
            if (ep_event_loop_fd == -1) {
                if (timeout > 0) {
                    ep_sleep_ms(timeout);
                }
                ep_process_expired_timers();
            } else {
                ep_async_wait_step(timeout);
            }
        }
        
        // Propagate cancellation/failure inside task group
        for (int i = 0; i < tg->count; i++) {
            EpFuture* fut = tg->futures[i];
            if (fut->completed && fut->value == -1) {
                tg->has_error = 1;
                for (int j = 0; j < tg->count; j++) {
                    EpFuture* other_fut = tg->futures[j];
                    if (!other_fut->completed) {
                        EpTask* other_task = ep_find_task_by_future(other_fut);
                        if (other_task) {
                            ep_cancel_task(other_task);
                        } else {
                            other_fut->completed = 1;
                            other_fut->value = -1;
                        }
                    }
                }
            }
        }
    }
    
    long long list = create_list();
    for (int i = 0; i < tg->count; i++) {
        append_list(list, tg->futures[i]->value);
    }
    return list;
}

static long long ep_timeout_timer_step(void* r) {
    EpTimeoutArgs* args = (EpTimeoutArgs*)r;
    if (args && args->fut && !args->fut->completed) {
        args->timer_fired = 1;
        EpTask* task = ep_find_task_by_future(args->fut);
        if (task) {
            ep_cancel_task(task);
        } else {
            args->fut->completed = 1;
            args->fut->value = -1;
        }
    }
    return 0;
}

static long long async_timeout(long long timeout_ms, long long fut_ptr) {
    EpFuture* fut = (EpFuture*)fut_ptr;
    if (!fut) return -1;
    if (fut->completed) return fut->value;
    
    EpTimeoutArgs* args = (EpTimeoutArgs*)malloc(sizeof(EpTimeoutArgs));
    args->fut = fut;
    args->timer_fired = 0;
    
    EpTask* timer_task = (EpTask*)malloc(sizeof(EpTask));
    timer_task->step = ep_timeout_timer_step;
    timer_task->args = args;
    timer_task->args_size_bytes = sizeof(EpTimeoutArgs);
    timer_task->fut = NULL;
    timer_task->state = 0;
    timer_task->is_cancelled = 0;
    timer_task->parent = NULL;
    
    ep_async_register_timer(timeout_ms, timer_task);
    
    while (!fut->completed && !(args->timer_fired)) {
        if (ep_run_queue_head) {
            EpTask* task = ep_task_dequeue();
            if (task) {
                if (task->is_cancelled) {
                    if (task->fut) {
                        task->fut->completed = 1;
                        task->fut->value = -1;
                    }
                    free(task->args);
                    free(task);
                } else {
                    EpTask* saved_current = ep_current_task;
                    ep_current_task = task;
                    long long res = task->step(task->args);
                    ep_current_task = saved_current;
                    if (res != -999999) {
                        if (task->fut) {
                            task->fut->value = res;
                            task->fut->completed = 1;
                            if (task->fut->waiting_task) {
                                ep_task_enqueue(task->fut->waiting_task);
                                task->fut->waiting_task = NULL;
                            }
                        }
                        free(task->args);
                        free(task);
                    }
                }
            }
        } else {
            long long timeout = ep_get_next_timer_timeout();
            if (timeout == -1 && !ep_timers_head && ep_active_io_sources == 0) {
                break;
            }
            if (ep_event_loop_fd == -1) {
                if (timeout > 0) {
                    ep_sleep_ms(timeout);
                }
                ep_process_expired_timers();
            } else {
                ep_async_wait_step(timeout);
            }
        }
    }
    
    return fut->value;
}

/* ── Awaitable async socket-readability ─────────────────────────────────────
   `await async_wait_readable(fd)` suspends the calling async task until `fd` is
   readable, letting the event loop run other tasks (e.g. another agent waiting on
   its own LLM socket) meanwhile. Mirrors sleep_ms: build a future, register a
   oneshot read-readiness task with the loop, return the future. When fd becomes
   readable, ep_async_wait_step re-enqueues the task; its step completes the future
   and wakes whoever awaited it. This is what lets I/O-bound agents run concurrently
   on ONE thread — no OS threads, no shared-heap GC race. */
typedef struct { EpFuture* fut; } EpReadReadyArgs;
static long long ep_read_ready_step(void* r) {
    EpReadReadyArgs* args = (EpReadReadyArgs*)r;
    if (args && args->fut) {
        args->fut->completed = 1;
        args->fut->value = 1;
        if (args->fut->waiting_task) {
            ep_task_enqueue(args->fut->waiting_task);
            args->fut->waiting_task = NULL;
        }
    }
    return 0;
}
long long async_wait_readable(long long fd) {
    EpFuture* fut = (EpFuture*)malloc(sizeof(EpFuture));
    fut->completed = 0;
    fut->value = 0;
    fut->waiting_task = NULL;
    fut->chan = 0;
    { EpGCObject* _go = ep_gc_register(fut, EP_OBJ_STRUCT); if(_go) _go->num_fields = 3; }
    EpReadReadyArgs* args = (EpReadReadyArgs*)malloc(sizeof(EpReadReadyArgs));
    args->fut = fut;
    EpTask* task = (EpTask*)malloc(sizeof(EpTask));
    task->step = ep_read_ready_step;
    task->args = args;
    task->args_size_bytes = sizeof(EpReadReadyArgs);
    task->fut = NULL;
    task->state = 0;
    task->is_cancelled = 0;
    task->parent = ep_current_task;
    ep_async_register_read((int)fd, task);
    return (long long)fut;
}

typedef struct {
    EpFuture* fut;
} EpSleepTimerArgs;

static long long ep_sleep_timer_step(void* r) {
    EpSleepTimerArgs* args = (EpSleepTimerArgs*)r;
    if (args && args->fut) {
        args->fut->completed = 1;
        args->fut->value = 0;
        if (args->fut->waiting_task) {
            ep_task_enqueue(args->fut->waiting_task);
            args->fut->waiting_task = NULL;
        }
    }
    return 0;
}

static long long sleep_ms(long long ms) {
    /* Outside the event loop (no task is being stepped) a registered timer
       would never fire on its own, so the cooperative path used to sleep for
       0 ms. Block for real instead, and hand back an already-completed
       future so `await sleep_ms(...)` from synchronous code still works. */
    if (!ep_current_task) {
        if (ms > 0) ep_sleep_ms(ms);
        EpFuture* done = (EpFuture*)malloc(sizeof(EpFuture));
        done->completed = 1;
        done->value = 0;
        done->waiting_task = NULL;
        done->chan = 0;
        { EpGCObject* _go = ep_gc_register(done, EP_OBJ_STRUCT); if(_go) _go->num_fields = 3; }
        return (long long)done;
    }
    EpFuture* fut = (EpFuture*)malloc(sizeof(EpFuture));
    fut->completed = 0;
    fut->value = 0;
    fut->waiting_task = NULL;
    fut->chan = 0;
    { EpGCObject* _go = ep_gc_register(fut, EP_OBJ_STRUCT); if(_go) _go->num_fields = 3; }

    EpSleepTimerArgs* args = (EpSleepTimerArgs*)malloc(sizeof(EpSleepTimerArgs));
    args->fut = fut;
    
    EpTask* task = (EpTask*)malloc(sizeof(EpTask));
    task->step = ep_sleep_timer_step;
    task->args = args;
    task->args_size_bytes = sizeof(EpSleepTimerArgs);
    task->fut = NULL;
    task->state = 0;
    task->is_cancelled = 0;
    task->parent = ep_current_task;
    
    ep_async_register_timer(ms, task);
    return (long long)fut;
}

static long long cancel_task(long long fut_ptr) {
    EpFuture* fut = (EpFuture*)fut_ptr;
    if (fut) {
        EpTask* task = ep_find_task_by_future(fut);
        if (task) {
            ep_cancel_task(task);
        } else {
            fut->completed = 1;
            fut->value = -1;
        }
    }
    return 0;
}

/* Closure environment — captures travel with the function pointer */
#define EP_CLOSURE_MAGIC 0x4550434C4FL
typedef struct {
    long long magic;
    long long fn_ptr;
    long long env[];  /* flexible array of captured values */
} EpClosure;

/* GC globals */
static EpGCObject* ep_gc_head = NULL;
static long long ep_gc_count = 0;
static long long ep_gc_threshold = 4096;
static int ep_gc_enabled = 1;
static long long ep_gc_nursery_count = 0;
static long long ep_gc_nursery_threshold = 512;
static int ep_gc_minor_count = 0;
static int ep_gc_major_count = 0;
static void** ep_gc_remembered_set = NULL;
static long long ep_gc_remembered_cap = 0;
static long long ep_gc_remembered_size = 0;
/* Single mutex for ALL GC and thread registry operations.
   Previous design had two mutexes (ep_gc_mutex + ep_thread_registry_mutex)
   which caused deadlock under concurrent channel load: thread A held gc_mutex
   and waited for registry_mutex, thread B held registry_mutex and waited for
   gc_mutex. Single lock eliminates the ordering problem. */
#ifdef __wasm__
#define __thread
#endif
static pthread_mutex_t ep_gc_mutex = PTHREAD_MUTEX_INITIALIZER;

/* Stop-the-world coordination. The collector sets ep_gc_stop_requested and, in
   ep_gc_stop_the_world(), waits until every *other* registered thread has parked
   at a safepoint (ep_gc_park_if_stopped). This guarantees mark/sweep never runs
   concurrently with a mutator changing its roots or an object's fields — the
   "marking races with running mutators" hazard. All three fields are touched
   only while holding ep_gc_mutex (the lock-free reads of ep_gc_stop_requested at
   safepoints are a benign optimization: a missed set just defers parking to the
   next safepoint, and the collector's bounded wait covers it). */
static volatile int ep_gc_stop_requested = 0;
static int ep_gc_parked_count = 0;
static pthread_cond_t ep_gc_resume_cond = PTHREAD_COND_INITIALIZER;

/* Function pointer for channel scanning — set after EpChannel is defined.
   GC mark calls this to scan values in-transit in channel buffers. */
static void (*ep_gc_scan_channels_major)(void) = NULL;
static void (*ep_gc_scan_channels_minor)(void) = NULL;
/* Function pointers for marking top-level constant/global variables, which are
   GC roots that live outside any function frame. Set by __ep_init_constants. */
static void (*ep_gc_mark_globals_major)(void) = NULL;
static void (*ep_gc_mark_globals_minor)(void) = NULL;
/* Function pointers for map value traversal — set after EpMap is defined.
   GC mark calls these to recursively mark values stored in maps. */
static void (*ep_gc_mark_map_values)(void* ptr) = NULL;
static void (*ep_gc_mark_map_values_minor)(void* ptr) = NULL;

/* Thread registry for GC root scanning in multi-threaded environment */
#define EP_MAX_THREADS 256
static __thread void* volatile ep_thread_local_top = NULL;
static __thread void* ep_thread_local_bottom = NULL;

static void* volatile* ep_thread_tops[EP_MAX_THREADS];
static void* ep_thread_bottoms[EP_MAX_THREADS];
static volatile int ep_thread_active[EP_MAX_THREADS];
static int ep_num_threads = 0;

/* Per-thread GC root state — heap-allocated, stable across thread lifetime.
   Previous design stored raw pointers to __thread arrays (ep_gc_root_stack,
   ep_gc_root_sp) in the global registry. When a thread exited, the __thread
   storage was freed, leaving dangling pointers that ep_gc_mark would
   dereference → segfault. Now each thread gets a heap-allocated state struct
   that survives thread exit and is only recycled when the slot is reused. */
typedef struct {
    long long* roots[4096];  /* copy of root pointers, updated under lock */
    volatile int sp;         /* current root stack pointer */
} EpThreadGCState;

static EpThreadGCState* ep_thread_gc_states[EP_MAX_THREADS];

/* Shadow stack for explicit GC roots — thread-local to prevent cross-thread corruption */
#define EP_GC_MAX_ROOTS 4096
static __thread long long* ep_gc_root_stack[EP_GC_MAX_ROOTS];
static __thread int ep_gc_root_sp = 0;
static __thread int ep_thread_slot = -1;

/* ep_gc_root_sp is the *logical* shadow-stack depth. It always advances on
   push and retreats on pop so that per-frame push/pop counts stay balanced.
   Array storage is capped at EP_GC_MAX_ROOTS: once the stack is full, further
   roots are counted but not stored (those deep-overflow locals are simply not
   traced) — crucially, we never overwrite or drop an outer frame's stored
   roots, which the old "silently skip the push but still pop" path did. */
static void ep_gc_push_root(long long* root) {
    int idx = ep_gc_root_sp;
    ep_gc_root_sp++;
    if (idx < EP_GC_MAX_ROOTS) {
        ep_gc_root_stack[idx] = root;
        /* Update the heap-allocated state so GC mark can see it safely */
        if (ep_thread_slot >= 0 && ep_thread_gc_states[ep_thread_slot]) {
            ep_thread_gc_states[ep_thread_slot]->roots[idx] = root;
            ep_thread_gc_states[ep_thread_slot]->sp =
                (ep_gc_root_sp < EP_GC_MAX_ROOTS) ? ep_gc_root_sp : EP_GC_MAX_ROOTS;
        }
    }
}
static void ep_gc_pop_roots(long long count) {
    ep_gc_root_sp -= (int)count;
    if (ep_gc_root_sp < 0) ep_gc_root_sp = 0;
    /* Update the heap-allocated state (clamped to the array bound) */
    if (ep_thread_slot >= 0 && ep_thread_gc_states[ep_thread_slot]) {
        ep_thread_gc_states[ep_thread_slot]->sp =
            (ep_gc_root_sp < EP_GC_MAX_ROOTS) ? ep_gc_root_sp : EP_GC_MAX_ROOTS;
    }
}

/* Park the calling thread if the collector has stopped the world.
   MUST be called with ep_gc_mutex held. The thread's shadow stack (its precise
   root set) is stable while parked, so the collector can scan it race-free. */
static void ep_gc_park_if_stopped(void) {
    if (!ep_gc_stop_requested) return;
    /* Spill registers onto the stack and publish this thread's current stack top
       so the collector can conservatively scan its frozen C stack while parked —
       this catches roots held only in registers/temporaries that the precise
       shadow stack does not yet record. _dummy is declared below _pregs, so its
       (lower) address bounds a scan range that covers the spilled registers. */
    jmp_buf _pregs;
    volatile char _top_marker;  /* function-scope: stays valid while parked */
    memset(&_pregs, 0, sizeof(_pregs));
    setjmp(_pregs);
    /* _top_marker is declared after _pregs, so its (lower) address bounds a scan
       range [&_top_marker, stack_bottom] that covers the spilled registers. */
    ep_thread_local_top = (void*)&_top_marker;
    __sync_synchronize();  /* publish shadow-stack + top writes before parking */
    ep_gc_parked_count++;
    while (ep_gc_stop_requested) {
        pthread_cond_wait(&ep_gc_resume_cond, &ep_gc_mutex);
    }
    ep_gc_parked_count--;
}

/* Begin a stop-the-world pause. MUST be called with ep_gc_mutex held.
   Waits (briefly releasing the lock so blocked mutators can reach a safepoint)
   until all other registered threads have parked. After a bounded fallback
   (~50ms) it proceeds anyway: any thread that hasn't parked by then is blocked
   or idle with a stable shadow stack, so scanning it is still safe in practice. */
static void ep_gc_stop_the_world(void) {
    ep_gc_stop_requested = 1;
    /* Actively-running threads reach a safepoint (every allocation and every
       function entry) within microseconds, so they park on the first spin or
       two. The bound only caps the rare case where a thread is blocked/idle
       (e.g. just entered a channel op) and won't park — those have a stable
       shadow stack, so proceeding to scan them is safe. ~40 * 250us ≈ 10ms. */
    for (int spins = 0; spins < 40; spins++) {
        int others = 0;
        for (int t = 0; t < ep_num_threads; t++) {
            if (ep_thread_active[t] && t != ep_thread_slot) others++;
        }
        if (others <= 0 || ep_gc_parked_count >= others) return;
        pthread_mutex_unlock(&ep_gc_mutex);
#ifdef _WIN32
        Sleep(1);
#elif !defined(__wasm__)
        usleep(250);
#endif
        pthread_mutex_lock(&ep_gc_mutex);
    }
}

/* End a stop-the-world pause and wake all parked threads. MUST hold ep_gc_mutex. */
static void ep_gc_start_the_world(void) {
    ep_gc_stop_requested = 0;
    pthread_cond_broadcast(&ep_gc_resume_cond);
}

static void ep_gc_register_thread(void* stack_bottom) {
    ep_thread_local_bottom = stack_bottom;
    ep_thread_local_top = stack_bottom;
    
    pthread_mutex_lock(&ep_gc_mutex);
    int slot = -1;
    for (int i = 0; i < ep_num_threads; i++) {
        if (!ep_thread_active[i]) {
            slot = i;
            break;
        }
    }
    if (slot == -1 && ep_num_threads < EP_MAX_THREADS) {
        slot = ep_num_threads++;
    }
    if (slot != -1) {
        ep_thread_tops[slot] = &ep_thread_local_top;
        ep_thread_bottoms[slot] = stack_bottom;
        /* Allocate or reuse heap state for this slot */
        if (!ep_thread_gc_states[slot]) {
            ep_thread_gc_states[slot] = (EpThreadGCState*)calloc(1, sizeof(EpThreadGCState));
        }
        ep_thread_gc_states[slot]->sp = 0;
        ep_thread_slot = slot;
        __sync_synchronize();  /* Memory barrier: state must be visible before active */
        ep_thread_active[slot] = 1;
    }
    pthread_mutex_unlock(&ep_gc_mutex);
}

static void ep_gc_unregister_thread(void) {
    pthread_mutex_lock(&ep_gc_mutex);
    for (int i = 0; i < ep_num_threads; i++) {
        if (ep_thread_active[i] && ep_thread_tops[i] == &ep_thread_local_top) {
            /* Zero root count FIRST — even if ep_gc_mark races past the
               active check, it will see sp=0 and walk no roots instead
               of dereferencing stale __thread pointers */
            if (ep_thread_gc_states[i]) {
                ep_thread_gc_states[i]->sp = 0;
            }
            __sync_synchronize();  /* Memory barrier: sp=0 visible before deactivation */
            ep_thread_active[i] = 0;
            ep_thread_slot = -1;
            break;
        }
    }
    pthread_mutex_unlock(&ep_gc_mutex);
}

#define EP_GC_UPDATE_TOP() { volatile int _dummy; ep_thread_local_top = (void*)&_dummy; }

/* Simple open-addressed hash map with linear probing for O(1) GC object lookup */
typedef struct {
    void* key;
    EpGCObject* value;
} EpGCEntry;

static EpGCEntry* ep_gc_table = NULL;
static long long ep_gc_table_cap = 0;
static long long ep_gc_table_size = 0;

/* Bucket index for a pointer key. The previous hash was ((uintptr_t)key % cap)
   with cap a power of two; malloc returns 16-byte-aligned pointers, so the low 4
   bits are always 0 and only every 16th bucket was ever a home slot. That caused
   catastrophic primary clustering -> O(n) probe runs -> ep_gc_table_remove's
   rehash became O(n^2), which (under the single global GC mutex) wedged the whole
   node when a large object list was freed. A splitmix64 finalizer avalanches all
   bits, so even the low bits taken by the (cap-1) mask are well distributed. */
static inline long long ep_gc_index(void* key, long long cap) {
    uint64_t z = (uint64_t)(uintptr_t)key;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    z = z ^ (z >> 31);
    return (long long)(z & (uint64_t)(cap - 1));   /* cap is always a power of two */
}

/* Insert without growing — assumes a free slot exists. Used by the resize and by
   ep_gc_table_remove's rehash, neither of which may trigger a (re)allocation of
   the table mid-iteration. */
static void ep_gc_table_place(void* key, EpGCObject* value) {
    long long idx = ep_gc_index(key, ep_gc_table_cap);
    while (ep_gc_table[idx].key != NULL) {
        if (ep_gc_table[idx].key == key) {
            ep_gc_table[idx].value = value;
            return;
        }
        idx = (idx + 1) & (ep_gc_table_cap - 1);
    }
    ep_gc_table[idx].key = key;
    ep_gc_table[idx].value = value;
    ep_gc_table_size++;
}

static void ep_gc_table_insert(void* key, EpGCObject* value) {
    if (ep_gc_table_size * 2 >= ep_gc_table_cap) {
        long long old_cap = ep_gc_table_cap;
        long long new_cap = old_cap == 0 ? 512 : old_cap * 2;
        EpGCEntry* new_table = (EpGCEntry*)calloc(new_cap, sizeof(EpGCEntry));
        EpGCEntry* old_table = ep_gc_table;
        ep_gc_table = new_table;
        ep_gc_table_cap = new_cap;
        ep_gc_table_size = 0;
        for (long long i = 0; i < old_cap; i++) {
            if (old_table[i].key != NULL) {
                ep_gc_table_place(old_table[i].key, old_table[i].value);
            }
        }
        free(old_table);
    }
    ep_gc_table_place(key, value);
}

static EpGCObject* ep_gc_table_get(void* key) {
    if (ep_gc_table_cap == 0) return NULL;
    long long idx = ep_gc_index(key, ep_gc_table_cap);
    while (ep_gc_table[idx].key != NULL) {
        if (ep_gc_table[idx].key == key) return ep_gc_table[idx].value;
        idx = (idx + 1) & (ep_gc_table_cap - 1);
    }
    return NULL;
}

static void ep_gc_table_remove(void* key) {
    if (ep_gc_table_cap == 0) return;
    long long idx = ep_gc_index(key, ep_gc_table_cap);
    while (ep_gc_table[idx].key != NULL) {
        if (ep_gc_table[idx].key == key) {
            ep_gc_table[idx].key = NULL;
            ep_gc_table[idx].value = NULL;
            ep_gc_table_size--;
            /* Backward-shift rehash of the rest of this cluster. Re-place (no
               resize: size is not growing) so a mid-iteration realloc can never
               free the table out from under this loop. */
            long long next_idx = (idx + 1) & (ep_gc_table_cap - 1);
            while (ep_gc_table[next_idx].key != NULL) {
                void* rehash_key = ep_gc_table[next_idx].key;
                EpGCObject* rehash_val = ep_gc_table[next_idx].value;
                ep_gc_table[next_idx].key = NULL;
                ep_gc_table[next_idx].value = NULL;
                ep_gc_table_size--;
                ep_gc_table_place(rehash_key, rehash_val);
                next_idx = (next_idx + 1) & (ep_gc_table_cap - 1);
            }
            return;
        }
        idx = (idx + 1) & (ep_gc_table_cap - 1);
    }
}



/* Register a new GC object */
static EpGCObject* ep_gc_register(void* ptr, EpObjKind kind) {
    if (!ptr) return NULL;
    pthread_mutex_lock(&ep_gc_mutex);
    ep_gc_park_if_stopped();  /* safepoint: don't allocate/touch the table mid-collection */
    EpGCObject* obj = (EpGCObject*)malloc(sizeof(EpGCObject));
    if (!obj) {
        pthread_mutex_unlock(&ep_gc_mutex);
        return NULL;
    }
    obj->kind = kind;
    obj->marked = 0;
    obj->ptr = ptr;
    obj->size = 0;
    obj->num_fields = 0;
    obj->generation = 0;
    obj->next = ep_gc_head;
    ep_gc_head = obj;
    ep_gc_count++;
    ep_gc_nursery_count++;
    ep_gc_table_insert(ptr, obj);
    pthread_mutex_unlock(&ep_gc_mutex);
    return obj;
}

/* Find GC object by pointer.
   Takes ep_gc_mutex because ep_gc_table_insert may realloc+free the table
   concurrently (from another thread's allocation). Mutator-side callers
   (write barrier, free_struct/free_map/free_list, to-string) must use this
   locking variant; code already holding the mutex (mark/sweep) calls
   ep_gc_table_get directly to avoid a non-recursive double-lock deadlock. */
static EpGCObject* ep_gc_find(void* ptr) {
    pthread_mutex_lock(&ep_gc_mutex);
    ep_gc_park_if_stopped();  /* safepoint */
    EpGCObject* obj = ep_gc_table_get(ptr);
    pthread_mutex_unlock(&ep_gc_mutex);
    return obj;
}

/* Write barrier for generational GC: tracks references from old objects (gen 1) to young objects (gen 0).
   The whole operation runs under ep_gc_mutex so the table lookups and the
   remembered-set update see a consistent table (no race with a concurrent
   resize) and use the no-lock ep_gc_table_get to avoid re-entering the lock. */
static void ep_gc_write_barrier(void* host_ptr, long long val) {
    if (val == 0) return;
    pthread_mutex_lock(&ep_gc_mutex);
    ep_gc_park_if_stopped();  /* safepoint: don't update the remembered set mid-collection */
    EpGCObject* host_obj = ep_gc_table_get(host_ptr);
    EpGCObject* val_obj = ep_gc_table_get((void*)val);
    if (host_obj && val_obj && host_obj->generation == 1 && val_obj->generation == 0) {
        /* Check if already in remembered set */
        int found = 0;
        for (long long i = 0; i < ep_gc_remembered_size; i++) {
            if (ep_gc_remembered_set[i] == (void*)val) {
                found = 1;
                break;
            }
        }
        if (!found) {
            if (ep_gc_remembered_size >= ep_gc_remembered_cap) {
                long long new_cap = ep_gc_remembered_cap == 0 ? 128 : ep_gc_remembered_cap * 2;
                void** new_set = (void**)realloc(ep_gc_remembered_set, new_cap * sizeof(void*));
                if (new_set) {
                    ep_gc_remembered_set = new_set;
                    ep_gc_remembered_cap = new_cap;
                }
            }
            if (ep_gc_remembered_size < ep_gc_remembered_cap) {
                ep_gc_remembered_set[ep_gc_remembered_size++] = (void*)val;
            }
        }
    }
    pthread_mutex_unlock(&ep_gc_mutex);
}

/* Forward declarations for list type (needed by GC mark) */
typedef struct {
    long long* data;
    long long length;
    long long capacity;
} EpList;

/* A real heap object (list/map/string) is malloc'd, so its address is far above
   the never-mapped first page. EP values that are NOT pointers — small ints,
   booleans, and JSON type-tags (2=string, 3=list, 4=object) — land in [0,4096).
   Guarding the object accessors with this turns "deref a non-pointer" (the cause
   of the read_transcripts segfault, and that whole class) into a safe null return
   instead of a daemon-killing SIGSEGV. One comparison; negligible on hot paths. */
#define EP_BADPTR(p) (((unsigned long long)(p)) < 4096ULL)

/* Mark a single object and recursively mark its children */
static void ep_gc_mark_object(void* ptr) {
    if (!ptr) return;
    /* Runs under ep_gc_mutex (held by the collector) — use the no-lock lookup. */
    EpGCObject* obj = ep_gc_table_get(ptr);
    if (!obj || obj->marked) return;
    obj->marked = 1;

    if (obj->kind == EP_OBJ_LIST) {
        EpList* list = (EpList*)ptr;
        for (long long i = 0; i < list->length; i++) {
            long long val = list->data[i];
            if (val != 0) {
                ep_gc_mark_object((void*)val);
            }
        }
    } else if (obj->kind == EP_OBJ_STRUCT) {
        long long* fields = (long long*)ptr;
        for (long long i = 0; i < obj->num_fields; i++) {
            if (fields[i] != 0) {
                ep_gc_mark_object((void*)fields[i]);
            }
        }
    } else if (obj->kind == EP_OBJ_MAP) {
        if (ep_gc_mark_map_values) ep_gc_mark_map_values(ptr);
    }
}

/* Mark a single object and recursively mark its children (only if it is Gen 0) */
static void ep_gc_mark_object_minor(void* ptr) {
    if (!ptr) return;
    /* Runs under ep_gc_mutex (held by the collector) — use the no-lock lookup. */
    EpGCObject* obj = ep_gc_table_get(ptr);
    if (!obj || obj->generation != 0 || obj->marked) return;
    obj->marked = 1;

    if (obj->kind == EP_OBJ_LIST) {
        EpList* list = (EpList*)ptr;
        for (long long i = 0; i < list->length; i++) {
            long long val = list->data[i];
            if (val != 0) {
                ep_gc_mark_object_minor((void*)val);
            }
        }
    } else if (obj->kind == EP_OBJ_STRUCT) {
        long long* fields = (long long*)ptr;
        for (long long i = 0; i < obj->num_fields; i++) {
            if (fields[i] != 0) {
                ep_gc_mark_object_minor((void*)fields[i]);
            }
        }
    } else if (obj->kind == EP_OBJ_MAP) {
        if (ep_gc_mark_map_values_minor) ep_gc_mark_map_values_minor(ptr);
    }
}

/* Conservatively scan every registered thread's C stack and mark any word that
   looks like a tracked pointer. The collector spills its own registers and
   publishes its top here; all other threads are parked at a safepoint with their
   registers spilled and top published (ep_gc_park_if_stopped), so their stacks
   are frozen. This complements the precise shadow stacks: it catches roots held
   only in registers/temporaries (e.g. a freshly allocated object not yet stored
   into a rooted slot). Non-pointer words are harmlessly ignored by ep_gc_find.

   Only run on MAJOR collections: minor collections rely on the precise shadow
   stacks plus the write barrier's remembered set (the standard generational
   approach), so they do no stack scan at all — which means there is no racy
   cross-thread stack read on the frequent minor path either. The expensive
   full-stack scan is paid only on the rarer major collection, where it pins
   any long-lived object reachable only via a register across many GCs.

   Marked no_sanitize_address: a conservative scan deliberately reads whole stack
   ranges (including ASAN redzones and out-of-frame slots), which is not a bug. */
#if defined(__SANITIZE_ADDRESS__)
# define EP_NO_ASAN __attribute__((no_sanitize_address))
#elif defined(__has_feature)
# if __has_feature(address_sanitizer)
#  define EP_NO_ASAN __attribute__((no_sanitize_address))
# endif
#endif
#ifndef EP_NO_ASAN
# define EP_NO_ASAN
#endif
EP_NO_ASAN
static void ep_gc_scan_thread_stacks(void) {
    jmp_buf _regs;
    volatile char _top_marker;
    memset(&_regs, 0, sizeof(_regs));
    setjmp(_regs);   /* spill the collector's own registers onto its stack */
    /* Publish the LOWEST of our own local addresses as this thread's live top, so the
       scanned range covers both the stack marker and the register-spill buffer whatever
       order the compiler laid them out (a missed _regs would drop a register-only root). */
    { char* _a = (char*)(void*)&_top_marker; char* _b = (char*)(void*)&_regs;
      ep_thread_local_top = (void*)((_a < _b) ? _a : _b); }
    for (int t = 0; t < ep_num_threads; t++) {
        if (!ep_thread_active[t]) continue;
        if (!ep_thread_tops[t]) continue;
        /* The published top comes from a char local, so it may not be pointer-aligned;
           mask DOWN to 8 bytes. Aligning down only widens the conservative window by a
           few harmless bytes — aligning up could skip the slot holding a live root.
           Unaligned void** dereferences are UB and produce a skewed scan window on
           strict platforms (caught by valgrind on Linux). */
        void** start = (void**)((uintptr_t)*ep_thread_tops[t] & ~(uintptr_t)7);
        void** end = (void**)ep_thread_bottoms[t];
        if (!start || !end) continue;
        if (start > end) { void** tmp = start; start = end; end = tmp; }
        for (void** cur = start; cur < end; cur++) {
            void* p = *cur;
            if (p) ep_gc_mark_object(p);
        }
    }
}

/* Mark phase: traverse from ALL threads' explicit GC roots.
   Uses the heap-allocated EpThreadGCState instead of raw __thread pointers. */
static void ep_gc_mark(void) {
    ep_gc_scan_thread_stacks();  /* conservative C-stack scan of all (parked) threads — major only */
    for (int t = 0; t < ep_num_threads; t++) {
        if (!ep_thread_active[t]) continue;
        EpThreadGCState* state = ep_thread_gc_states[t];
        if (!state) continue;
        int sp = state->sp;
        if (sp <= 0 || sp > EP_GC_MAX_ROOTS) continue;
        for (int i = 0; i < sp; i++) {
            long long* root_ptr = state->roots[i];
            if (!root_ptr) continue;
            long long val = *root_ptr;
            if (val != 0) {
                ep_gc_mark_object((void*)val);
            }
        }
    }
    /* Also mark from main thread's local root stack (thread 0 / unregistered) */
    int local_sp = ep_gc_root_sp;
    if (local_sp > EP_GC_MAX_ROOTS) local_sp = EP_GC_MAX_ROOTS;
    for (int i = 0; i < local_sp; i++) {
        long long val = *ep_gc_root_stack[i];
        if (val != 0) {
            ep_gc_mark_object((void*)val);
        }
    }
    /* Mark active tasks in the scheduler run queue */
    EpTask* task = ep_run_queue_head;
    while (task) {
        if (task->fut) {
            ep_gc_mark_object((void*)task->fut);
        }
        if (task->args && task->args_size_bytes > 0) {
            long long* ptr = (long long*)task->args;
            for (int i = 0; i < task->args_size_bytes / 8; i++) {
                long long val = ptr[i];
                if (val != 0) ep_gc_mark_object((void*)val);
            }
        }
        task = task->next;
    }
    /* Mark active tasks in the timers queue */
    EpTimer* timer = ep_timers_head;
    while (timer) {
        if (timer->task) {
            EpTask* t = timer->task;
            if (t->fut) {
                ep_gc_mark_object((void*)t->fut);
            }
            if (t->args && t->args_size_bytes > 0) {
                long long* ptr = (long long*)t->args;
                for (int i = 0; i < t->args_size_bytes / 8; i++) {
                    long long val = ptr[i];
                    if (val != 0) ep_gc_mark_object((void*)val);
                }
            }
        }
        timer = timer->next;
    }
    /* Mark top-level constant/global variables (roots outside any frame) */
    if (ep_gc_mark_globals_major) ep_gc_mark_globals_major();
    /* Scan all registered channel buffers — values in-transit have no root */
    if (ep_gc_scan_channels_major) ep_gc_scan_channels_major();
}

/* Conservatively scan the CURRENT thread's own live C stack and mark any YOUNG object it
   finds. This closes a use-after-free on the frequent minor path: a freshly-allocated
   argument temporary — e.g. the result of g() while f(g() and h()) is still evaluating
   h() — lives only on the C stack / in registers and is not yet on the precise shadow
   stack, so a minor collection triggered mid-expression would otherwise free it. Scanning
   ONLY the collecting thread's own stack is race-free (no cross-thread read) and cheap
   (one bounded stack, current thread only). Non-pointer words are harmlessly ignored by
   ep_gc_table_get; only generation-0 objects are marked. The setjmp spills register-held
   roots onto the stack so the scan can see them. */
EP_NO_ASAN
static void ep_gc_scan_own_stack_minor(void) {
    jmp_buf _regs;
    volatile char _marker;
    memset(&_regs, 0, sizeof(_regs));
    setjmp(_regs);   /* spill callee-saved registers into _regs, on the stack */
    void* bottom = ep_thread_local_bottom;
    if (!bottom) return;
    /* Start at the LOWEST of our own local addresses so the scanned range covers both
       the current stack top (_marker) and the register-spill buffer (_regs), regardless
       of how the compiler ordered these locals on the stack. Missing _regs would drop a
       root held only in a callee-saved register -> a rare use-after-free. */
    char* a = (char*)(void*)&_marker;
    char* b = (char*)(void*)&_regs;
    char* lo = (a < b) ? a : b;
    /* lo comes from a char local, so it may not be pointer-aligned; mask DOWN to 8
       bytes. Aligning down only widens the conservative window by a few harmless
       bytes — aligning up could skip the slot holding a live root. Unaligned void**
       dereferences are UB and skew the scan window on strict platforms (valgrind). */
    void** start = (void**)((uintptr_t)lo & ~(uintptr_t)7);
    void** end = (void**)bottom;
    if (start > end) { void** tmp = start; start = end; end = tmp; }
    for (void** cur = start; cur < end; cur++) {
        void* p = *cur;
        if (p) ep_gc_mark_object_minor(p);
    }
}

static void ep_gc_mark_minor(void) {
    /* Conservatively scan our OWN live C stack first, to catch freshly-allocated argument
       temporaries (only on the stack / in registers, not yet on the shadow stack) that a
       minor collection mid-expression would otherwise free. Own-thread only, so race-free. */
    ep_gc_scan_own_stack_minor();
    for (int t = 0; t < ep_num_threads; t++) {
        if (!ep_thread_active[t]) continue;
        EpThreadGCState* state = ep_thread_gc_states[t];
        if (!state) continue;
        int sp = state->sp;
        if (sp <= 0 || sp > EP_GC_MAX_ROOTS) continue;
        for (int i = 0; i < sp; i++) {
            long long* root_ptr = state->roots[i];
            if (!root_ptr) continue;
            long long val = *root_ptr;
            if (val != 0) {
                ep_gc_mark_object_minor((void*)val);
            }
        }
    }
    int local_sp = ep_gc_root_sp;
    if (local_sp > EP_GC_MAX_ROOTS) local_sp = EP_GC_MAX_ROOTS;
    for (int i = 0; i < local_sp; i++) {
        long long val = *ep_gc_root_stack[i];
        if (val != 0) {
            ep_gc_mark_object_minor((void*)val);
        }
    }
    /* Mark active tasks in the scheduler run queue for minor collection */
    EpTask* task = ep_run_queue_head;
    while (task) {
        if (task->fut) {
            ep_gc_mark_object_minor((void*)task->fut);
        }
        if (task->args && task->args_size_bytes > 0) {
            long long* ptr = (long long*)task->args;
            for (int i = 0; i < task->args_size_bytes / 8; i++) {
                long long val = ptr[i];
                if (val != 0) ep_gc_mark_object_minor((void*)val);
            }
        }
        task = task->next;
    }
    /* Mark active tasks in the timers queue for minor collection */
    EpTimer* timer = ep_timers_head;
    while (timer) {
        if (timer->task) {
            EpTask* t = timer->task;
            if (t->fut) {
                ep_gc_mark_object_minor((void*)t->fut);
            }
            if (t->args && t->args_size_bytes > 0) {
                long long* ptr = (long long*)t->args;
                for (int i = 0; i < t->args_size_bytes / 8; i++) {
                    long long val = ptr[i];
                    if (val != 0) ep_gc_mark_object_minor((void*)val);
                }
            }
        }
        timer = timer->next;
    }
    /* Also mark from the remembered set */
    for (long long i = 0; i < ep_gc_remembered_size; i++) {
        ep_gc_mark_object_minor(ep_gc_remembered_set[i]);
    }
    /* Mark top-level constant/global variables (roots outside any frame) */
    if (ep_gc_mark_globals_minor) ep_gc_mark_globals_minor();
    /* Scan all registered channel buffers — values in-transit have no root */
    if (ep_gc_scan_channels_minor) ep_gc_scan_channels_minor();
}

static void ep_gc_sweep_minor(void) {
    EpGCObject** cur = &ep_gc_head;
    while (*cur) {
        if ((*cur)->generation == 0) {
            if (!(*cur)->marked) {
                EpGCObject* garbage = *cur;
                *cur = garbage->next;
                ep_gc_table_remove(garbage->ptr);
                if (garbage->kind == EP_OBJ_LIST) {
                    EpList* list = (EpList*)garbage->ptr;
                    if (list) {
                        free(list->data);
                        free(list);
                    }
                } else if (garbage->kind == EP_OBJ_STRING) {
                    free(garbage->ptr);
                } else if (garbage->kind == EP_OBJ_STRUCT) {
                    free(garbage->ptr);
                } else if (garbage->kind == EP_OBJ_CLOSURE) {
                    free(garbage->ptr);
                } else if (garbage->kind == EP_OBJ_MAP) {
                    /* EpMap layout: entries*, capacity, size. Free entries then map. */
                    void** map_fields = (void**)garbage->ptr;
                    if (map_fields && map_fields[0]) free(map_fields[0]); /* entries */
                    free(garbage->ptr);
                }
                free(garbage);
                ep_gc_count--;
                ep_gc_nursery_count--;
            } else {
                (*cur)->marked = 0;
                (*cur)->generation = 1;
                ep_gc_nursery_count--;
                cur = &(*cur)->next;
            }
        } else {
            cur = &(*cur)->next;
        }
    }
    ep_gc_remembered_size = 0;
}

static void ep_gc_sweep_major(void) {
    EpGCObject** cur = &ep_gc_head;
    while (*cur) {
        if (!(*cur)->marked) {
            EpGCObject* garbage = *cur;
            *cur = garbage->next;
            ep_gc_table_remove(garbage->ptr);
            if (garbage->generation == 0) {
                ep_gc_nursery_count--;
            }
            if (garbage->kind == EP_OBJ_LIST) {
                EpList* list = (EpList*)garbage->ptr;
                if (list) {
                    free(list->data);
                    free(list);
                }
            } else if (garbage->kind == EP_OBJ_STRING) {
                free(garbage->ptr);
            } else if (garbage->kind == EP_OBJ_STRUCT) {
                free(garbage->ptr);
            } else if (garbage->kind == EP_OBJ_CLOSURE) {
                free(garbage->ptr);
            } else if (garbage->kind == EP_OBJ_MAP) {
                void** map_fields = (void**)garbage->ptr;
                if (map_fields && map_fields[0]) free(map_fields[0]);
                free(garbage->ptr);
            }
            free(garbage);
            ep_gc_count--;
        } else {
            (*cur)->marked = 0;
            if ((*cur)->generation == 0) {
                (*cur)->generation = 1;
                ep_gc_nursery_count--;
            }
            cur = &(*cur)->next;
        }
    }
    ep_gc_remembered_size = 0;
}

static void ep_gc_collect_minor(void) {
    if (!ep_gc_enabled) return;
    ep_gc_minor_count++;
    ep_gc_mark_minor();
    ep_gc_sweep_minor();
}

static void ep_gc_collect_major(void) {
    if (!ep_gc_enabled) return;
    ep_gc_major_count++;
    ep_gc_mark();
    ep_gc_sweep_major();
    ep_gc_threshold = ep_gc_count * 2;
    if (ep_gc_threshold < 4096) ep_gc_threshold = 4096;
}

/* Run a full GC collection — caller MUST hold ep_gc_mutex */
static void ep_gc_collect(void) {
    ep_gc_collect_major();
}

/* Maybe trigger GC if we've exceeded threshold. Also serves as the per-function
   GC safepoint: if another thread has stopped the world, park here until it's done. */
static void ep_gc_maybe_collect(void) {
    if (!ep_gc_enabled) return;  /* Early exit if GC suppressed (e.g. during channel ops) */
    /* Safepoint: lock-free fast check, then park under the lock if a collection
       is in progress on another thread. Keeps the no-GC path lock-free. */
    if (ep_gc_stop_requested) {
        pthread_mutex_lock(&ep_gc_mutex);
        ep_gc_park_if_stopped();
        pthread_mutex_unlock(&ep_gc_mutex);
    }
    /* Fast path: check thresholds before acquiring mutex.
       Counters are only incremented under the mutex, so worst case
       we miss one collection cycle — safe trade-off for avoiding
       a mutex lock/unlock (~20-50ns) on every function call. */
    if (ep_gc_nursery_count < ep_gc_nursery_threshold && ep_gc_count < ep_gc_threshold) return;
    EP_GC_UPDATE_TOP();
    pthread_mutex_lock(&ep_gc_mutex);
    /* Another thread may have started collecting between the check and the lock —
       park instead of racing it, then re-check thresholds under the lock. */
    ep_gc_park_if_stopped();
    if (ep_gc_nursery_count >= ep_gc_nursery_threshold || ep_gc_count >= ep_gc_threshold) {
        ep_gc_stop_the_world();
        if (ep_gc_nursery_count >= ep_gc_nursery_threshold) {
            ep_gc_collect_minor();
        }
        if (ep_gc_count >= ep_gc_threshold) {
            ep_gc_collect_major();
        }
        ep_gc_start_the_world();
    }
    pthread_mutex_unlock(&ep_gc_mutex);
}

/* Unregister an object (for explicit free — removes from GC tracking) */
static void ep_gc_unregister(void* ptr) {
    if (!ptr) return;
    pthread_mutex_lock(&ep_gc_mutex);
    ep_gc_park_if_stopped();  /* safepoint: don't mutate the table mid-collection */
    /* Clean up references from the remembered set to prevent dangling pointers */
    for (long long i = 0; i < ep_gc_remembered_size; ) {
        if (ep_gc_remembered_set[i] == ptr) {
            for (long long j = i; j < ep_gc_remembered_size - 1; j++) {
                ep_gc_remembered_set[j] = ep_gc_remembered_set[j + 1];
            }
            ep_gc_remembered_size--;
        } else {
            i++;
        }
    }
    ep_gc_table_remove(ptr);
    EpGCObject** cur = &ep_gc_head;
    while (*cur) {
        if ((*cur)->ptr == ptr) {
            EpGCObject* found = *cur;
            *cur = found->next;
            if (found->generation == 0) {
                ep_gc_nursery_count--;
            }
            free(found);
            ep_gc_count--;
            pthread_mutex_unlock(&ep_gc_mutex);
            return;
        }
        cur = &(*cur)->next;
    }
    pthread_mutex_unlock(&ep_gc_mutex);
}

/* Cleanup all remaining GC objects (called at program exit) */
static void ep_gc_shutdown(void) {
    ep_gc_enabled = 0;
    /* Only free GC bookkeeping structures, not the tracked objects themselves.
       The RAII auto-cleanup has already freed owned objects, and the OS will
       reclaim everything else on process exit. Attempting to free individual
       objects here causes double-free aborts when RAII and GC both track
       the same allocation. */
    EpGCObject* cur = ep_gc_head;
    while (cur) {
        EpGCObject* next = cur->next;
        free(cur);  /* free the GCObject wrapper only */
        cur = next;
    }
    ep_gc_head = NULL;
    ep_gc_count = 0;
    if (ep_gc_table) {
        free(ep_gc_table);
        ep_gc_table = NULL;
    }
    ep_gc_table_cap = 0;
    ep_gc_table_size = 0;
}

/* ========== End Garbage Collector ========== */

long long create_list(void);
long long append_list(long long list_ptr, long long value);
long long get_list(long long list_ptr, long long index);
long long set_list(long long list_ptr, long long index, long long value);
long long length_list(long long list_ptr);
long long free_list(long long list_ptr);
long long pop_list(long long list_ptr);
long long remove_list(long long list_ptr, long long index);
char* string_from_list(long long list_ptr);
long long string_to_list(const char* s);
long long string_length(const char* s);
long long display_string(const char* s);
long long screen_write(const char* s);
long long file_read(long long path_val);
long long file_write(long long path_val, long long content_val);
long long file_append(long long path_val, long long content_val);
long long file_exists(long long path_val);
long long string_contains(long long s_val, long long sub_val);
long long string_index_of(long long s_val, long long sub_val);
long long string_replace(long long s_val, long long old_val, long long new_val);
long long string_upper(long long s_val);
long long string_lower(long long s_val);
long long string_trim(long long s_val);
long long string_split(long long s_val, long long delim_val);
long long char_at(long long s_val, long long index);
long long char_from_code(long long code);
long long ep_abs(long long n);
long long json_get_string(long long json_val, long long key_val);
long long json_get_int(long long json_val, long long key_val);
long long json_get_bool(long long json_val, long long key_val);
long long ep_sha1(long long data_val);
long long ep_net_recv_bytes(long long fd, long long count);
long long ep_net_send_raw(long long fd, long long data_ptr, long long count);
long long channel_try_recv(long long chan_ptr, long long out_ptr);
long long channel_has_data(long long chan_ptr);
long long channel_select(long long channels_list, long long timeout_ms);
long long ep_auto_to_string(long long val);
long long ep_float_to_string(long long bits);

typedef struct EpChannel_ {
    long long* data;
    long long capacity;
    long long head;
    long long tail;
    long long size;
    ep_mutex_t mutex;
    ep_cond_t cond_recv;
    ep_cond_t cond_send;
} EpChannel;

/* Global channel registry — allows GC to scan values in-transit in channel buffers.
   Without this, an object sent to a channel but not yet received has NO GC root:
   the sender has popped it, the receiver hasn't pushed it, and the channel buffer
   is not scanned. The GC sweeps it → receiver gets a dangling pointer. */
#define EP_MAX_CHANNELS 1024
static EpChannel* ep_channel_registry[EP_MAX_CHANNELS];
static int ep_channel_count = 0;
static pthread_mutex_t ep_channel_registry_mutex = PTHREAD_MUTEX_INITIALIZER;

static void ep_register_channel(EpChannel* chan) {
    pthread_mutex_lock(&ep_channel_registry_mutex);
    if (ep_channel_count < EP_MAX_CHANNELS) {
        ep_channel_registry[ep_channel_count++] = chan;
    }
    pthread_mutex_unlock(&ep_channel_registry_mutex);
}

/* Channel scanning implementations — called by GC mark via function pointers.
   These are defined here (after EpChannel) so they can access struct fields. */
static void ep_gc_mark_object(void* ptr);     /* forward decl */
static void ep_gc_mark_object_minor(void* ptr); /* forward decl */

static void ep_gc_scan_channels_major_impl(void) {
    pthread_mutex_lock(&ep_channel_registry_mutex);
    for (int c = 0; c < ep_channel_count; c++) {
        EpChannel* chan = ep_channel_registry[c];
        if (!chan || chan->size <= 0) continue;
        ep_mutex_lock(&chan->mutex);
        for (long long j = 0; j < chan->size; j++) {
            long long idx = (chan->head + j) % chan->capacity;
            long long val = chan->data[idx];
            if (val != 0) ep_gc_mark_object((void*)val);
        }
        ep_mutex_unlock(&chan->mutex);
    }
    pthread_mutex_unlock(&ep_channel_registry_mutex);
}

static void ep_gc_scan_channels_minor_impl(void) {
    pthread_mutex_lock(&ep_channel_registry_mutex);
    for (int c = 0; c < ep_channel_count; c++) {
        EpChannel* chan = ep_channel_registry[c];
        if (!chan || chan->size <= 0) continue;
        ep_mutex_lock(&chan->mutex);
        for (long long j = 0; j < chan->size; j++) {
            long long idx = (chan->head + j) % chan->capacity;
            long long val = chan->data[idx];
            if (val != 0) ep_gc_mark_object_minor((void*)val);
        }
        ep_mutex_unlock(&chan->mutex);
    }
    pthread_mutex_unlock(&ep_channel_registry_mutex);
}

long long create_channel(void) {
    EpChannel* chan = malloc(sizeof(EpChannel));
    if (!chan) return 0;
    chan->capacity = 1024;
    chan->data = malloc(chan->capacity * sizeof(long long));
    chan->head = 0;
    chan->tail = 0;
    chan->size = 0;
    ep_mutex_init(&chan->mutex);
    ep_cond_init(&chan->cond_recv);
    ep_cond_init(&chan->cond_send);
    ep_register_channel(chan);
    return (long long)chan;
}

long long send_channel(long long chan_ptr, long long value) {
    EpChannel* chan = (EpChannel*)chan_ptr;
    if (!chan) return 0;
    /* Suppress GC during channel operations. The blocking condvar wait
       can interleave with GC mark/sweep on another thread, causing
       use-after-free when the GC sweeps objects that are live on a
       thread currently blocked in send/receive. Channel buffers contain
       raw long long values (not GC-tracked pointers), so suppressing
       GC here is safe. */
    int gc_was_enabled = ep_gc_enabled;
    ep_gc_enabled = 0;
    ep_mutex_lock(&chan->mutex);
    while (chan->size >= chan->capacity) {
        ep_cond_wait(&chan->cond_send, &chan->mutex);
    }
    chan->data[chan->tail] = value;
    chan->tail = (chan->tail + 1) % chan->capacity;
    chan->size += 1;
    ep_cond_signal(&chan->cond_recv);
    ep_mutex_unlock(&chan->mutex);
    ep_gc_enabled = gc_was_enabled;
    return value;
}

long long receive_channel(long long chan_ptr) {
    EpChannel* chan = (EpChannel*)chan_ptr;
    if (!chan) return 0;
    /* Suppress GC during channel receive — same rationale as send_channel */
    int gc_was_enabled = ep_gc_enabled;
    ep_gc_enabled = 0;
    ep_mutex_lock(&chan->mutex);
    while (chan->size <= 0) {
        ep_cond_wait(&chan->cond_recv, &chan->mutex);
    }
    long long value = chan->data[chan->head];
    chan->head = (chan->head + 1) % chan->capacity;
    chan->size -= 1;
    ep_cond_signal(&chan->cond_send);
    ep_mutex_unlock(&chan->mutex);
    ep_gc_enabled = gc_was_enabled;
    return value;
}

// Non-blocking receive — returns 1 if data was available, 0 if channel empty
long long channel_try_recv(long long chan_ptr, long long out_ptr) {
    EpChannel* chan = (EpChannel*)chan_ptr;
    if (!chan) return 0;
    ep_mutex_lock(&chan->mutex);
    if (chan->size <= 0) {
        ep_mutex_unlock(&chan->mutex);
        return 0;
    }
    long long value = chan->data[chan->head];
    chan->head = (chan->head + 1) % chan->capacity;
    chan->size -= 1;
    ep_cond_signal(&chan->cond_send);
    ep_mutex_unlock(&chan->mutex);
    if (out_ptr) {
        *((long long*)out_ptr) = value;
    }
    return 1;
}

// Check if channel has data without consuming it
long long channel_has_data(long long chan_ptr) {
    EpChannel* chan = (EpChannel*)chan_ptr;
    if (!chan) return 0;
    ep_mutex_lock(&chan->mutex);
    int has = (chan->size > 0) ? 1 : 0;
    ep_mutex_unlock(&chan->mutex);
    return has;
}

/* Leave a GC-safe blocking region (see channel_select). If a collection is
   in progress, wait for it to finish before running mutator code again. */
static void ep_gc_leave_blocking_region(void) {
    if (ep_thread_slot < 0) return;
    pthread_mutex_lock(&ep_gc_mutex);
    while (ep_gc_stop_requested) {
        pthread_cond_wait(&ep_gc_resume_cond, &ep_gc_mutex);
    }
    ep_gc_parked_count--;
    pthread_mutex_unlock(&ep_gc_mutex);
}

// Select: wait for any of N channels to have data, with timeout in ms
// channels_list is a list of channel pointers
// Returns index (0-based) of first ready channel, or -1 on timeout
long long channel_select(long long channels_list, long long timeout_ms) {
    EpList* list = (EpList*)channels_list;
    if (!list || list->length == 0) return -1;

#ifdef _WIN32
    ULONGLONG start_tick = GetTickCount64();
#else
    struct timespec start, now;
    clock_gettime(CLOCK_MONOTONIC, &start);
#endif

    /* A GC-safe blocking region. A thread sitting in a long select must not
       stall every stop-the-world (waking it to park costs ~0.5ms per major
       collection — allocation-heavy code on another thread pays that tens of
       thousands of times). Instead, pin this frame's roots once — spill the
       callee-saved registers into this frame and publish the frame as the
       thread's stack top — and count the thread as already parked. The
       collector then proceeds immediately and scans [this frame, stack
       bottom], a range that is frozen for the whole select: the poll loop
       below only grows the stack DOWNWARD from here (excluded from the scan)
       and allocates nothing. On every way out, ep_gc_leave_blocking_region
       waits for any in-flight collection before mutator code resumes.
       (Without any of this, the collector scans a live, mutating stack
       against a stale top, misses the channels list held in a callee-saved
       register, sweeps it, and the next poll dereferences freed memory.) */
    jmp_buf _pin_regs;
    volatile char _pin_marker;
    if (ep_thread_slot >= 0) {
        memset(&_pin_regs, 0, sizeof(_pin_regs));
        setjmp(_pin_regs);
        pthread_mutex_lock(&ep_gc_mutex);
        { char* _a = (char*)(void*)&_pin_marker; char* _b = (char*)(void*)&_pin_regs;
          ep_thread_local_top = (void*)((uintptr_t)((_a < _b) ? _a : _b) & ~(uintptr_t)7); }
        __sync_synchronize();
        ep_gc_parked_count++;
        pthread_mutex_unlock(&ep_gc_mutex);
    }

    while (1) {
        // Poll all channels
        for (long long i = 0; i < list->length; i++) {
            EpChannel* chan = (EpChannel*)list->data[i];
            if (chan) {
                ep_mutex_lock(&chan->mutex);
                if (chan->size > 0) {
                    ep_mutex_unlock(&chan->mutex);
                    ep_gc_leave_blocking_region();
                    return i;
                }
                ep_mutex_unlock(&chan->mutex);
            }
        }

        // Check timeout
        if (timeout_ms >= 0) {
#ifdef _WIN32
            ULONGLONG now_tick = GetTickCount64();
            long long elapsed = (long long)(now_tick - start_tick);
#else
            clock_gettime(CLOCK_MONOTONIC, &now);
            long long elapsed = (now.tv_sec - start.tv_sec) * 1000 + (now.tv_nsec - start.tv_nsec) / 1000000;
#endif
            if (elapsed >= timeout_ms) {
                ep_gc_leave_blocking_region();
                return -1;
            }
        }
        
        // Brief sleep to avoid busy-wait
#ifdef _WIN32
        Sleep(1);
#else
        usleep(1000); // 1ms
#endif
    }
}

#ifdef __wasm__
long long ep_net_connect(const char* host, long long port) {
    (void)host; (void)port;
    return -1;
}

long long ep_net_listen(long long port) {
    (void)port;
    return -1;
}

long long ep_net_accept(long long server_fd) {
    (void)server_fd;
    return -1;
}

long long ep_net_send(long long fd, const char* data) {
    (void)fd; (void)data;
    return 0;
}

long long ep_net_send_raw(long long fd, long long data_ptr, long long count) {
    (void)fd; (void)data_ptr; (void)count;
    return 0;
}

char* ep_net_recv(long long fd, long long max_len) {
    (void)fd; (void)max_len;
    char* empty = malloc(1);
    if (empty) empty[0] = '\0';
    return empty;
}

long long ep_net_close(long long fd) {
    (void)fd;
    return -1;
}

long long ep_sleep_ms(long long ms) {
    struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000;
    nanosleep(&ts, NULL);
    return 0;
}

long long ep_system(long long cmd) {
    (void)cmd;
    return -1;
}

long long ep_play_sound(long long path) {
    (void)path;
    return -1;
}

long long ep_dlopen(long long path) {
    (void)path;
    return 0;
}

long long ep_dlsym(long long handle, long long name) {
    (void)handle; (void)name;
    return 0;
}

long long ep_dlclose(long long handle) {
    (void)handle;
    return 0;
}
#else
long long ep_net_connect(const char* host, long long port) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) return -1;
    struct hostent* server = gethostbyname(host);
    if (!server) {
#ifdef _WIN32
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        return -1;
    }
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    memcpy(&serv_addr.sin_addr.s_addr, server->h_addr_list[0], server->h_length);
    serv_addr.sin_port = htons(port);
#ifdef _WIN32
    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        closesocket(sockfd);
        return -1;
    }
#else
    // Bounded connect: an unreachable peer must not block ~75s on the OS SYN
    // timeout (this stalled node startup). Non-blocking connect + 5s select, then
    // restore blocking mode for the rest of the session.
    int _ep_flags = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, _ep_flags | O_NONBLOCK);
    int _ep_cr = connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
    if (_ep_cr < 0) {
        if (errno != EINPROGRESS) { close(sockfd); return -1; }
        fd_set _ep_wset; FD_ZERO(&_ep_wset); FD_SET(sockfd, &_ep_wset);
        struct timeval _ep_tv; _ep_tv.tv_sec = 5; _ep_tv.tv_usec = 0;
        int _ep_sel = select(sockfd + 1, NULL, &_ep_wset, NULL, &_ep_tv);
        if (_ep_sel <= 0) { close(sockfd); return -1; } // timeout or error
        int _ep_so_err = 0; socklen_t _ep_slen = sizeof(_ep_so_err);
        if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &_ep_so_err, &_ep_slen) < 0 || _ep_so_err != 0) {
            close(sockfd);
            return -1;
        }
    }
    fcntl(sockfd, F_SETFL, _ep_flags);
#endif
    return sockfd;
}

long long ep_net_listen(long long port) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) return -1;
    int opt = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);
    if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
#ifdef _WIN32
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        return -1;
    }
    if (listen(sockfd, 10) < 0) {
#ifdef _WIN32
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        return -1;
    }
    return sockfd;
}

long long ep_net_accept(long long server_fd) {
    struct sockaddr_in cli_addr;
    socklen_t clilen = sizeof(cli_addr);
    int newsockfd = accept((int)server_fd, (struct sockaddr*)&cli_addr, &clilen);
    if (newsockfd >= 0) {
        /* Bound how long a single recv/send may block so a slow or silent
           client cannot pin a handler thread forever (slowloris). */
        struct timeval tv;
        tv.tv_sec = 30;
        tv.tv_usec = 0;
        setsockopt(newsockfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv));
        setsockopt(newsockfd, SOL_SOCKET, SO_SNDTIMEO, (const char*)&tv, sizeof(tv));
    }
    return newsockfd;
}

long long ep_net_send(long long fd, const char* data) {
    if (!data) return 0;
    return ep_net_send_raw(fd, (long long)data, (long long)strlen(data));
}

long long ep_net_send_raw(long long fd, long long data_ptr, long long count) {
    if (data_ptr == 0 || count <= 0) return 0;

    /* send() may write fewer bytes than requested. Keep sending until the
       explicit byte count is exhausted, including bytes after embedded NULs. */
    const char* data = (const char*)data_ptr;
    long long off = 0;
    while (off < count) {
#ifdef _WIN32
        int chunk = count - off > INT_MAX ? INT_MAX : (int)(count - off);
        int n = send((int)fd, data + off, chunk, 0);
        if (n < 0 && WSAGetLastError() == WSAEINTR) continue;
#else
        ssize_t n = send((int)fd, data + off, (size_t)(count - off), 0);
        if (n < 0 && errno == EINTR) continue;
#endif
        if (n <= 0) break;
        off += (long long)n;
    }
    return off;
}

char* ep_net_recv(long long fd, long long max_len) {
    char* buf = malloc(max_len + 1);
    if (!buf) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        return empty;
    }
#ifdef _WIN32
    int n = recv((int)fd, buf, (int)max_len, 0);
#else
    ssize_t n = recv((int)fd, buf, max_len, 0);
#endif
    if (n < 0) n = 0;
    buf[n] = '\0';
    return buf;
}

long long ep_net_close(long long fd) {
#ifdef _WIN32
    return closesocket((int)fd);
#else
    return close((int)fd);
#endif
}

long long ep_sleep_ms(long long ms) {
#ifdef _WIN32
    Sleep((DWORD)ms);
#else
    usleep((useconds_t)(ms * 1000));
#endif
    return 0;
}

long long ep_system(long long cmd) {
    return (long long)system((const char*)cmd);
}

long long ep_play_sound(long long path) {
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "afplay '%s' &", (const char*)path);
    return (long long)system(cmd);
}

/* ========== Dynamic Library Loading (FFI) ========== */
#ifndef _WIN32
#include <dlfcn.h>
#endif

long long ep_dlopen(long long path) {
#ifdef _WIN32
    HMODULE h = LoadLibraryA((const char*)path);
    return (long long)h;
#else
    const char* p = (const char*)path;
    void* handle = dlopen(p, RTLD_LAZY);
    return (long long)handle;
#endif
}

long long ep_dlsym(long long handle, long long name) {
#ifdef _WIN32
    FARPROC sym = GetProcAddress((HMODULE)handle, (const char*)name);
    return (long long)sym;
#else
    void* sym = dlsym((void*)handle, (const char*)name);
    return (long long)sym;
#endif
}

long long ep_dlclose(long long handle) {
#ifdef _WIN32
    return (long long)FreeLibrary((HMODULE)handle);
#else
    return (long long)dlclose((void*)handle);
#endif
}
#endif

/* Call a function pointer with 0..6 arguments.
   These are type-punned through long long — the C calling convention
   makes this work for integer and pointer arguments. */
typedef long long (*ep_fn0)(void);
typedef long long (*ep_fn1)(long long);
typedef long long (*ep_fn2)(long long, long long);
typedef long long (*ep_fn3)(long long, long long, long long);
typedef long long (*ep_fn4)(long long, long long, long long, long long);
typedef long long (*ep_fn5)(long long, long long, long long, long long, long long);
typedef long long (*ep_fn6)(long long, long long, long long, long long, long long, long long);
typedef long long (*ep_fn7)(long long, long long, long long, long long, long long, long long, long long);
typedef long long (*ep_fn8)(long long, long long, long long, long long, long long, long long, long long, long long);
typedef long long (*ep_fn9)(long long, long long, long long, long long, long long, long long, long long, long long, long long);
typedef long long (*ep_fn10)(long long, long long, long long, long long, long long, long long, long long, long long, long long, long long);

long long ep_dlcall0(long long fptr) {
    return ((ep_fn0)fptr)();
}
long long ep_dlcall1(long long fptr, long long a0) {
    return ((ep_fn1)fptr)(a0);
}
long long ep_dlcall2(long long fptr, long long a0, long long a1) {
    return ((ep_fn2)fptr)(a0, a1);
}
long long ep_dlcall3(long long fptr, long long a0, long long a1, long long a2) {
    return ((ep_fn3)fptr)(a0, a1, a2);
}
long long ep_dlcall4(long long fptr, long long a0, long long a1, long long a2, long long a3) {
    return ((ep_fn4)fptr)(a0, a1, a2, a3);
}
long long ep_dlcall5(long long fptr, long long a0, long long a1, long long a2, long long a3, long long a4) {
    return ((ep_fn5)fptr)(a0, a1, a2, a3, a4);
}
long long ep_dlcall6(long long fptr, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    return ((ep_fn6)fptr)(a0, a1, a2, a3, a4, a5);
}
long long ep_dlcall7(long long fptr, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5, long long a6) {
    return ((ep_fn7)fptr)(a0, a1, a2, a3, a4, a5, a6);
}
long long ep_dlcall8(long long fptr, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5, long long a6, long long a7) {
    return ((ep_fn8)fptr)(a0, a1, a2, a3, a4, a5, a6, a7);
}
long long ep_dlcall9(long long fptr, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5, long long a6, long long a7, long long a8) {
    return ((ep_fn9)fptr)(a0, a1, a2, a3, a4, a5, a6, a7, a8);
}
long long ep_dlcall10(long long fptr, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5, long long a6, long long a7, long long a8, long long a9) {
    return ((ep_fn10)fptr)(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9);
}

/* ========== Float FFI: ep_dlcall_f* ========== */
/* For calling C functions that accept/return double values.
   Arguments are passed as long long (bit-punned doubles).
   Return value is a double bit-punned back to long long.
   Use ep_double_to_bits() / ep_bits_to_double() to convert. */

typedef union { long long i; double f; } ep_float_bits;

static inline double ep_ll_to_double(long long v) {
    ep_float_bits u; u.i = v; return u.f;
}
static inline long long ep_double_to_ll(double v) {
    ep_float_bits u; u.f = v; return u.i;
}

/* Convert between ErnosPlain float representation and raw bits */
long long ep_double_to_bits(long long float_val) {
    /* float_val is already an EP Float stored as long long bits */
    return float_val;
}
long long ep_bits_to_double(long long bits) {
    return bits;
}

/* Float function pointer typedefs */
typedef double (*ep_ff0)(void);
typedef double (*ep_ff1)(double);
typedef double (*ep_ff2)(double, double);
typedef double (*ep_ff3)(double, double, double);
typedef double (*ep_ff4)(double, double, double, double);
typedef double (*ep_ff5)(double, double, double, double, double);
typedef double (*ep_ff6)(double, double, double, double, double, double);

/* Call functions that take doubles and return double */
long long ep_dlcall_f0(long long fptr) {
    return ep_double_to_ll(((ep_ff0)fptr)());
}
long long ep_dlcall_f1(long long fptr, long long a0) {
    return ep_double_to_ll(((ep_ff1)fptr)(ep_ll_to_double(a0)));
}
long long ep_dlcall_f2(long long fptr, long long a0, long long a1) {
    return ep_double_to_ll(((ep_ff2)fptr)(ep_ll_to_double(a0), ep_ll_to_double(a1)));
}
long long ep_dlcall_f3(long long fptr, long long a0, long long a1, long long a2) {
    return ep_double_to_ll(((ep_ff3)fptr)(ep_ll_to_double(a0), ep_ll_to_double(a1), ep_ll_to_double(a2)));
}
long long ep_dlcall_f4(long long fptr, long long a0, long long a1, long long a2, long long a3) {
    return ep_double_to_ll(((ep_ff4)fptr)(ep_ll_to_double(a0), ep_ll_to_double(a1), ep_ll_to_double(a2), ep_ll_to_double(a3)));
}
long long ep_dlcall_f5(long long fptr, long long a0, long long a1, long long a2, long long a3, long long a4) {
    return ep_double_to_ll(((ep_ff5)fptr)(ep_ll_to_double(a0), ep_ll_to_double(a1), ep_ll_to_double(a2), ep_ll_to_double(a3), ep_ll_to_double(a4)));
}
long long ep_dlcall_f6(long long fptr, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    return ep_double_to_ll(((ep_ff6)fptr)(ep_ll_to_double(a0), ep_ll_to_double(a1), ep_ll_to_double(a2), ep_ll_to_double(a3), ep_ll_to_double(a4), ep_ll_to_double(a5)));
}

/* Variants that take doubles but return int (for comparison functions etc.) */
typedef long long (*ep_fdi1)(double);
typedef long long (*ep_fdi2)(double, double);
typedef long long (*ep_fdi3)(double, double, double);

long long ep_dlcall_fd1(long long fptr, long long a0) {
    return ((ep_fdi1)fptr)(ep_ll_to_double(a0));
}
long long ep_dlcall_fd2(long long fptr, long long a0, long long a1) {
    return ((ep_fdi2)fptr)(ep_ll_to_double(a0), ep_ll_to_double(a1));
}
long long ep_dlcall_fd3(long long fptr, long long a0, long long a1, long long a2) {
    return ((ep_fdi3)fptr)(ep_ll_to_double(a0), ep_ll_to_double(a1), ep_ll_to_double(a2));
}
/* ========== End Float FFI ========== */
/* ========== End Dynamic Library Loading ========== */

unsigned long hash_string(const char* str) {
    unsigned long hash = 5381;
    int c;
    while ((c = *str++)) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

typedef struct {
    char* key;
    long long value;
    int used;
} EpMapEntry;

typedef struct {
    EpMapEntry* entries;
    long long capacity;
    long long size;
} EpMap;

/* Map value traversal for GC — walks all entries and marks values.
   Called by ep_gc_mark_object() via function pointer. */
static void ep_gc_mark_map_values_impl(void* ptr) {
    EpMap* map = (EpMap*)ptr;
    if (!map || !map->entries) return;
    for (long long i = 0; i < map->capacity; i++) {
        if (map->entries[i].used && map->entries[i].value != 0) {
            ep_gc_mark_object((void*)map->entries[i].value);
        }
        /* Also mark keys if they are heap strings */
        if (map->entries[i].used && map->entries[i].key != NULL) {
            ep_gc_mark_object((void*)map->entries[i].key);
        }
    }
}

static void ep_gc_mark_map_values_minor_impl(void* ptr) {
    EpMap* map = (EpMap*)ptr;
    if (!map || !map->entries) return;
    for (long long i = 0; i < map->capacity; i++) {
        if (map->entries[i].used && map->entries[i].value != 0) {
            ep_gc_mark_object_minor((void*)map->entries[i].value);
        }
        if (map->entries[i].used && map->entries[i].key != NULL) {
            ep_gc_mark_object_minor((void*)map->entries[i].key);
        }
    }
}

long long create_map(void) {
    EpMap* map = malloc(sizeof(EpMap));
    if (!map) return 0;
    map->capacity = 16;
    map->size = 0;
    map->entries = calloc(map->capacity, sizeof(EpMapEntry));
    if (!map->entries) {
        free(map);
        return 0;
    }
    ep_gc_register(map, EP_OBJ_MAP);
    return (long long)map;
}

static void map_resize(EpMap* map, long long new_capacity) {
    EpMapEntry* old_entries = map->entries;
    long long old_capacity = map->capacity;
    map->capacity = new_capacity;
    map->entries = calloc(new_capacity, sizeof(EpMapEntry));
    map->size = 0;
    for (long long i = 0; i < old_capacity; i++) {
        if (old_entries[i].used && old_entries[i].key != NULL) {
            char* key = old_entries[i].key;
            long long value = old_entries[i].value;
            unsigned long h = hash_string(key) % new_capacity;
            while (map->entries[h].used) {
                h = (h + 1) % new_capacity;
            }
            map->entries[h].key = key;
            map->entries[h].value = value;
            map->entries[h].used = 1;
            map->size++;
        }
    }
    free(old_entries);
}

#if defined(__ANDROID__) && defined(__aarch64__)
/* Bionic heap pointers may carry a top-byte tag and appear negative as Int.
   Preserve that tag for ownership/free; remove it only for the kernel probe.
   A pipe copies the byte (unlike /dev/null) and reports EFAULT for an integer
   that does not name readable memory. Never dereference a guessed pointer. */
static int ep_android_string_byte(long long value, unsigned char* first) {
    uintptr_t address = (uintptr_t)value & UINT64_C(0x00ffffffffffffff);
    if (address <= 0x100000 || address >= UINT64_C(0x0001000000000000)) return 0;
    int descriptors[2];
    if (pipe2(descriptors, O_CLOEXEC) != 0) return 0;
    ssize_t sent;
    do { sent = write(descriptors[1], (const void*)address, 1); }
    while (sent < 0 && errno == EINTR);
    ssize_t received = -1;
    if (sent == 1) {
        do { received = read(descriptors[0], first, 1); }
        while (received < 0 && errno == EINTR);
    }
    close(descriptors[0]);
    close(descriptors[1]);
    return received == 1;
}
#endif

/* Convert a key value to a string — handles both string pointers and integers */
static const char* ep_map_key_str(long long key_val, char* buf, int bufsize) {
    if (key_val == 0) { buf[0] = '0'; buf[1] = '\0'; return buf; }
#if defined(__ANDROID__) && defined(__aarch64__)
    unsigned char first;
    if (ep_android_string_byte(key_val, &first) &&
        ((first >= 0x20 && first < 0x7F) || first >= 0xC0 || first == 0)) {
        return (const char*)(void*)key_val;
    }
#else
    /* Check if value is in plausible pointer range for a string */
    if (key_val > 0x100000) {
        const char* p = (const char*)(void*)key_val;
        unsigned char first = (unsigned char)*p;
        if ((first >= 0x20 && first < 0x7F) || first >= 0xC0 || first == 0) {
            return p; /* valid string pointer */
        }
    }
#endif
    snprintf(buf, bufsize, "%lld", key_val);
    return buf;
}

long long map_insert(long long map_ptr, long long key_val, long long value) {
    if (EP_BADPTR(map_ptr)) return 0;
    EpMap* map = (EpMap*)map_ptr;
    char keybuf[32];
    const char* key = ep_map_key_str(key_val, keybuf, sizeof(keybuf));
    if (!map) return 0;
    if (map->size * 2 >= map->capacity) {
        map_resize(map, map->capacity * 2);
    }
    unsigned long h = hash_string(key) % map->capacity;
    while (map->entries[h].used) {
        if (strcmp(map->entries[h].key, key) == 0) {
            map->entries[h].value = value;
            ep_gc_write_barrier((void*)map_ptr, value);
            return value;
        }
        h = (h + 1) % map->capacity;
    }
    map->entries[h].key = strdup(key);
    map->entries[h].value = value;
    map->entries[h].used = 1;
    map->size++;
    ep_gc_write_barrier((void*)map_ptr, value);
    return value;
}

long long map_get_val(long long map_ptr, long long key_val) {
    if (EP_BADPTR(map_ptr)) return 0;
    EpMap* map = (EpMap*)map_ptr;
    char keybuf[32];
    const char* key = ep_map_key_str(key_val, keybuf, sizeof(keybuf));
    if (!map) return 0;
    unsigned long h = hash_string(key) % map->capacity;
    long long start_h = h;
    while (map->entries[h].used) {
        if (map->entries[h].key && strcmp(map->entries[h].key, key) == 0) {
            return map->entries[h].value;
        }
        h = (h + 1) % map->capacity;
        if (h == start_h) break;
    }
    return 0;
}

/* map_set_str: store a string value (strdup'd copy) under a string key */
long long map_set_str(long long map_ptr, long long key_val, long long str_val) {
    /* Store the string pointer as a long long value — same as map_insert */
    return map_insert(map_ptr, key_val, str_val);
}

/* map_get_str: retrieve a string value from a map (returns char* as long long) */
long long map_get_str(long long map_ptr, long long key_val) {
    /* Same as map_get_val — the stored long long IS a char* pointer */
    return map_get_val(map_ptr, key_val);
}

long long map_contains(long long map_ptr, long long key_val) {
    if (EP_BADPTR(map_ptr)) return 0;
    EpMap* map = (EpMap*)map_ptr;
    char keybuf[32];
    const char* key = ep_map_key_str(key_val, keybuf, sizeof(keybuf));
    if (!map) return 0;
    unsigned long h = hash_string(key) % map->capacity;
    long long start_h = h;
    while (map->entries[h].used) {
        if (map->entries[h].key && strcmp(map->entries[h].key, key) == 0) {
            return 1;
        }
        h = (h + 1) % map->capacity;
        if (h == start_h) break;
    }
    return 0;
}

long long map_delete(long long map_ptr, long long key_val) {
    if (EP_BADPTR(map_ptr)) return 0;
    EpMap* map = (EpMap*)map_ptr;
    char keybuf[32];
    const char* key = ep_map_key_str(key_val, keybuf, sizeof(keybuf));
    if (!map) return 0;
    unsigned long h = hash_string(key) % map->capacity;
    long long start_h = h;
    while (map->entries[h].used) {
        if (map->entries[h].key && strcmp(map->entries[h].key, key) == 0) {
            free(map->entries[h].key);
            map->entries[h].key = NULL;
            map->entries[h].value = 0;
            map->entries[h].used = 0;
            map->size--;
            long long next_h = (h + 1) % map->capacity;
            while (map->entries[next_h].used) {
                char* k = map->entries[next_h].key;
                long long v = map->entries[next_h].value;
                map->entries[next_h].key = NULL;
                map->entries[next_h].value = 0;
                map->entries[next_h].used = 0;
                map->size--;
                map_insert(map_ptr, (long long)k, v);
                free(k);
                next_h = (next_h + 1) % map->capacity;
            }
            return 1;
        }
        h = (h + 1) % map->capacity;
        if (h == start_h) break;
    }
    return 0;
}

long long map_keys(long long map_ptr) {
    EpMap* map = (EpMap*)map_ptr;
    if (!map) return (long long)create_list();
    long long list = create_list();
    for (long long i = 0; i < map->capacity; i++) {
        if (map->entries[i].used && map->entries[i].key) {
            append_list(list, (long long)strdup(map->entries[i].key));
        }
    }
    return list;
}

long long map_values(long long map_ptr) {
    EpMap* map = (EpMap*)map_ptr;
    if (!map) return (long long)create_list();
    long long list = create_list();
    for (long long i = 0; i < map->capacity; i++) {
        if (map->entries[i].used && map->entries[i].key) {
            append_list(list, map->entries[i].value);
        }
    }
    return list;
}

long long map_size(long long map_ptr) {
    EpMap* map = (EpMap*)map_ptr;
    if (!map) return 0;
    return map->size;
}

long long free_map(long long map_ptr) {
    EpMap* map = (EpMap*)map_ptr;
    if (!map) return 0;
    /* Skip if already freed (idempotent) */
    if (!ep_gc_find(map)) return 0;
    ep_gc_unregister(map);
    for (long long i = 0; i < map->capacity; i++) {
        if (map->entries[i].used && map->entries[i].key != NULL) {
            free(map->entries[i].key);
        }
    }
    free(map->entries);
    free(map);
    return 0;
}

typedef struct {
    long long* data;
    long long capacity;
    long long head;
    long long tail;
    long long size;
} EpDeque;

long long create_deque(void) {
    EpDeque* dq = malloc(sizeof(EpDeque));
    if (!dq) return 0;
    dq->capacity = 16;
    dq->size = 0;
    dq->head = 0;
    dq->tail = 0;
    dq->data = malloc(dq->capacity * sizeof(long long));
    if (!dq->data) {
        free(dq);
        return 0;
    }
    return (long long)dq;
}

static void deque_resize(EpDeque* dq, long long new_capacity) {
    long long* new_data = malloc(new_capacity * sizeof(long long));
    for (long long i = 0; i < dq->size; i++) {
        new_data[i] = dq->data[(dq->head + i) % dq->capacity];
    }
    free(dq->data);
    dq->data = new_data;
    dq->capacity = new_capacity;
    dq->head = 0;
    dq->tail = dq->size;
}

long long deque_push_back(long long dq_ptr, long long value) {
    EpDeque* dq = (EpDeque*)dq_ptr;
    if (!dq) return 0;
    if (dq->size >= dq->capacity) {
        deque_resize(dq, dq->capacity * 2);
    }
    dq->data[dq->tail] = value;
    dq->tail = (dq->tail + 1) % dq->capacity;
    dq->size++;
    return value;
}

long long deque_push_front(long long dq_ptr, long long value) {
    EpDeque* dq = (EpDeque*)dq_ptr;
    if (!dq) return 0;
    if (dq->size >= dq->capacity) {
        deque_resize(dq, dq->capacity * 2);
    }
    dq->head = (dq->head - 1 + dq->capacity) % dq->capacity;
    dq->data[dq->head] = value;
    dq->size++;
    return value;
}

long long deque_pop_back(long long dq_ptr) {
    EpDeque* dq = (EpDeque*)dq_ptr;
    if (!dq || dq->size == 0) return 0;
    dq->tail = (dq->tail - 1 + dq->capacity) % dq->capacity;
    long long value = dq->data[dq->tail];
    dq->size--;
    return value;
}

long long deque_pop_front(long long dq_ptr) {
    EpDeque* dq = (EpDeque*)dq_ptr;
    if (!dq || dq->size == 0) return 0;
    long long value = dq->data[dq->head];
    dq->head = (dq->head + 1) % dq->capacity;
    dq->size--;
    return value;
}

long long deque_length(long long dq_ptr) {
    EpDeque* dq = (EpDeque*)dq_ptr;
    if (!dq) return 0;
    return dq->size;
}

long long free_deque(long long dq_ptr) {
    EpDeque* dq = (EpDeque*)dq_ptr;
    if (!dq) return 0;
    free(dq->data);
    free(dq);
    return 0;
}

/* Filesystem Operations */
#include <dirent.h>
#include <sys/stat.h>

long long fs_scan_dir(long long path_val) {
    const char* path = (const char*)path_val;
    long long list_ptr = create_list();
    if (!path) return list_ptr;
    DIR* d = opendir(path);
    if (!d) return list_ptr;
    struct dirent* dir;
    while ((dir = readdir(d)) != NULL) {
        if (strcmp(dir->d_name, ".") == 0 || strcmp(dir->d_name, "..") == 0) {
            continue;
        }
        char* name = strdup(dir->d_name);
        append_list(list_ptr, (long long)name);
    }
    closedir(d);
    return list_ptr;
}

long long fs_copy_file(long long src_val, long long dest_val) {
    const char* src = (const char*)src_val;
    const char* dest = (const char*)dest_val;
    if (!src || !dest) return 0;
    FILE* f_src = fopen(src, "rb");
    if (!f_src) return 0;
    FILE* f_dest = fopen(dest, "wb");
    if (!f_dest) {
        fclose(f_src);
        return 0;
    }
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f_src)) > 0) {
        fwrite(buf, 1, n, f_dest);
    }
    fclose(f_src);
    fclose(f_dest);
    return 1;
}

long long fs_delete_file(long long path_val) {
    const char* path = (const char*)path_val;
    if (!path) return 0;
    return remove(path) == 0 ? 1 : 0;
}

long long fs_move_file(long long src_val, long long dest_val) {
    const char* src = (const char*)src_val;
    const char* dest = (const char*)dest_val;
    if (!src || !dest) return 0;
    return rename(src, dest) == 0 ? 1 : 0;
}

long long fs_exists(long long path_val) {
    const char* path = (const char*)path_val;
    if (!path) return 0;
    struct stat st;
    return stat(path, &st) == 0 ? 1 : 0;
}

long long fs_is_dir(long long path_val) {
    const char* path = (const char*)path_val;
    if (!path) return 0;
    struct stat st;
    if (stat(path, &st) != 0) return 0;
    return S_ISDIR(st.st_mode) ? 1 : 0;
}

long long fs_is_file(long long path_val) {
    const char* path = (const char*)path_val;
    if (!path) return 0;
    struct stat st;
    if (stat(path, &st) != 0) return 0;
    return S_ISREG(st.st_mode) ? 1 : 0;
}

long long fs_get_size(long long path_val) {
    const char* path = (const char*)path_val;
    if (!path) return 0;
    struct stat st;
    if (stat(path, &st) != 0) return 0;
    return (long long)st.st_size;
}

/* HTTP Client */
#ifdef __wasm__
long long ep_http_request(long long method_val, long long url_val, long long headers_val, long long body_val) {
    (void)method_val; (void)url_val; (void)headers_val; (void)body_val;
    return (long long)strdup("Error: HTTP request is not supported on WebAssembly");
}
#else
long long ep_http_request(long long method_val, long long url_val, long long headers_val, long long body_val) {
    const char* method = (const char*)method_val;
    const char* url = (const char*)url_val;
    const char* headers = (const char*)headers_val;
    const char* body = (const char*)body_val;
    if (!method || !url) return (long long)strdup("");
    if (strncmp(url, "http://", 7) != 0) {
        return (long long)strdup("Error: only http:// protocol supported");
    }
    const char* host_start = url + 7;
    const char* path_start = strchr(host_start, '/');
    char host[256];
    char path[1024];
    if (path_start) {
        size_t host_len = path_start - host_start;
        if (host_len >= sizeof(host)) host_len = sizeof(host) - 1;
        strncpy(host, host_start, host_len);
        host[host_len] = '\0';
        strncpy(path, path_start, sizeof(path) - 1);
        path[sizeof(path) - 1] = '\0';
    } else {
        strncpy(host, host_start, sizeof(host) - 1);
        host[sizeof(host) - 1] = '\0';
        strcpy(path, "/");
    }
    int port = 80;
    char* colon = strchr(host, ':');
    if (colon) {
        *colon = '\0';
        port = atoi(colon + 1);
    }
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) return (long long)strdup("Error: socket creation failed");
    struct hostent* server = gethostbyname(host);
    if (!server) {
        close(sockfd);
        return (long long)strdup("Error: host resolution failed");
    }
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    memcpy(&serv_addr.sin_addr.s_addr, server->h_addr_list[0], server->h_length);
    serv_addr.sin_port = htons(port);
    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        close(sockfd);
        return (long long)strdup("Error: connection failed");
    }
    char req[4096];
    size_t body_len = body ? strlen(body) : 0;
    int req_len = snprintf(req, sizeof(req),
        "%s %s HTTP/1.1\r\n"
        "Host: %s\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n"
        "%s%s"
        "\r\n",
        method, path, host, body_len, headers ? headers : "", (headers && strlen(headers) > 0 && headers[strlen(headers)-1] != '\n') ? "\r\n" : "");
    if (send(sockfd, req, req_len, 0) < 0) {
        close(sockfd);
        return (long long)strdup("Error: send failed");
    }
    if (body_len > 0) {
        if (send(sockfd, body, body_len, 0) < 0) {
            close(sockfd);
            return (long long)strdup("Error: send body failed");
        }
    }
    size_t resp_cap = 4096;
    size_t resp_len = 0;
    char* resp = malloc(resp_cap);
    if (!resp) {
        close(sockfd);
        return (long long)strdup("");
    }
    char recv_buf[4096];
    ssize_t n;
    while ((n = recv(sockfd, recv_buf, sizeof(recv_buf), 0)) > 0) {
        if (resp_len + n >= resp_cap) {
            resp_cap *= 2;
            char* new_resp = realloc(resp, resp_cap);
            if (!new_resp) {
                free(resp);
                close(sockfd);
                return (long long)strdup("Error: memory allocation failed");
            }
            resp = new_resp;
        }
        memcpy(resp + resp_len, recv_buf, n);
        resp_len += n;
    }
    resp[resp_len] = '\0';
    close(sockfd);
    // Strip HTTP headers — return only the body after \r\n\r\n
    char* http_body = strstr(resp, "\r\n\r\n");
    if (http_body) {
        http_body += 4;
        char* result = strdup(http_body);
        free(resp);
        return (long long)result;
    }
    return (long long)resp;
}
#endif

#define ROTRIGHT(word,bits) (((word) >> (bits)) | ((word) << (32-(bits))))
#define CH(x,y,z) (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x,y,z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x) (ROTRIGHT(x,2) ^ ROTRIGHT(x,13) ^ ROTRIGHT(x,22))
#define EP1(x) (ROTRIGHT(x,6) ^ ROTRIGHT(x,11) ^ ROTRIGHT(x,25))
#define SIG0(x) (ROTRIGHT(x,7) ^ ROTRIGHT(x,18) ^ ((x) >> 3))
#define SIG1(x) (ROTRIGHT(x,17) ^ ROTRIGHT(x,19) ^ ((x) >> 10))

typedef struct {
    unsigned char data[64];
    unsigned int datalen;
    unsigned long long bitlen;
    unsigned int state[8];
} EP_SHA256_CTX;

static const unsigned int sha256_k[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

void ep_sha256_transform(EP_SHA256_CTX *ctx, const unsigned char *data) {
    unsigned int a, b, c, d, e, f, g, h, i, j, t1, t2, m[64];
    for (i = 0, j = 0; i < 16; ++i, j += 4)
        m[i] = (data[j] << 24) | (data[j + 1] << 16) | (data[j + 2] << 8) | (data[j + 3]);
    for ( ; i < 64; ++i)
        m[i] = SIG1(m[i - 2]) + m[i - 7] + SIG0(m[i - 15]) + m[i - 16];
    a = ctx->state[0]; b = ctx->state[1]; c = ctx->state[2]; d = ctx->state[3];
    e = ctx->state[4]; f = ctx->state[5]; g = ctx->state[6]; h = ctx->state[7];
    for (i = 0; i < 64; ++i) {
        t1 = h + EP1(e) + CH(e,f,g) + sha256_k[i] + m[i];
        t2 = EP0(a) + MAJ(a,b,c);
        h = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    ctx->state[0] += a; ctx->state[1] += b; ctx->state[2] += c; ctx->state[3] += d;
    ctx->state[4] += e; ctx->state[5] += f; ctx->state[6] += g; ctx->state[7] += h;
}

void ep_sha256_init(EP_SHA256_CTX *ctx) {
    ctx->datalen = 0; ctx->bitlen = 0;
    ctx->state[0] = 0x6a09e667; ctx->state[1] = 0xbb67ae85; ctx->state[2] = 0x3c6ef372; ctx->state[3] = 0xa54ff53a;
    ctx->state[4] = 0x510e527f; ctx->state[5] = 0x9b05688c; ctx->state[6] = 0x1f83d9ab; ctx->state[7] = 0x5be0cd19;
}

void ep_sha256_update(EP_SHA256_CTX *ctx, const unsigned char *data, size_t len) {
    for (size_t i = 0; i < len; ++i) {
        ctx->data[ctx->datalen] = data[i];
        ctx->datalen++;
        if (ctx->datalen == 64) {
            ep_sha256_transform(ctx, ctx->data);
            ctx->bitlen += 512;
            ctx->datalen = 0;
        }
    }
}

void ep_sha256_final(EP_SHA256_CTX *ctx, unsigned char *hash) {
    unsigned int i = ctx->datalen;
    if (ctx->datalen < 56) {
        ctx->data[i++] = 0x80;
        while (i < 56) ctx->data[i++] = 0x00;
    } else {
        ctx->data[i++] = 0x80;
        while (i < 64) ctx->data[i++] = 0x00;
        ep_sha256_transform(ctx, ctx->data);
        memset(ctx->data, 0, 56);
    }
    ctx->bitlen += ctx->datalen * 8;
    ctx->data[63] = ctx->bitlen; ctx->data[62] = ctx->bitlen >> 8;
    ctx->data[61] = ctx->bitlen >> 16; ctx->data[60] = ctx->bitlen >> 24;
    ctx->data[59] = ctx->bitlen >> 32; ctx->data[58] = ctx->bitlen >> 40;
    ctx->data[57] = ctx->bitlen >> 48; ctx->data[56] = ctx->bitlen >> 56;
    ep_sha256_transform(ctx, ctx->data);
    for (i = 0; i < 4; ++i) {
        hash[i]      = (ctx->state[0] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 4]  = (ctx->state[1] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 8]  = (ctx->state[2] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 12] = (ctx->state[3] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 16] = (ctx->state[4] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 20] = (ctx->state[5] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 24] = (ctx->state[6] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 28] = (ctx->state[7] >> (24 - i * 8)) & 0x000000ff;
    }
}

char* ep_sha256(const char* s) {
    if (!s) s = "";
    EP_SHA256_CTX ctx;
    ep_sha256_init(&ctx);
    ep_sha256_update(&ctx, (const unsigned char*)s, strlen(s));
    unsigned char hash[32];
    ep_sha256_final(&ctx, hash);
    char* result = malloc(65);
    if (result) {
        for (int i = 0; i < 32; i++) {
            snprintf(result + (i * 2), 3, "%02x", hash[i]);
        }
        result[64] = '\0';
    }
    return result;
}

/* RFC 2104 HMAC-SHA256. Operates on raw bytes with explicit lengths (binary
   safe), so keys/messages containing NUL bytes hash correctly. Returns a
   malloc'd 64-char lowercase hex string. */
long long ep_hmac_sha256(long long key_ptr, long long key_len, long long msg_ptr, long long msg_len) {
    const unsigned char* key = (const unsigned char*)key_ptr;
    const unsigned char* msg = (const unsigned char*)msg_ptr;
    size_t klen = (size_t)key_len;
    size_t mlen = (size_t)msg_len;

    unsigned char k0[64];
    memset(k0, 0, sizeof(k0));
    if (klen > 64) {
        /* Keys longer than the block size are replaced by their hash. */
        EP_SHA256_CTX kc;
        ep_sha256_init(&kc);
        ep_sha256_update(&kc, key ? key : (const unsigned char*)"", klen);
        unsigned char kh[32];
        ep_sha256_final(&kc, kh);
        memcpy(k0, kh, 32);
    } else if (key) {
        memcpy(k0, key, klen);
    }

    unsigned char ipad[64], opad[64];
    for (int i = 0; i < 64; i++) {
        ipad[i] = k0[i] ^ 0x36;
        opad[i] = k0[i] ^ 0x5c;
    }

    /* inner = H((K0 ^ ipad) || message) */
    EP_SHA256_CTX ic;
    ep_sha256_init(&ic);
    ep_sha256_update(&ic, ipad, 64);
    if (msg && mlen) ep_sha256_update(&ic, msg, mlen);
    unsigned char inner[32];
    ep_sha256_final(&ic, inner);

    /* mac = H((K0 ^ opad) || inner) */
    EP_SHA256_CTX oc;
    ep_sha256_init(&oc);
    ep_sha256_update(&oc, opad, 64);
    ep_sha256_update(&oc, inner, 32);
    unsigned char mac[32];
    ep_sha256_final(&oc, mac);

    char* out = (char*)malloc(65);
    if (out) {
        for (int i = 0; i < 32; i++) {
            snprintf(out + (i * 2), 3, "%02x", mac[i]);
        }
        out[64] = '\0';
    }
    return (long long)out;
}

typedef struct {
    unsigned int count[2];
    unsigned int state[4];
    unsigned char buffer[64];
} EP_MD5_CTX;

#define F(x,y,z) (((x) & (y)) | (~(x) & (z)))
#define G(x,y,z) (((x) & (z)) | ((y) & ~(z)))
#define H(x,y,z) ((x) ^ (y) ^ (z))
#define I(x,y,z) ((y) ^ ((x) | ~(z)))
#define ROTATE_LEFT(x,n) (((x) << (n)) | ((x) >> (32-(n))))

#define FF(a,b,c,d,x,s,ac) { \
    (a) += F((b),(c),(d)) + (x) + (ac); \
    (a) = ROTATE_LEFT((a),(s)); \
    (a) += (b); \
}
#define GG(a,b,c,d,x,s,ac) { \
    (a) += G((b),(c),(d)) + (x) + (ac); \
    (a) = ROTATE_LEFT((a),(s)); \
    (a) += (b); \
}
#define HH(a,b,c,d,x,s,ac) { \
    (a) += H((b),(c),(d)) + (x) + (ac); \
    (a) = ROTATE_LEFT((a),(s)); \
    (a) += (b); \
}
#define II(a,b,c,d,x,s,ac) { \
    (a) += I((b),(c),(d)) + (x) + (ac); \
    (a) = ROTATE_LEFT((a),(s)); \
    (a) += (b); \
}

void ep_md5_init(EP_MD5_CTX *ctx) {
    ctx->count[0] = ctx->count[1] = 0;
    ctx->state[0] = 0x67452301;
    ctx->state[1] = 0xefcdab89;
    ctx->state[2] = 0x98badcfe;
    ctx->state[3] = 0x10325476;
}

void ep_md5_transform(unsigned int state[4], const unsigned char block[64]) {
    unsigned int a = state[0], b = state[1], c = state[2], d = state[3], x[16];
    for (int i = 0, j = 0; i < 16; i++, j += 4)
        x[i] = (block[j]) | (block[j+1] << 8) | (block[j+2] << 16) | (block[j+3] << 24);

    FF(a, b, c, d, x[0], 7, 0xd76aa478); FF(d, a, b, c, x[1], 12, 0xe8c7b756); FF(c, d, a, b, x[2], 17, 0x242070db); FF(b, c, d, a, x[3], 22, 0xc1bdceee);
    FF(a, b, c, d, x[4], 7, 0xf57c0faf); FF(d, a, b, c, x[5], 12, 0x4787c62a); FF(c, d, a, b, x[6], 17, 0xa8304613); FF(b, c, d, a, x[7], 22, 0xfd469501);
    FF(a, b, c, d, x[8], 7, 0x698098d8); FF(d, a, b, c, x[9], 12, 0x8b44f7af); FF(c, d, a, b, x[10], 17, 0xffff5bb1); FF(b, c, d, a, x[11], 22, 0x895cd7be);
    FF(a, b, c, d, x[12], 7, 0x6b901122); FF(d, a, b, c, x[13], 12, 0xfd987193); FF(c, d, a, b, x[14], 17, 0xa679438e); FF(b, c, d, a, x[15], 22, 0x49b40821);

    GG(a, b, c, d, x[1], 5, 0xf61e2562); GG(d, a, b, c, x[6], 9, 0xc040b340); GG(c, d, a, b, x[11], 14, 0x265e5a51); GG(b, c, d, a, x[0], 20, 0xe9b6c7aa);
    GG(a, b, c, d, x[5], 5, 0xd62f105d); GG(d, a, b, c, x[10], 9, 0x02441453); GG(c, d, a, b, x[15], 14, 0xd8a1e681); GG(b, c, d, a, x[4], 20, 0xe7d3fbc8);
    GG(a, b, c, d, x[9], 5, 0x21e1cde6); GG(d, a, b, c, x[14], 9, 0xc33707d6); GG(c, d, a, b, x[3], 14, 0xf4d50d87); GG(b, c, d, a, x[8], 20, 0x455a14ed);
    GG(a, b, c, d, x[13], 5, 0xa9e3e905); GG(d, a, b, c, x[2], 9, 0xfcefa3f8); GG(c, d, a, b, x[7], 14, 0x676f02d9); GG(b, c, d, a, x[12], 20, 0x8d2a4c8a);

    HH(a, b, c, d, x[5], 4, 0xfffa3942); HH(d, a, b, c, x[8], 11, 0x8771f681); HH(c, d, a, b, x[11], 16, 0x6d9d6122); HH(b, c, d, a, x[14], 23, 0xfde5380c);
    HH(a, b, c, d, x[1], 4, 0xa4beea44); HH(d, a, b, c, x[4], 11, 0x4bdecfa9); HH(c, d, a, b, x[7], 16, 0xf6bb4b60); HH(b, c, d, a, x[10], 23, 0xbebfbc70);
    HH(a, b, c, d, x[13], 4, 0x289b7ec6); HH(d, a, b, c, x[0], 11, 0xeaa127fa); HH(c, d, a, b, x[3], 16, 0xd4ef3085); HH(b, c, d, a, x[6], 23, 0x04881d05);
    HH(a, b, c, d, x[9], 4, 0xd9d4d039); HH(d, a, b, c, x[12], 11, 0xe6db99e5); HH(c, d, a, b, x[15], 16, 0x1fa27cf8); HH(b, c, d, a, x[2], 23, 0xc4ac5665);

    II(a, b, c, d, x[0], 6, 0xf4292244); II(d, a, b, c, x[7], 10, 0x432aff97); II(c, d, a, b, x[14], 15, 0xab9423a7); II(b, c, d, a, x[5], 21, 0xfc93a039);
    II(a, b, c, d, x[12], 6, 0x655b59c3); II(d, a, b, c, x[3], 10, 0x8f0ccc92); II(c, d, a, b, x[10], 15, 0xffeff47d); II(b, c, d, a, x[1], 21, 0x85845dd1);
    II(a, b, c, d, x[8], 6, 0x6fa87e4f); II(d, a, b, c, x[15], 10, 0xfe2ce6e0); II(c, d, a, b, x[6], 15, 0xa3014314); II(b, c, d, a, x[13], 21, 0x4e0811a1);
    II(a, b, c, d, x[4], 6, 0xf7537e82); II(d, a, b, c, x[11], 10, 0xbd3af235); II(c, d, a, b, x[2], 15, 0x2ad7d2bb); II(b, c, d, a, x[9], 21, 0xeb86d391);

    state[0] += a; state[1] += b; state[2] += c; state[3] += d;
}

void ep_md5_update(EP_MD5_CTX *ctx, const unsigned char *input, size_t input_len) {
    unsigned int i = 0, index = (ctx->count[0] >> 3) & 0x3F, part_len = 64 - index;
    ctx->count[0] += input_len << 3;
    if (ctx->count[0] < (input_len << 3)) ctx->count[1]++;
    ctx->count[1] += input_len >> 29;
    if (input_len >= part_len) {
        memcpy(&ctx->buffer[index], input, part_len);
        ep_md5_transform(ctx->state, ctx->buffer);
        for (i = part_len; i + 63 < input_len; i += 64)
            ep_md5_transform(ctx->state, &input[i]);
        index = 0;
    }
    memcpy(&ctx->buffer[index], &input[i], input_len - i);
}

void ep_md5_final(EP_MD5_CTX *ctx, unsigned char digest[16]) {
    unsigned char bits[8];
    bits[0] = ctx->count[0]; bits[1] = ctx->count[0] >> 8; bits[2] = ctx->count[0] >> 16; bits[3] = ctx->count[0] >> 24;
    bits[4] = ctx->count[1]; bits[5] = ctx->count[1] >> 8; bits[6] = ctx->count[1] >> 16; bits[7] = ctx->count[1] >> 24;
    unsigned int index = (ctx->count[0] >> 3) & 0x3F, pad_len = (index < 56) ? (56 - index) : (120 - index);
    unsigned char padding[64];
    memset(padding, 0, 64); padding[0] = 0x80;
    ep_md5_update(ctx, padding, pad_len);
    ep_md5_update(ctx, bits, 8);
    for (int i = 0; i < 4; i++) {
        digest[i*4]     = ctx->state[i];
        digest[i*4 + 1] = ctx->state[i] >> 8;
        digest[i*4 + 2] = ctx->state[i] >> 16;
        digest[i*4 + 3] = ctx->state[i] >> 24;
    }
}

char* ep_md5(const char* s) {
    if (!s) s = "";
    EP_MD5_CTX ctx;
    ep_md5_init(&ctx);
    ep_md5_update(&ctx, (const unsigned char*)s, strlen(s));
    unsigned char hash[16];
    ep_md5_final(&ctx, hash);
    char* result = malloc(33);
    if (result) {
        for (int i = 0; i < 16; i++) {
            snprintf(result + (i * 2), 3, "%02x", hash[i]);
        }
        result[32] = '\0';
    }
    return result;
}

char* read_file_content(const char* filepath) {
    char mode[3];
    mode[0] = 'r';
    mode[1] = 'b';
    mode[2] = '\0';
    FILE* f = fopen(filepath, mode);
    if (!f) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        ep_gc_register(empty, EP_OBJ_STRING);
        return empty;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* buf = malloc(size + 1);
    if (!buf) {
        fclose(f);
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        ep_gc_register(empty, EP_OBJ_STRING);
        return empty;
    }
    size_t read_bytes = fread(buf, 1, size, f);
    buf[read_bytes] = '\0';
    fclose(f);
    ep_gc_register(buf, EP_OBJ_STRING);
    return buf;
}

long long string_length(const char* s) {
    if (!s) return 0;
    return strlen(s);
}

long long get_character(const char* s, long long index) {
    if (!s) return 0;
    long long len = strlen(s);
    if (index < 0 || index >= len) return 0;
    return (unsigned char)s[index];
}

long long create_list(void) {
    EpList* list = malloc(sizeof(EpList));
    if (!list) return 0;
    list->capacity = 4;
    list->length = 0;
    list->data = malloc(list->capacity * sizeof(long long));
    ep_gc_register(list, EP_OBJ_LIST);
    return (long long)list;
}

long long get_list_data_ptr(long long list_ptr) {
    if (EP_BADPTR(list_ptr)) return 0;
    EpList* list = (EpList*)list_ptr;
    if (!list) return 0;
    return (long long)list->data;
}

long long append_list(long long list_ptr, long long value) {
    if (EP_BADPTR(list_ptr)) return 0;
    EpList* list = (EpList*)list_ptr;
    if (!list) return 0;
    if (list->length >= list->capacity) {
        list->capacity *= 2;
        list->data = realloc(list->data, list->capacity * sizeof(long long));
    }
    list->data[list->length] = value;
    list->length += 1;
    ep_gc_write_barrier((void*)list_ptr, value);
    return value;
}

long long get_list(long long list_ptr, long long index) {
    if (EP_BADPTR(list_ptr)) return 0;
    EpList* list = (EpList*)list_ptr;
    if (index < 0 || index >= list->length) return 0;
    return list->data[index];
}

long long set_list(long long list_ptr, long long index, long long value) {
    if (EP_BADPTR(list_ptr)) return 0;
    EpList* list = (EpList*)list_ptr;
    if (index < 0 || index >= list->length) return 0;
    list->data[index] = value;
    ep_gc_write_barrier((void*)list_ptr, value);
    return value;
}

long long length_list(long long list_ptr) {
    if (EP_BADPTR(list_ptr)) return 0;
    EpList* list = (EpList*)list_ptr;
    return list->length;
}

long long free_list(long long list_ptr) {
    EpList* list = (EpList*)list_ptr;
    if (!list) return 0;
    /* Skip if already freed (idempotent) */
    if (!ep_gc_find(list)) return 0;
    ep_gc_unregister(list);
    free(list->data);
    free(list);
    return 0;
}

static int sqlite_list_callback(void* arg, int argc, char** argv, char** col_names) {
    EpList* rows = (EpList*)arg;
    EpList* row = (EpList*)create_list();
    for (int i = 0; i < argc; i++) {
        char* val = argv[i] ? strdup(argv[i]) : strdup("");
        append_list((long long)row, (long long)val);
    }
    append_list((long long)rows, (long long)row);
    return 0;
}

long long sqlite_get_callback_ptr(long long dummy) {
    return (long long)sqlite_list_callback;
}

/* SQLite type-safe wrappers — marshal between int and long long */
#ifdef EP_HAS_SQLITE
typedef struct sqlite3 sqlite3;
int sqlite3_open(const char*, sqlite3**);
int sqlite3_close(sqlite3*);
int sqlite3_exec(sqlite3*, const char*, int(*)(void*,int,char**,char**), void*, char**);

long long ep_sqlite3_open(long long filename, long long db_ptr) {
    sqlite3* db = NULL;
    int rc = sqlite3_open((const char*)filename, &db);
    if (rc == 0 && db_ptr != 0) {
        *((long long*)db_ptr) = (long long)db;
    }
    return (long long)rc;
}

long long ep_sqlite3_close(long long db) {
    return (long long)sqlite3_close((sqlite3*)db);
}

long long ep_sqlite3_exec(long long db, long long sql, long long callback, long long cb_arg, long long errmsg_ptr) {
    return (long long)sqlite3_exec((sqlite3*)db, (const char*)sql,
        (int(*)(void*,int,char**,char**))(callback),
        (void*)cb_arg, (char**)errmsg_ptr);
}

/* Prepared-statement API for parameterized queries (defeats SQL injection). */
typedef struct sqlite3_stmt sqlite3_stmt;
int sqlite3_prepare_v2(sqlite3*, const char*, int, sqlite3_stmt**, const char**);
int sqlite3_bind_text(sqlite3_stmt*, int, const char*, int, void(*)(void*));
int sqlite3_bind_int64(sqlite3_stmt*, int, long long);
int sqlite3_step(sqlite3_stmt*);
int sqlite3_column_count(sqlite3_stmt*);
const unsigned char* sqlite3_column_text(sqlite3_stmt*, int);
long long sqlite3_column_int64(sqlite3_stmt*, int);
int sqlite3_finalize(sqlite3_stmt*);

long long ep_sqlite3_prepare_v2(long long db, long long sql) {
    sqlite3_stmt* stmt = NULL;
    int rc = sqlite3_prepare_v2((sqlite3*)db, (const char*)sql, -1, &stmt, NULL);
    if (rc != 0) return 0;
    return (long long)stmt;
}

long long ep_sqlite3_bind_text(long long stmt, long long idx, long long value) {
    /* SQLITE_TRANSIENT ((void*)-1): sqlite copies the bound string. The value is
       a bound parameter, never concatenated into SQL — this is the safe path. */
    return (long long)sqlite3_bind_text((sqlite3_stmt*)stmt, (int)idx,
        (const char*)value, -1, (void(*)(void*))(intptr_t)-1);
}

long long ep_sqlite3_bind_int(long long stmt, long long idx, long long value) {
    return (long long)sqlite3_bind_int64((sqlite3_stmt*)stmt, (int)idx, value);
}

long long ep_sqlite3_step(long long stmt) {
    return (long long)sqlite3_step((sqlite3_stmt*)stmt);
}

long long ep_sqlite3_column_count(long long stmt) {
    return (long long)sqlite3_column_count((sqlite3_stmt*)stmt);
}

long long ep_sqlite3_column_text(long long stmt, long long col) {
    const unsigned char* t = sqlite3_column_text((sqlite3_stmt*)stmt, (int)col);
    char* copy = (!t) ? strdup("") : strdup((const char*)t);
    /* Register the copy with the GC so it is reclaimed (not leaked) and so
       ep_auto_to_string recognizes it as a string deterministically via
       ep_gc_find, rather than relying on the memory-probe heuristic. */
    if (copy) ep_gc_register(copy, EP_OBJ_STRING);
    return (long long)copy;
}

long long ep_sqlite3_column_int(long long stmt, long long col) {
    return sqlite3_column_int64((sqlite3_stmt*)stmt, (int)col);
}

long long ep_sqlite3_finalize(long long stmt) {
    return (long long)sqlite3_finalize((sqlite3_stmt*)stmt);
}
#endif /* EP_HAS_SQLITE */

int ep_argc = 0;
char** ep_argv = NULL;

void init_ep_args(int argc, char** argv) {
    ep_argc = argc;
    ep_argv = argv;
    ep_gc_register_thread((void*)&argc);
    /* Wire up channel scanning for GC (defined after EpChannel struct) */
    ep_gc_scan_channels_major = ep_gc_scan_channels_major_impl;
    ep_gc_scan_channels_minor = ep_gc_scan_channels_minor_impl;
    /* Wire up map value traversal for GC (defined after EpMap struct) */
    ep_gc_mark_map_values = ep_gc_mark_map_values_impl;
    ep_gc_mark_map_values_minor = ep_gc_mark_map_values_minor_impl;
}

long long get_argument_count(void) {
    return ep_argc;
}

const char* get_argument(long long index) {
    if (index < 0 || index >= ep_argc) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        return empty;
    }
    return ep_argv[index];
}

long long write_file_content(const char* filepath, const char* content) {
    char mode[3];
    mode[0] = 'w';
    mode[1] = 'b';
    mode[2] = '\0';
    FILE* f = fopen(filepath, mode);
    if (!f) return 0;
    size_t len = strlen(content);
    size_t written = fwrite(content, 1, len, f);
    fclose(f);
    return written == len ? 1 : 0;
}

long long run_command(const char* command) {
    if (!command) return -1;
    return system(command);
}

char* substring(const char* s, long long start, long long len) {
    if (!s) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        ep_gc_register(empty, EP_OBJ_STRING);
        return empty;
    }
    long long total_len = strlen(s);
    if (start < 0 || start >= total_len || len <= 0) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        ep_gc_register(empty, EP_OBJ_STRING);
        return empty;
    }
    if (start + len > total_len) {
        len = total_len - start;
    }
    char* sub = malloc(len + 1);
    if (!sub) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        ep_gc_register(empty, EP_OBJ_STRING);
        return empty;
    }
    strncpy(sub, s + start, len);
    sub[len] = '\0';
    ep_gc_register(sub, EP_OBJ_STRING);
    return sub;
}

char* string_from_list(long long list_ptr) {
    EpList* list = (EpList*)list_ptr;
    if (!list) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        ep_gc_register(empty, EP_OBJ_STRING);
        return empty;
    }
    char* s = malloc(list->length + 1);
    if (!s) {
        char* empty = malloc(1);
        if (empty) empty[0] = '\0';
        ep_gc_register(empty, EP_OBJ_STRING);
        return empty;
    }
    for (long long i = 0; i < list->length; i++) {
        s[i] = (char)list->data[i];
    }
    s[list->length] = '\0';
    ep_gc_register(s, EP_OBJ_STRING);
    return s;
}

// Inverse of string_from_list: convert a string to a list of its byte values in
// a single O(n) pass (one strlen + one copy). This lets callers iterate a string
// in O(n) total via O(1) get_list, instead of O(n) get_character per index
// (which is O(n^2) over the whole string).
long long string_to_list(const char* s) {
    EpList* list = malloc(sizeof(EpList));
    if (!list) return 0;
    long long len = s ? (long long)strlen(s) : 0;
    list->capacity = len > 0 ? len : 4;
    list->length = len;
    list->data = malloc(list->capacity * sizeof(long long));
    if (!list->data) {
        list->capacity = 0;
        list->length = 0;
        ep_gc_register(list, EP_OBJ_LIST);
        return (long long)list;
    }
    for (long long i = 0; i < len; i++) {
        list->data[i] = (unsigned char)s[i];
    }
    ep_gc_register(list, EP_OBJ_LIST);
    return (long long)list;
}

long long pop_list(long long list_ptr) {
    if (EP_BADPTR(list_ptr)) return 0;
    EpList* list = (EpList*)list_ptr;
    if (!list || list->length <= 0) return 0;
    list->length -= 1;
    return list->data[list->length];
}

long long remove_list(long long list_ptr, long long index) {
    if (EP_BADPTR(list_ptr)) return 0;
    EpList* list = (EpList*)list_ptr;
    if (!list || index < 0 || index >= list->length) return 0;
    long long removed = list->data[index];
    for (long long i = index; i < list->length - 1; i++) {
        list->data[i] = list->data[i + 1];
    }
    list->length -= 1;
    return removed;
}

long long display_string(const char* s) {
    if (s) puts(s);
    return 0;
}

/* Write text with NO trailing newline, and flush at once — for drawing to
   the screen where every byte's position matters (cursor moves, escape
   codes, a full-screen frame). puts()/display_string would append a
   newline and scroll a full-height frame; this does not. */
long long screen_write(const char* s) {
    if (s) {
        fputs(s, stdout);
        fflush(stdout);
    }
    return 0;
}

/* ========== File System Runtime ========== */
#include <sys/stat.h>
#ifdef _WIN32
  #include <io.h>
  #include <direct.h>
  #define mkdir(p, m) _mkdir(p)
  #define rmdir _rmdir
  #define getcwd _getcwd
  #define popen _popen
  #define pclose _pclose
  #define getpid _getpid
  #define setenv(k, v, o) _putenv_s(k, v)
  /* Minimal dirent polyfill for Windows */
  #include <windows.h>
  typedef struct { char d_name[260]; } ep_dirent;
  typedef struct { HANDLE hFind; WIN32_FIND_DATAA data; int first; } EP_DIR;
  static EP_DIR* ep_opendir(const char* p) {
      EP_DIR* d = (EP_DIR*)malloc(sizeof(EP_DIR));
      char buf[270]; snprintf(buf, sizeof(buf), "%s\\*", p);
      d->hFind = FindFirstFileA(buf, &d->data);
      d->first = 1;
      return (d->hFind == INVALID_HANDLE_VALUE) ? (free(d), (EP_DIR*)NULL) : d;
  }
  static ep_dirent* ep_readdir(EP_DIR* d) {
      static ep_dirent ent;
      if (d->first) { d->first = 0; strcpy(ent.d_name, d->data.cFileName); return &ent; }
      if (!FindNextFileA(d->hFind, &d->data)) return NULL;
      strcpy(ent.d_name, d->data.cFileName); return &ent;
  }
  static void ep_closedir(EP_DIR* d) { FindClose(d->hFind); free(d); }
  #define DIR EP_DIR
  #define dirent ep_dirent
  #define opendir ep_opendir
  #define readdir ep_readdir
  #define closedir ep_closedir
#else
  #include <dirent.h>
  #include <unistd.h>
#endif

long long ep_read_file(long long path_ptr) {
    const char* path = (const char*)path_ptr;
    FILE* f = fopen(path, "rb");
    if (!f) return (long long)"";
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* buf = (char*)malloc(size + 1);
    fread(buf, 1, size, f);
    buf[size] = '\0';
    fclose(f);
    return (long long)buf;
}

long long ep_write_file(long long path_ptr, long long content_ptr) {
    const char* path = (const char*)path_ptr;
    const char* content = (const char*)content_ptr;
    FILE* f = fopen(path, "wb");
    if (!f) return 0;
    fputs(content, f);
    fclose(f);
    return 1;
}

long long ep_append_file(long long path_ptr, long long content_ptr) {
    const char* path = (const char*)path_ptr;
    const char* content = (const char*)content_ptr;
    FILE* f = fopen(path, "ab");
    if (!f) return 0;
    fputs(content, f);
    fclose(f);
    return 1;
}

long long ep_file_exists(long long path_ptr) {
    const char* path = (const char*)path_ptr;
    struct stat st;
    return stat(path, &st) == 0 ? 1 : 0;
}

long long ep_is_directory(long long path_ptr) {
    const char* path = (const char*)path_ptr;
    struct stat st;
    if (stat(path, &st) != 0) return 0;
    return S_ISDIR(st.st_mode) ? 1 : 0;
}

long long ep_file_size(long long path_ptr) {
    const char* path = (const char*)path_ptr;
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    return (long long)st.st_size;
}

long long ep_list_directory(long long path_ptr) {
    const char* path = (const char*)path_ptr;
    DIR* dir = opendir(path);
    if (!dir) return (long long)create_list();
    long long list = create_list();
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.' && (entry->d_name[1] == '\0' || 
            (entry->d_name[1] == '.' && entry->d_name[2] == '\0'))) continue;
        char* name = strdup(entry->d_name);
        append_list(list, (long long)name);
    }
    closedir(dir);
    return list;
}

long long ep_create_directory(long long path_ptr) {
    const char* path = (const char*)path_ptr;
    return mkdir(path, 0755) == 0 ? 1 : 0;
}

long long ep_remove_file(long long path_ptr) {
    const char* path = (const char*)path_ptr;
    return remove(path) == 0 ? 1 : 0;
}

long long ep_remove_directory(long long path_ptr) {
    const char* path = (const char*)path_ptr;
    return rmdir(path) == 0 ? 1 : 0;
}

long long ep_rename_file(long long old_ptr, long long new_ptr) {
    return rename((const char*)old_ptr, (const char*)new_ptr) == 0 ? 1 : 0;
}

long long ep_copy_file(long long src_ptr, long long dst_ptr) {
    const char* src = (const char*)src_ptr;
    const char* dst = (const char*)dst_ptr;
    FILE* fin = fopen(src, "rb");
    if (!fin) return 0;
    FILE* fout = fopen(dst, "wb");
    if (!fout) { fclose(fin); return 0; }
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), fin)) > 0) {
        fwrite(buf, 1, n, fout);
    }
    fclose(fin);
    fclose(fout);
    return 1;
}

/* ========== Date/Time Runtime ========== */
#include <time.h>
#include <sys/time.h>

long long ep_time_now_ms(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000LL + (long long)tv.tv_usec / 1000LL;
}

long long ep_time_now_sec(void) {
    return (long long)time(NULL);
}


long long ep_time_year(long long ts) {
    time_t t = (time_t)ts;
    struct tm* tm = localtime(&t);
    return tm ? tm->tm_year + 1900 : 0;
}

long long ep_time_month(long long ts) {
    time_t t = (time_t)ts;
    struct tm* tm = localtime(&t);
    return tm ? tm->tm_mon + 1 : 0;
}

long long ep_time_day(long long ts) {
    time_t t = (time_t)ts;
    struct tm* tm = localtime(&t);
    return tm ? tm->tm_mday : 0;
}

long long ep_time_hour(long long ts) {
    time_t t = (time_t)ts;
    struct tm* tm = localtime(&t);
    return tm ? tm->tm_hour : 0;
}

long long ep_time_minute(long long ts) {
    time_t t = (time_t)ts;
    struct tm* tm = localtime(&t);
    return tm ? tm->tm_min : 0;
}

long long ep_time_second(long long ts) {
    time_t t = (time_t)ts;
    struct tm* tm = localtime(&t);
    return tm ? tm->tm_sec : 0;
}

long long ep_time_weekday(long long ts) {
    time_t t = (time_t)ts;
    struct tm* tm = localtime(&t);
    return tm ? tm->tm_wday : 0;
}

long long ep_format_time(long long ts, long long fmt_ptr) {
    time_t t = (time_t)ts;
    struct tm* tm = localtime(&t);
    if (!tm) return (long long)"";
    char* buf = (char*)malloc(256);
    strftime(buf, 256, (const char*)fmt_ptr, tm);
    return (long long)buf;
}

/* ========== OS Runtime ========== */

long long ep_getenv(long long name_ptr) {
    const char* val = getenv((const char*)name_ptr);
    return val ? (long long)val : (long long)"";
}

long long ep_setenv(long long name_ptr, long long val_ptr) {
    return setenv((const char*)name_ptr, (const char*)val_ptr, 1) == 0 ? 1 : 0;
}

long long ep_get_cwd(void) {
    char* buf = (char*)malloc(4096);
    if (getcwd(buf, 4096)) return (long long)buf;
    free(buf);
    return (long long)"";
}

long long ep_os_name(void) {
    #if defined(__APPLE__)
    return (long long)"macos";
    #elif defined(__linux__)
    return (long long)"linux";
    #elif defined(_WIN32)
    return (long long)"windows";
    #else
    return (long long)"unknown";
    #endif
}

long long ep_arch_name(void) {
    #if defined(__aarch64__) || defined(__arm64__)
    return (long long)"arm64";
    #elif defined(__x86_64__)
    return (long long)"x86_64";
    #elif defined(__i386__)
    return (long long)"x86";
    #else
    return (long long)"unknown";
    #endif
}

long long ep_exit(long long code) {
    exit((int)code);
    return 0;
}

long long ep_get_pid(void) {
    return (long long)getpid();
}

long long ep_get_home_dir(void) {
    const char* home = getenv("HOME");
    return home ? (long long)home : (long long)"";
}

#ifdef __wasm__
long long ep_run_command(long long cmd_ptr) {
    (void)cmd_ptr;
    return (long long)"Error: running external commands is not supported on WebAssembly";
}
#else
long long ep_run_command(long long cmd_ptr) {
    const char* cmd = (const char*)cmd_ptr;
    FILE* fp = popen(cmd, "r");
    if (!fp) return (long long)"";
    char* result = (char*)malloc(65536);
    size_t total = 0;
    char buf[4096];
    while (fgets(buf, sizeof(buf), fp)) {
        size_t len = strlen(buf);
        memcpy(result + total, buf, len);
        total += len;
    }
    result[total] = '\0';
    pclose(fp);
    return (long long)result;
}
#endif

/* ========== HashMap helpers ========== */

long long ep_hash_string(long long s_ptr) {
    const char* s = (const char*)s_ptr;
    if (!s) return 0;
    unsigned long long hash = 5381;
    int c;
    while ((c = *s++)) {
        hash = ((hash << 5) + hash) + c;
    }
    return (long long)hash;
}

long long ep_str_equals(long long a_ptr, long long b_ptr) {
    if (a_ptr == b_ptr) return 1;
    if (!a_ptr || !b_ptr) return 0;
    /* If either value looks like a small integer (not a valid heap pointer),
       fall back to integer comparison — strcmp would segfault. */
    if ((unsigned long long)a_ptr < 4096ULL || (unsigned long long)b_ptr < 4096ULL) return 0;
    return strcmp((const char*)a_ptr, (const char*)b_ptr) == 0 ? 1 : 0;
}

/* ========== Sync Primitives ========== */

#ifdef _WIN32
long long ep_mutex_create(void) {
    CRITICAL_SECTION* m = (CRITICAL_SECTION*)malloc(sizeof(CRITICAL_SECTION));
    InitializeCriticalSection(m);
    return (long long)m;
}
long long ep_mutex_lock_fn(long long m) {
    EnterCriticalSection((CRITICAL_SECTION*)m);
    return 1;
}
long long ep_mutex_unlock_fn(long long m) {
    LeaveCriticalSection((CRITICAL_SECTION*)m);
    return 1;
}
long long ep_mutex_trylock(long long m) {
    return TryEnterCriticalSection((CRITICAL_SECTION*)m) ? 1 : 0;
}
long long ep_mutex_destroy(long long m) {
    DeleteCriticalSection((CRITICAL_SECTION*)m);
    free((void*)m);
    return 0;
}
#else
long long ep_mutex_create(void) {
    pthread_mutex_t* m = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(m, NULL);
    return (long long)m;
}

long long ep_mutex_lock_fn(long long m) {
    return pthread_mutex_lock((pthread_mutex_t*)m) == 0 ? 1 : 0;
}

long long ep_mutex_unlock_fn(long long m) {
    return pthread_mutex_unlock((pthread_mutex_t*)m) == 0 ? 1 : 0;
}

long long ep_mutex_trylock(long long m) {
    return pthread_mutex_trylock((pthread_mutex_t*)m) == 0 ? 1 : 0;
}

long long ep_mutex_destroy(long long m) {
    pthread_mutex_destroy((pthread_mutex_t*)m);
    free((void*)m);
    return 0;
}
#endif

#ifdef _WIN32
long long ep_rwlock_create(void) {
    SRWLOCK* rwl = (SRWLOCK*)malloc(sizeof(SRWLOCK));
    InitializeSRWLock(rwl);
    return (long long)rwl;
}
long long ep_rwlock_read_lock(long long rwl) {
    AcquireSRWLockShared((SRWLOCK*)rwl);
    return 1;
}
long long ep_rwlock_write_lock(long long rwl) {
    AcquireSRWLockExclusive((SRWLOCK*)rwl);
    return 1;
}
long long ep_rwlock_unlock(long long rwl) {
    /* SRWLOCK does not have a single "unlock" — we try exclusive first.
       In practice the caller should know which lock was taken.
       ReleaseSRWLockExclusive on a shared lock is undefined, but
       the runtime guarantees matched lock/unlock pairs. We default
       to releasing the exclusive lock; shared unlock is handled
       by pairing read_lock -> read_unlock if needed later. */
    ReleaseSRWLockExclusive((SRWLOCK*)rwl);
    return 1;
}
long long ep_rwlock_destroy(long long rwl) {
    /* SRWLOCK has no destroy */
    free((void*)rwl);
    return 0;
}
#else
long long ep_rwlock_create(void) {
    pthread_rwlock_t* rwl = (pthread_rwlock_t*)malloc(sizeof(pthread_rwlock_t));
    pthread_rwlock_init(rwl, NULL);
    return (long long)rwl;
}

long long ep_rwlock_read_lock(long long rwl) {
    return pthread_rwlock_rdlock((pthread_rwlock_t*)rwl) == 0 ? 1 : 0;
}

long long ep_rwlock_write_lock(long long rwl) {
    return pthread_rwlock_wrlock((pthread_rwlock_t*)rwl) == 0 ? 1 : 0;
}

long long ep_rwlock_unlock(long long rwl) {
    return pthread_rwlock_unlock((pthread_rwlock_t*)rwl) == 0 ? 1 : 0;
}

long long ep_rwlock_destroy(long long rwl) {
    pthread_rwlock_destroy((pthread_rwlock_t*)rwl);
    free((void*)rwl);
    return 0;
}
#endif

#ifdef _MSC_VER
long long ep_atomic_create(long long initial) {
    volatile long long* a = (volatile long long*)malloc(sizeof(long long));
    InterlockedExchange64(a, initial);
    return (long long)a;
}
long long ep_atomic_load(long long a) {
    return InterlockedCompareExchange64((volatile long long*)a, 0, 0);
}
long long ep_atomic_store(long long a, long long value) {
    InterlockedExchange64((volatile long long*)a, value);
    return value;
}
long long ep_atomic_add(long long a, long long delta) {
    return InterlockedExchangeAdd64((volatile long long*)a, delta);
}
long long ep_atomic_sub(long long a, long long delta) {
    return InterlockedExchangeAdd64((volatile long long*)a, -delta);
}
long long ep_atomic_cas(long long a, long long expected, long long desired) {
    long long old = InterlockedCompareExchange64((volatile long long*)a, desired, expected);
    return (old == expected) ? 1 : 0;
}
#else
long long ep_atomic_create(long long initial) {
    long long* a = (long long*)malloc(sizeof(long long));
    __atomic_store_n(a, initial, __ATOMIC_SEQ_CST);
    return (long long)a;
}

long long ep_atomic_load(long long a) {
    return __atomic_load_n((long long*)a, __ATOMIC_SEQ_CST);
}

long long ep_atomic_store(long long a, long long value) {
    __atomic_store_n((long long*)a, value, __ATOMIC_SEQ_CST);
    return value;
}

long long ep_atomic_add(long long a, long long delta) {
    return __atomic_fetch_add((long long*)a, delta, __ATOMIC_SEQ_CST);
}

long long ep_atomic_sub(long long a, long long delta) {
    return __atomic_fetch_sub((long long*)a, delta, __ATOMIC_SEQ_CST);
}

long long ep_atomic_cas(long long a, long long expected, long long desired) {
    long long exp = expected;
    return __atomic_compare_exchange_n((long long*)a, &exp, desired, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST) ? 1 : 0;
}
#endif

/* Barrier — portable polyfill (macOS lacks pthread_barrier_t) */
typedef struct {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    unsigned count;
    unsigned target;
    unsigned generation;
} EpBarrier;

long long ep_barrier_create(long long count) {
    EpBarrier* b = (EpBarrier*)malloc(sizeof(EpBarrier));
    pthread_mutex_init(&b->mutex, NULL);
    pthread_cond_init(&b->cond, NULL);
    b->count = 0;
    b->target = (unsigned)count;
    b->generation = 0;
    return (long long)b;
}

long long ep_barrier_wait(long long bp) {
    EpBarrier* b = (EpBarrier*)bp;
    pthread_mutex_lock(&b->mutex);
    unsigned gen = b->generation;
    b->count++;
    if (b->count >= b->target) {
        b->count = 0;
        b->generation++;
        pthread_cond_broadcast(&b->cond);
        pthread_mutex_unlock(&b->mutex);
        return 1; /* serial thread */
    }
    while (gen == b->generation) {
        pthread_cond_wait(&b->cond, &b->mutex);
    }
    pthread_mutex_unlock(&b->mutex);
    return 0;
}

long long ep_barrier_destroy(long long bp) {
    EpBarrier* b = (EpBarrier*)bp;
    pthread_mutex_destroy(&b->mutex);
    pthread_cond_destroy(&b->cond);
    free(b);
    return 0;
}

/* Semaphore via mutex+condvar (portable) */
typedef struct {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    long long value;
} EpSemaphore;

long long ep_semaphore_create(long long initial) {
    EpSemaphore* s = (EpSemaphore*)malloc(sizeof(EpSemaphore));
    pthread_mutex_init(&s->mutex, NULL);
    pthread_cond_init(&s->cond, NULL);
    s->value = initial;
    return (long long)s;
}

long long ep_semaphore_wait(long long sp) {
    EpSemaphore* s = (EpSemaphore*)sp;
    pthread_mutex_lock(&s->mutex);
    while (s->value <= 0) {
        pthread_cond_wait(&s->cond, &s->mutex);
    }
    s->value--;
    pthread_mutex_unlock(&s->mutex);
    return 1;
}

long long ep_semaphore_post(long long sp) {
    EpSemaphore* s = (EpSemaphore*)sp;
    pthread_mutex_lock(&s->mutex);
    s->value++;
    pthread_cond_signal(&s->cond);
    pthread_mutex_unlock(&s->mutex);
    return 1;
}

long long ep_semaphore_trywait(long long sp) {
    EpSemaphore* s = (EpSemaphore*)sp;
    pthread_mutex_lock(&s->mutex);
    if (s->value > 0) {
        s->value--;
        pthread_mutex_unlock(&s->mutex);
        return 1;
    }
    pthread_mutex_unlock(&s->mutex);
    return 0;
}

long long ep_semaphore_destroy(long long sp) {
    EpSemaphore* s = (EpSemaphore*)sp;
    pthread_mutex_destroy(&s->mutex);
    pthread_cond_destroy(&s->cond);
    free(s);
    return 0;
}

long long ep_condvar_create(void) {
    pthread_cond_t* cv = (pthread_cond_t*)malloc(sizeof(pthread_cond_t));
    pthread_cond_init(cv, NULL);
    return (long long)cv;
}

long long ep_condvar_wait(long long cv, long long m) {
    return pthread_cond_wait((pthread_cond_t*)cv, (pthread_mutex_t*)m) == 0 ? 1 : 0;
}

long long ep_condvar_signal(long long cv) {
    return pthread_cond_signal((pthread_cond_t*)cv) == 0 ? 1 : 0;
}

long long ep_condvar_broadcast(long long cv) {
    return pthread_cond_broadcast((pthread_cond_t*)cv) == 0 ? 1 : 0;
}

long long ep_condvar_destroy(long long cv) {
    pthread_cond_destroy((pthread_cond_t*)cv);
    free((void*)cv);
    return 0;
}

/* ========== Regex (simple stub — delegates to POSIX regex) ========== */
#include <regex.h>

long long ep_regex_match(long long pattern_ptr, long long text_ptr) {
    regex_t regex;
    const char* pattern = (const char*)pattern_ptr;
    const char* text = (const char*)text_ptr;
    int ret = regcomp(&regex, pattern, REG_EXTENDED | REG_NOSUB);
    if (ret) return 0;
    ret = regexec(&regex, text, 0, NULL, 0);
    regfree(&regex);
    return ret == 0 ? 1 : 0;
}

long long ep_regex_find(long long pattern_ptr, long long text_ptr) {
    regex_t regex;
    regmatch_t match;
    const char* pattern = (const char*)pattern_ptr;
    const char* text = (const char*)text_ptr;
    int ret = regcomp(&regex, pattern, REG_EXTENDED);
    if (ret) return (long long)"";
    ret = regexec(&regex, text, 1, &match, 0);
    if (ret != 0) { regfree(&regex); return (long long)""; }
    int len = match.rm_eo - match.rm_so;
    char* result = (char*)malloc(len + 1);
    memcpy(result, text + match.rm_so, len);
    result[len] = '\0';
    regfree(&regex);
    return (long long)result;
}

long long ep_regex_find_all(long long pattern_ptr, long long text_ptr) {
    regex_t regex;
    regmatch_t match;
    const char* pattern = (const char*)pattern_ptr;
    const char* text = (const char*)text_ptr;
    long long list = create_list();
    int ret = regcomp(&regex, pattern, REG_EXTENDED);
    if (ret) return list;
    const char* cursor = text;
    while (regexec(&regex, cursor, 1, &match, 0) == 0) {
        int len = match.rm_eo - match.rm_so;
        char* result = (char*)malloc(len + 1);
        memcpy(result, cursor + match.rm_so, len);
        result[len] = '\0';
        append_list(list, (long long)result);
        cursor += match.rm_eo;
        if (match.rm_eo == 0) break;
    }
    regfree(&regex);
    return list;
}

long long ep_regex_replace(long long pattern_ptr, long long text_ptr, long long repl_ptr) {
    /* Simple single-replacement via regex */
    regex_t regex;
    regmatch_t match;
    const char* pattern = (const char*)pattern_ptr;
    const char* text = (const char*)text_ptr;
    const char* repl = (const char*)repl_ptr;
    int ret = regcomp(&regex, pattern, REG_EXTENDED);
    if (ret) return text_ptr;
    ret = regexec(&regex, text, 1, &match, 0);
    if (ret != 0) { regfree(&regex); return text_ptr; }
    size_t tlen = strlen(text);
    size_t rlen = strlen(repl);
    size_t new_len = tlen - (match.rm_eo - match.rm_so) + rlen;
    char* result = (char*)malloc(new_len + 1);
    memcpy(result, text, match.rm_so);
    memcpy(result + match.rm_so, repl, rlen);
    memcpy(result + match.rm_so + rlen, text + match.rm_eo, tlen - match.rm_eo);
    result[new_len] = '\0';
    regfree(&regex);
    return (long long)result;
}

long long ep_regex_split(long long pattern_ptr, long long text_ptr) {
    long long list = create_list();
    /* Simple split: find matches and split around them */
    regex_t regex;
    regmatch_t match;
    const char* pattern = (const char*)pattern_ptr;
    const char* text = (const char*)text_ptr;
    int ret = regcomp(&regex, pattern, REG_EXTENDED);
    if (ret) {
        append_list(list, text_ptr);
        return list;
    }
    const char* cursor = text;
    while (regexec(&regex, cursor, 1, &match, 0) == 0) {
        int len = match.rm_so;
        char* part = (char*)malloc(len + 1);
        memcpy(part, cursor, len);
        part[len] = '\0';
        append_list(list, (long long)part);
        cursor += match.rm_eo;
        if (match.rm_eo == 0) break;
    }
    char* rest = strdup(cursor);
    append_list(list, (long long)rest);
    regfree(&regex);
    return list;
}

/* ========== Base64 ========== */
static const char b64_table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

long long ep_base64_encode(long long data_ptr) {
    const unsigned char* data = (const unsigned char*)data_ptr;
    size_t len = strlen((const char*)data);
    size_t out_len = 4 * ((len + 2) / 3);
    char* out = (char*)malloc(out_len + 1);
    size_t i, j = 0;
    for (i = 0; i < len; i += 3) {
        unsigned int n = data[i] << 16;
        if (i + 1 < len) n |= data[i+1] << 8;
        if (i + 2 < len) n |= data[i+2];
        out[j++] = b64_table[(n >> 18) & 63];
        out[j++] = b64_table[(n >> 12) & 63];
        out[j++] = (i + 1 < len) ? b64_table[(n >> 6) & 63] : '=';
        out[j++] = (i + 2 < len) ? b64_table[n & 63] : '=';
    }
    out[j] = '\0';
    return (long long)out;
}

long long ep_uuid_v4(void) {
    char* uuid = (char*)malloc(37);
    unsigned char bytes[16];
    ep_secure_random_bytes(bytes, 16);
    bytes[6] = (bytes[6] & 0x0F) | 0x40;
    bytes[8] = (bytes[8] & 0x3F) | 0x80;
    snprintf(uuid, 37, "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
        bytes[0], bytes[1], bytes[2], bytes[3],
        bytes[4], bytes[5], bytes[6], bytes[7],
        bytes[8], bytes[9], bytes[10], bytes[11],
        bytes[12], bytes[13], bytes[14], bytes[15]);
    return (long long)uuid;
}

long long file_read(long long path_val) {
    const char* path = (const char*)path_val;
    if (!path) return (long long)strdup("");
    FILE* f = fopen(path, "rb");
    if (!f) return (long long)strdup("");
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* buf = malloc(size + 1);
    if (!buf) { fclose(f); return (long long)strdup(""); }
    fread(buf, 1, size, f);
    buf[size] = '\0';
    fclose(f);
    ep_gc_register(buf, EP_OBJ_STRING);
    return (long long)buf;
}

long long file_write(long long path_val, long long content_val) {
    const char* path = (const char*)path_val;
    const char* content = (const char*)content_val;
    if (!path || !content) return 0;
    FILE* f = fopen(path, "wb");
    if (!f) return 0;
    size_t len = strlen(content);
    fwrite(content, 1, len, f);
    fclose(f);
    return 1;
}

long long file_append(long long path_val, long long content_val) {
    const char* path = (const char*)path_val;
    const char* content = (const char*)content_val;
    if (!path || !content) return 0;
    FILE* f = fopen(path, "ab");
    if (!f) return 0;
    size_t len = strlen(content);
    fwrite(content, 1, len, f);
    fclose(f);
    return 1;
}

long long file_exists(long long path_val) {
    const char* path = (const char*)path_val;
    if (!path) return 0;
    FILE* f = fopen(path, "r");
    if (f) { fclose(f); return 1; }
    return 0;
}

long long string_contains(long long s_val, long long sub_val) {
    const char* s = (const char*)s_val;
    const char* sub = (const char*)sub_val;
    if (!s || !sub) return 0;
    return strstr(s, sub) != NULL ? 1 : 0;
}

long long string_index_of(long long s_val, long long sub_val) {
    const char* s = (const char*)s_val;
    const char* sub = (const char*)sub_val;
    if (!s || !sub) return -1;
    const char* found = strstr(s, sub);
    if (!found) return -1;
    return (long long)(found - s);
}

long long string_replace(long long s_val, long long old_val, long long new_val) {
    const char* s = (const char*)s_val;
    const char* old_str = (const char*)old_val;
    const char* new_str = (const char*)new_val;
    if (!s || !old_str || !new_str) return (long long)strdup(s ? s : "");
    size_t old_len = strlen(old_str);
    size_t new_len = strlen(new_str);
    if (old_len == 0) return (long long)strdup(s);
    int count = 0;
    const char* p = s;
    while ((p = strstr(p, old_str)) != NULL) { count++; p += old_len; }
    size_t result_len = strlen(s) + count * (new_len - old_len);
    char* result = malloc(result_len + 1);
    if (!result) return (long long)strdup(s);
    char* dst = result;
    p = s;
    while (*p) {
        if (strncmp(p, old_str, old_len) == 0) {
            memcpy(dst, new_str, new_len);
            dst += new_len;
            p += old_len;
        } else {
            *dst++ = *p++;
        }
    }
    *dst = '\0';
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

/* ========== Additional String Functions ========== */
#include <ctype.h>

long long string_upper(long long s_val) {
    const char* s = (const char*)s_val;
    if (!s) return (long long)strdup("");
    long long len = strlen(s);
    char* result = malloc(len + 1);
    for (long long i = 0; i < len; i++) result[i] = toupper((unsigned char)s[i]);
    result[len] = '\0';
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

long long string_lower(long long s_val) {
    const char* s = (const char*)s_val;
    if (!s) return (long long)strdup("");
    long long len = strlen(s);
    char* result = malloc(len + 1);
    for (long long i = 0; i < len; i++) result[i] = tolower((unsigned char)s[i]);
    result[len] = '\0';
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

long long string_trim(long long s_val) {
    const char* s = (const char*)s_val;
    if (!s) return (long long)strdup("");
    while (*s && isspace((unsigned char)*s)) s++;
    long long len = strlen(s);
    while (len > 0 && isspace((unsigned char)s[len - 1])) len--;
    char* result = malloc(len + 1);
    memcpy(result, s, len);
    result[len] = '\0';
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

long long string_split(long long s_val, long long delim_val) {
    const char* s = (const char*)s_val;
    const char* delim = (const char*)delim_val;
    if (!s || !delim) return create_list();
    long long list = create_list();
    long long dlen = strlen(delim);
    if (dlen == 0) { append_list(list, s_val); return list; }
    const char* p = s;
    while (1) {
        const char* found = strstr(p, delim);
        long long partlen = found ? (found - p) : (long long)strlen(p);
        char* part = malloc(partlen + 1);
        memcpy(part, p, partlen);
        part[partlen] = '\0';
        ep_gc_register(part, EP_OBJ_STRING);
        append_list(list, (long long)part);
        if (!found) break;
        p = found + dlen;
    }
    return list;
}

long long char_at(long long s_val, long long index) {
    const char* s = (const char*)s_val;
    if (!s || index < 0 || index >= (long long)strlen(s)) return 0;
    return (unsigned char)s[index];
}

long long char_from_code(long long code) {
    char* result = malloc(2);
    result[0] = (char)code;
    result[1] = '\0';
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

long long ep_abs(long long n) {
    return n < 0 ? -n : n;
}

// Auto-convert any value to string for string interpolation
long long ep_auto_to_string(long long val) {
    // If the value is 0, return "0"
    if (val == 0) return (long long)strdup("0");
    // Check if val is a GC-tracked string (heap-allocated)
    EpGCObject* obj = ep_gc_find((void*)val);
    if (obj && obj->kind == EP_OBJ_STRING) {
        return val; // It's a known string pointer
    }
    // Check if val is a static string literal (in .rodata/.data segment)
    // These aren't GC-tracked but ARE valid pointers. Use a safe probe:
    // only dereference if the address is in a readable memory page.
#if defined(__ANDROID__) && defined(__aarch64__)
    unsigned char first;
    if (ep_android_string_byte(val, &first) &&
        ((first >= 0x20 && first <= 0x7E) || (first >= 0xC0 && first <= 0xFD) ||
         first == '\n' || first == '\t' || first == '\r' || first == 0)) {
        return val;
    }
#else
    if (val > 0x100000) {
#if defined(_WIN32)
        // Windows: use VirtualQuery to safely probe pointer validity
        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQuery((void*)val, &mbi, sizeof(mbi)) && mbi.State == MEM_COMMIT && !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD))) {
            const char* p = (const char*)(void*)val;
            unsigned char first = (unsigned char)*p;
            if ((first >= 0x20 && first <= 0x7E) || (first >= 0xC0 && first <= 0xFD) || first == '\n' || first == '\t' || first == '\r' || first == 0) {
                return val; // Readable memory, looks like a string
            }
        }
#elif defined(__APPLE__)
        // macOS: use vm_read_overwrite to safely probe
        char probe;
        vm_size_t sz = 1;
        kern_return_t kr = vm_read_overwrite(mach_task_self(), (mach_vm_address_t)val, 1, (mach_vm_address_t)&probe, &sz);
        if (kr == KERN_SUCCESS) {
            unsigned char first = (unsigned char)probe;
            if ((first >= 0x20 && first <= 0x7E) || (first >= 0xC0 && first <= 0xFD) || first == '\n' || first == '\t' || first == '\r' || first == 0) {
                return val; // Readable memory, looks like a string
            }
        }
#else
        // Linux: use write() to /dev/null as a safe pointer probe
        // write() returns -1 with EFAULT for invalid pointers, no signal
        int devnull = open("/dev/null", 1); // O_WRONLY
        if (devnull >= 0) {
            ssize_t r = write(devnull, (const void*)val, 1);
            close(devnull);
            if (r == 1) {
                const char* p = (const char*)(void*)val;
                unsigned char first = (unsigned char)*p;
                if ((first >= 0x20 && first <= 0x7E) || (first >= 0xC0 && first <= 0xFD) || first == '\n' || first == '\t' || first == '\r' || first == 0) {
                    return val;
                }
            }
        }
#endif
    }
#endif
    // Otherwise, convert integer to string
    char* buf = (char*)malloc(32);
    snprintf(buf, 32, "%lld", val);
    ep_gc_register(buf, EP_OBJ_STRING);
    return (long long)buf;
}

/* Format a Float (double bits carried in a long long) as a string. F-string
   interpolation routes Float-typed expressions here: ep_auto_to_string cannot
   know the bits are a double and would print them as a huge integer. Uses the
   same %.15g format as `display` so a float reads identically both ways. */
long long ep_float_to_string(long long bits) {
    double d;
    memcpy(&d, &bits, sizeof(double));
    char* buf = (char*)malloc(40);
    snprintf(buf, 40, "%.15g", d);
    ep_gc_register(buf, EP_OBJ_STRING);
    return (long long)buf;
}

long long ep_random_int(long long min, long long max) {
    if (max <= min) return min;
    /* Draw from the OS CSPRNG with rejection sampling to avoid modulo bias. */
    unsigned long long range = (unsigned long long)(max - min) + 1ULL;
    unsigned long long limit = UINT64_MAX - (UINT64_MAX % range);
    unsigned long long r;
    do {
        ep_secure_random_bytes((unsigned char*)&r, sizeof(r));
    } while (r >= limit);
    return min + (long long)(r % range);
}

// JSON built-in functions
static const char* json_skip_ws(const char* p) {
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    return p;
}

static const char* json_skip_value(const char* p) {
    p = json_skip_ws(p);
    if (*p == '"') {
        p++;
        while (*p && *p != '"') { if (*p == '\\') p++; p++; }
        if (*p == '"') p++;
    } else if (*p == '{') {
        int depth = 1; p++;
        while (*p && depth > 0) {
            if (*p == '"') { p++; while (*p && *p != '"') { if (*p == '\\') p++; p++; } if (*p) p++; }
            else if (*p == '{') { depth++; p++; }
            else if (*p == '}') { depth--; p++; }
            else p++;
        }
    } else if (*p == '[') {
        int depth = 1; p++;
        while (*p && depth > 0) {
            if (*p == '"') { p++; while (*p && *p != '"') { if (*p == '\\') p++; p++; } if (*p) p++; }
            else if (*p == '[') { depth++; p++; }
            else if (*p == ']') { depth--; p++; }
            else p++;
        }
    } else {
        while (*p && *p != ',' && *p != '}' && *p != ']' && *p != ' ' && *p != '\n') p++;
    }
    return p;
}

static const char* json_find_key(const char* json, const char* key) {
    const char* p = json_skip_ws(json);
    if (*p != '{') return NULL;
    p++;
    while (*p) {
        p = json_skip_ws(p);
        if (*p == '}') return NULL;
        if (*p != '"') return NULL;
        p++;
        const char* ks = p;
        while (*p && *p != '"') { if (*p == '\\') p++; p++; }
        size_t klen = p - ks;
        if (*p == '"') p++;
        p = json_skip_ws(p);
        if (*p == ':') p++;
        p = json_skip_ws(p);
        if (klen == strlen(key) && strncmp(ks, key, klen) == 0) {
            return p;
        }
        p = json_skip_value(p);
        p = json_skip_ws(p);
        if (*p == ',') p++;
    }
    return NULL;
}

long long json_get_string(long long json_val, long long key_val) {
    const char* json = (const char*)json_val;
    const char* key = (const char*)key_val;
    if (!json || !key) return (long long)strdup("");
    const char* val = json_find_key(json, key);
    if (!val || *val != '"') return (long long)strdup("");
    val++;
    const char* end = val;
    while (*end && *end != '"') { if (*end == '\\') end++; end++; }
    size_t len = end - val;
    char* result = (char*)malloc(len + 1);
    // Handle escape sequences
    size_t di = 0;
    const char* si = val;
    while (si < end) {
        if (*si == '\\' && si + 1 < end) {
            si++;
            switch (*si) {
                case 'n': result[di++] = '\n'; break;
                case 't': result[di++] = '\t'; break;
                case 'r': result[di++] = '\r'; break;
                case '"': result[di++] = '"'; break;
                case '\\': result[di++] = '\\'; break;
                default: result[di++] = *si; break;
            }
        } else {
            result[di++] = *si;
        }
        si++;
    }
    result[di] = '\0';
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

long long json_get_int(long long json_val, long long key_val) {
    const char* json = (const char*)json_val;
    const char* key = (const char*)key_val;
    if (!json || !key) return 0;
    const char* val = json_find_key(json, key);
    if (!val) return 0;
    return atoll(val);
}

long long json_get_bool(long long json_val, long long key_val) {
    const char* json = (const char*)json_val;
    const char* key = (const char*)key_val;
    if (!json || !key) return 0;
    const char* val = json_find_key(json, key);
    if (!val) return 0;
    if (strncmp(val, "true", 4) == 0) return 1;
    return 0;
}

// SHA-1 implementation (RFC 3174) for WebSocket handshake
static unsigned int sha1_left_rotate(unsigned int x, int n) {
    return (x << n) | (x >> (32 - n));
}

long long ep_sha1(long long data_val) {
    const unsigned char* data = (const unsigned char*)data_val;
    if (!data) return (long long)strdup("");
    size_t len = strlen((const char*)data);

    unsigned int h0 = 0x67452301, h1 = 0xEFCDAB89, h2 = 0x98BADCFE, h3 = 0x10325476, h4 = 0xC3D2E1F0;
    size_t new_len = len + 1;
    while (new_len % 64 != 56) new_len++;
    unsigned char* msg = (unsigned char*)calloc(new_len + 8, 1);
    memcpy(msg, data, len);
    msg[len] = 0x80;
    unsigned long long bits_len = (unsigned long long)len * 8;
    for (int i = 0; i < 8; i++) msg[new_len + 7 - i] = (unsigned char)(bits_len >> (i * 8));

    for (size_t offset = 0; offset < new_len + 8; offset += 64) {
        unsigned int w[80];
        for (int i = 0; i < 16; i++) {
            w[i] = ((unsigned int)msg[offset + i*4] << 24) | ((unsigned int)msg[offset + i*4+1] << 16) |
                    ((unsigned int)msg[offset + i*4+2] << 8) | (unsigned int)msg[offset + i*4+3];
        }
        for (int i = 16; i < 80; i++) w[i] = sha1_left_rotate(w[i-3] ^ w[i-8] ^ w[i-14] ^ w[i-16], 1);
        unsigned int a = h0, b = h1, c = h2, d = h3, e = h4;
        for (int i = 0; i < 80; i++) {
            unsigned int f, k;
            if (i < 20) { f = (b & c) | ((~b) & d); k = 0x5A827999; }
            else if (i < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
            else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
            else { f = b ^ c ^ d; k = 0xCA62C1D6; }
            unsigned int temp = sha1_left_rotate(a, 5) + f + e + k + w[i];
            e = d; d = c; c = sha1_left_rotate(b, 30); b = a; a = temp;
        }
        h0 += a; h1 += b; h2 += c; h3 += d; h4 += e;
    }
    free(msg);

    // Return Base64-encoded hash directly (for WebSocket handshake)
    unsigned char hash[20];
    hash[0] = (h0>>24)&0xFF; hash[1] = (h0>>16)&0xFF; hash[2] = (h0>>8)&0xFF; hash[3] = h0&0xFF;
    hash[4] = (h1>>24)&0xFF; hash[5] = (h1>>16)&0xFF; hash[6] = (h1>>8)&0xFF; hash[7] = h1&0xFF;
    hash[8] = (h2>>24)&0xFF; hash[9] = (h2>>16)&0xFF; hash[10] = (h2>>8)&0xFF; hash[11] = h2&0xFF;
    hash[12] = (h3>>24)&0xFF; hash[13] = (h3>>16)&0xFF; hash[14] = (h3>>8)&0xFF; hash[15] = h3&0xFF;
    hash[16] = (h4>>24)&0xFF; hash[17] = (h4>>16)&0xFF; hash[18] = (h4>>8)&0xFF; hash[19] = h4&0xFF;

    // Base64 encode the 20-byte hash
    size_t b64_len = 4 * ((20 + 2) / 3);
    char* result = (char*)malloc(b64_len + 1);
    size_t j = 0;
    for (size_t bi = 0; bi < 20; bi += 3) {
        unsigned int n2 = ((unsigned int)hash[bi]) << 16;
        if (bi + 1 < 20) n2 |= ((unsigned int)hash[bi+1]) << 8;
        if (bi + 2 < 20) n2 |= (unsigned int)hash[bi+2];
        result[j++] = b64_table[(n2 >> 18) & 0x3F];
        result[j++] = b64_table[(n2 >> 12) & 0x3F];
        result[j++] = (bi + 1 < 20) ? b64_table[(n2 >> 6) & 0x3F] : '=';
        result[j++] = (bi + 2 < 20) ? b64_table[n2 & 0x3F] : '=';
    }
    result[j] = '\0';
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

// Read exact N bytes from a socket
#ifdef __wasm__
long long ep_net_recv_bytes(long long fd, long long count) {
    (void)fd; (void)count;
    return (long long)strdup("");
}
#else
long long ep_net_recv_bytes(long long fd, long long count) {
    if (count <= 0) return (long long)strdup("");
    char* buf = (char*)malloc(count + 1);
#ifdef _WIN32
    int total = 0;
    while (total < (int)count) {
        int n = recv((int)fd, buf + total, (int)(count - total), 0);
        if (n <= 0) break;
        total += n;
    }
#else
    ssize_t total = 0;
    while (total < count) {
        ssize_t n = recv((int)fd, buf + total, count - total, 0);
        if (n <= 0) break;
        total += n;
    }
#endif
    buf[total] = '\0';
    ep_gc_register(buf, EP_OBJ_STRING);
    return (long long)buf;
}
#endif

long long ep_get_args(void) {
    long long list_ptr = create_list();
    for (int i = 0; i < ep_argc; i++) {
        char* arg_copy = strdup(ep_argv[i]);
        ep_gc_register(arg_copy, EP_OBJ_STRING);
        append_list(list_ptr, (long long)arg_copy);
    }
    return list_ptr;
}

/* Built-in: string concatenation */
long long concat(long long a, long long b) {
    const char* sa = (const char*)a;
    const char* sb = (const char*)b;
    long long la = strlen(sa);
    long long lb = strlen(sb);
    char* result = malloc(la + lb + 1);
    memcpy(result, sa, la);
    memcpy(result + la, sb, lb);
    result[la + lb] = '\0';
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

long long int_to_string(long long val) {
    char* buf = malloc(32);
    snprintf(buf, 32, "%lld", val);
    ep_gc_register(buf, EP_OBJ_STRING);
    return (long long)buf;
}

long long ep_int_to_str(long long val) { return int_to_string(val); }

typedef struct { char* data; long long len; long long cap; } EpStringBuilder;

long long ep_sb_create(long long dummy) {
    (void)dummy;
    EpStringBuilder* sb = (EpStringBuilder*)malloc(sizeof(EpStringBuilder));
    sb->cap = 256;
    sb->len = 0;
    sb->data = (char*)malloc(sb->cap);
    sb->data[0] = '\0';
    return (long long)sb;
}

long long ep_sb_append(long long sb_ptr, long long str_ptr) {
    EpStringBuilder* sb = (EpStringBuilder*)sb_ptr;
    const char* s = (const char*)str_ptr;
    if (!s) return sb_ptr;
    long long slen = strlen(s);
    while (sb->len + slen + 1 > sb->cap) {
        sb->cap *= 2;
        sb->data = (char*)realloc(sb->data, sb->cap);
    }
    memcpy(sb->data + sb->len, s, slen);
    sb->len += slen;
    sb->data[sb->len] = '\0';
    return sb_ptr;
}

long long ep_sb_append_int(long long sb_ptr, long long val) {
    char buf[32];
    snprintf(buf, sizeof(buf), "%lld", val);
    return ep_sb_append(sb_ptr, (long long)buf);
}

long long ep_sb_to_string(long long sb_ptr) {
    EpStringBuilder* sb = (EpStringBuilder*)sb_ptr;
    char* result = (char*)malloc(sb->len + 1);
    memcpy(result, sb->data, sb->len + 1);
    ep_gc_register(result, EP_OBJ_STRING);
    free(sb->data);
    free(sb);
    return (long long)result;
}

long long ep_sb_length(long long sb_ptr) {
    return ((EpStringBuilder*)sb_ptr)->len;
}

long long str_to_ptr(long long s) { return s; }
long long ptr_to_str(long long p) {
    if (p == 0) return (long long)strdup("");
    char* copy = strdup((const char*)p);
    ep_gc_register(copy, EP_OBJ_STRING);
    return (long long)copy;
}

long long peek_byte(long long ptr, long long offset) {
    return (long long)((unsigned char*)ptr)[offset];
}
long long poke_byte(long long ptr, long long offset, long long value) {
    ((unsigned char*)ptr)[offset] = (unsigned char)value;
    return 0;
}
long long alloc_bytes(long long size) {
    return (long long)calloc((size_t)size, 1);
}
long long free_bytes(long long ptr) {
    free((void*)ptr);
    return 0;
}
long long list_to_bytes(long long list_ptr) {
    long long len = length_list(list_ptr);
    unsigned char* buf = (unsigned char*)malloc(len);
    for (long long i = 0; i < len; i++) {
        buf[i] = (unsigned char)get_list(list_ptr, i);
    }
    return (long long)buf;
}
long long bytes_to_list(long long ptr, long long len) {
    long long list = create_list();
    unsigned char* buf = (unsigned char*)ptr;
    for (long long i = 0; i < len; i++) {
        append_list(list, (long long)buf[i]);
    }
    return list;
}

long long ep_gc_get_minor_count() {
    return ep_gc_minor_count;
}
long long ep_gc_get_major_count() {
    return ep_gc_major_count;
}
long long ep_gc_get_nursery_count() {
    return ep_gc_nursery_count;
}

long long string_to_int(long long s) {
    if (s == 0) return 0;
    return atoll((const char*)s);
}

long long read_line() {
    char buf[4096];
    if (fgets(buf, sizeof(buf), stdin) == NULL) { buf[0] = '\0'; }
    size_t len = strlen(buf);
    if (len > 0 && buf[len-1] == '\n') buf[len-1] = '\0';
    char* result = strdup(buf);
    ep_gc_register(result, EP_OBJ_STRING);
    return (long long)result;
}

long long read_int() {
    long long val = 0;
    scanf("%lld", &val);
    while(getchar() != '\n');
    return val;
}

/* Read ONE key immediately: no echo, no waiting for Enter. Returns the key's
   number code (one byte at a time — escape sequences such as arrow keys
   arrive as successive codes), or -1 at end of input. When stdin is a pipe
   or a file (scripted tests), it simply reads the next byte. */
long long read_key() {
#if defined(__wasm__)
    return -1;
#elif defined(_WIN32)
    if (!_isatty(_fileno(stdin))) {
        return (long long)fgetc(stdin);
    }
    return (long long)_getch();
#else
    if (!isatty(STDIN_FILENO)) {
        return (long long)fgetc(stdin);
    }
    struct termios old_state, raw_state;
    if (tcgetattr(STDIN_FILENO, &old_state) != 0) {
        return (long long)fgetc(stdin);
    }
    raw_state = old_state;
    raw_state.c_lflag &= ~(ICANON | ECHO);
    raw_state.c_cc[VMIN] = 1;
    raw_state.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw_state);
    unsigned char ch = 0;
    long long got = (long long)read(STDIN_FILENO, &ch, 1);
    tcsetattr(STDIN_FILENO, TCSANOW, &old_state);
    if (got <= 0) return -1;
    return (long long)ch;
#endif
}

/* How wide the terminal window is, in characters. 80 when unknown. */
long long terminal_columns() {
#if defined(__wasm__)
    return 80;
#elif defined(_WIN32)
    CONSOLE_SCREEN_BUFFER_INFO info;
    if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info)) {
        long long cols = (long long)(info.srWindow.Right - info.srWindow.Left + 1);
        if (cols > 0) return cols;
    }
    return 80;
#else
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0) {
        return (long long)ws.ws_col;
    }
    return 80;
#endif
}

/* How tall the terminal window is, in lines. 24 when unknown. */
long long terminal_rows() {
#if defined(__wasm__)
    return 24;
#elif defined(_WIN32)
    CONSOLE_SCREEN_BUFFER_INFO info;
    if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info)) {
        long long rows = (long long)(info.srWindow.Bottom - info.srWindow.Top + 1);
        if (rows > 0) return rows;
    }
    return 24;
#else
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 0) {
        return (long long)ws.ws_row;
    }
    return 24;
#endif
}

long long read_float() {
    double val = 0.0;
    scanf("%lf", &val);
    while(getchar() != '\n');
    long long result; memcpy(&result, &val, sizeof(double));
    return result;
}

long long int_to_float(long long val) {
    double d = (double)val;
    long long result; memcpy(&result, &d, sizeof(double));
    return result;
}

long long float_to_int(long long val) {
    double d; memcpy(&d, &val, sizeof(double));
    return (long long)d;
}


/* External Function Prototypes (FFI) */
long long ep_sb_create(long long);
long long ep_sb_append(long long, long long);
long long ep_sb_append_int(long long, long long);
long long ep_sb_to_string(long long);
long long ep_sb_length(long long);
long long ep_getenv(long long);
long long ep_setenv(long long, long long);
long long ep_get_args();
long long ep_get_cwd();
long long ep_arch_name();
long long ep_exit(long long);
long long ep_run_command(long long);
long long ep_get_pid();
long long ep_get_home_dir();
long long ep_read_file(long long);
long long ep_write_file(long long, long long);
long long ep_append_file(long long, long long);
long long ep_file_exists(long long);
long long ep_is_directory(long long);
long long ep_file_size(long long);
long long ep_list_directory(long long);
long long ep_create_directory(long long);
long long ep_remove_file(long long);
long long ep_remove_directory(long long);
long long ep_rename_file(long long, long long);
long long ep_copy_file(long long, long long);
long long ep_realpath(long long);


/* Top-Level Constant Globals (Bridge Libraries) */
long long UI_POINTER_PRESSED = 0;
long long UI_TOUCH_START_X = 0;
long long UI_TOUCH_START_Y = 0;
long long UI_TOUCH_LAST_Y = 0;
long long UI_TOUCH_MOVED = 0;
long long UI_TOUCH_DELTA = 0;
long long UI_TOUCH_STARTED = 0;
long long UI_SCALE = 0;
long long UI_TOP = 0;
long long UI_BOTTOM = 0;
long long UI_TRANSFORM_CIF = 0;
long long ANDROID_SDL = 0;
long long ANDROID_INPUT_MUTEX = 0;
long long ANDROID_INPUT_BUFFER = 0;
long long ANDROID_INPUT_USED = 0;
long long ANDROID_INPUT_OVERFLOW = 0;
long long ANDROID_INPUT_WATCH = 0;
long long ANDROID_INPUT_WINDOW = 0;
long long ANDROID_INPUT_LOCK = 0;
long long ANDROID_INPUT_UNLOCK = 0;
long long ANDROID_INPUT_COPY = 0;
long long ANDROID_INPUT_LENGTH = 0;
long long ANDROID_POINTER_PENDING = 0;
long long NATIVE_SYSTEM = 0;
long long NATIVE_ANDROID = 0;
long long NATIVE_VARIADIC_FFI = 0;
long long ANDROID_JNI_ENV = 0;
long long ANDROID_JNI_TABLE = 0;
long long FONT_FFI = 0;
long long FONT_CALL = 0;
long long FONT_DRAW_CIF = 0;
long long FONT_MEASURE_CIF = 0;
long long FONT_VALUE = 0;
long long FONT_TEXT = 0;
long long FONT_POSITION = 0;
long long FONT_SIZE = 0;
long long FONT_SPACE = 0;
long long FONT_COLOR = 0;
long long FONT_DRAW_ARGS = 0;
long long FONT_MEASURE_ARGS = 0;
long long FONT_DRAW = 0;
long long FONT_MEASURE = 0;
long long FONT_RESULT = 0;
long long RAYLIB_HANDLE = 0;
long long RAYLIB_WHITE = 0;
long long RAYLIB_BLACK = 0;
long long RAYLIB_RED = 0;
long long RAYLIB_GREEN = 0;
long long RAYLIB_BLUE = 0;
long long RAYLIB_YELLOW = 0;
long long RAYLIB_ORANGE = 0;
long long RAYLIB_PURPLE = 0;
long long RAYLIB_PINK = 0;
long long RAYLIB_LIGHTGRAY = 0;
long long RAYLIB_DARKGRAY = 0;
long long RAYLIB_GRAY = 0;
long long RAYLIB_MAROON = 0;
long long RAYLIB_LIME = 0;
long long RAYLIB_DARKBLUE = 0;
long long RAYLIB_DARKGREEN = 0;
long long RAYLIB_DARKPURPLE = 0;
long long RAYLIB_BEIGE = 0;
long long RAYLIB_MAGENTA = 0;
long long RAYLIB_SKYBLUE = 0;
long long RAYLIB_GOLD = 0;
long long RAYLIB_BROWN = 0;
long long RAYLIB_DARKBROWN = 0;
long long RAYLIB_VIOLET = 0;
long long RAYLIB_RAYWHITE = 0;
long long RAYLIB_BLANK = 0;
long long KEY_SPACE = 0;
long long KEY_ESCAPE = 0;
long long KEY_ENTER = 0;
long long KEY_TAB = 0;
long long KEY_BACKSPACE = 0;
long long KEY_DELETE = 0;
long long KEY_RIGHT = 0;
long long KEY_LEFT = 0;
long long KEY_DOWN = 0;
long long KEY_UP = 0;
long long KEY_PAGE_UP = 0;
long long KEY_PAGE_DOWN = 0;
long long KEY_HOME = 0;
long long KEY_END = 0;
long long KEY_F1 = 0;
long long KEY_F2 = 0;
long long KEY_F3 = 0;
long long KEY_F4 = 0;
long long KEY_F5 = 0;
long long KEY_F6 = 0;
long long KEY_F7 = 0;
long long KEY_F8 = 0;
long long KEY_F9 = 0;
long long KEY_F10 = 0;
long long KEY_F11 = 0;
long long KEY_F12 = 0;
long long KEY_LEFT_SHIFT = 0;
long long KEY_LEFT_CONTROL = 0;
long long KEY_LEFT_ALT = 0;
long long KEY_RIGHT_SHIFT = 0;
long long KEY_RIGHT_CONTROL = 0;
long long KEY_RIGHT_ALT = 0;
long long KEY_A = 0;
long long KEY_B = 0;
long long KEY_C = 0;
long long KEY_D = 0;
long long KEY_E = 0;
long long KEY_F = 0;
long long KEY_G = 0;
long long KEY_H = 0;
long long KEY_I = 0;
long long KEY_J = 0;
long long KEY_K = 0;
long long KEY_L = 0;
long long KEY_M = 0;
long long KEY_N = 0;
long long KEY_O = 0;
long long KEY_P = 0;
long long KEY_Q = 0;
long long KEY_R = 0;
long long KEY_S = 0;
long long KEY_T = 0;
long long KEY_U = 0;
long long KEY_V = 0;
long long KEY_W = 0;
long long KEY_X = 0;
long long KEY_Y = 0;
long long KEY_Z = 0;
long long KEY_ZERO = 0;
long long KEY_ONE = 0;
long long KEY_TWO = 0;
long long KEY_THREE = 0;
long long KEY_FOUR = 0;
long long KEY_FIVE = 0;
long long KEY_SIX = 0;
long long KEY_SEVEN = 0;
long long KEY_EIGHT = 0;
long long KEY_NINE = 0;
long long MOUSE_LEFT = 0;
long long MOUSE_RIGHT = 0;
long long MOUSE_MIDDLE = 0;
long long FLAG_VSYNC_HINT = 0;
long long FLAG_FULLSCREEN_MODE = 0;
long long FLAG_WINDOW_RESIZABLE = 0;
long long FLAG_WINDOW_UNDECORATED = 0;
long long FLAG_WINDOW_TRANSPARENT = 0;
long long FLAG_MSAA_4X_HINT = 0;
long long FLAG_WINDOW_ALWAYS_RUN = 0;
long long LOG_NONE = 0;
long long LOG_ERROR = 0;
long long LOG_WARNING = 0;
long long LOG_INFO = 0;
long long LOG_DEBUG = 0;
long long LOG_TRACE = 0;
long long CHAT_WHEEL_CIF = 0;
long long CHAT_WHEEL_RESULT = 0;
long long PROGRESS_TURN = 0;
long long PROGRESS_ROUND = 0;
long long PROGRESS_EPOCH = 0;
long long PROGRESS_LAST = 0;
long long SOURCES_OPEN = 0;
long long SOURCE_CHILD = 0;
long long SOURCE_NOTICE = 0;
long long EDIT_TEXT = 0;
long long EDIT_CARET = 0;
long long EDIT_ANCHOR = 0;
long long EDIT_FOCUS = 0;
long long EDIT_DRAG = 0;
long long EDIT_SCROLL = 0;
long long EDIT_BLINK = 0;
long long EDIT_ERROR = 0;
long long EDIT_CLICK_TIME = 0;
long long EDIT_CLICK_POS = 0;
long long SELECT_CLICK_TIME = 0;
long long SELECT_CLICK_POS = 0;
long long EDIT_UNDO = 0;
long long EDIT_REDO = 0;
long long SELECT_TOP = 0;
long long SELECT_BOTTOM = 0;
long long SELECT_TEXT = 0;
long long SELECT_CARET = 0;
long long SELECT_ANCHOR = 0;
long long SELECT_DRAG = 0;
long long EDIT_MENU = 0;
long long EDIT_MENU_X = 0;
long long EDIT_MENU_Y = 0;
long long EDIT_MENU_USED = 0;
long long PDF_OBJC = 0;
long long STATE_LEASE_FD = 0;
long long WORKER_LEASE_FD = 0;


/* User Function Prototypes */
long long color(long long, long long, long long);
long long panel(long long, long long, long long, long long, long long);
long long label(long long, long long, long long, long long, long long);
long long hit(long long, long long, long long, long long);
long long wrap_text(long long, long long, long long, long long, long long, long long);
long long _main();
long long ui_viewport_update();
long long ui_screen_width();
long long ui_screen_height();
long long ui_mouse_x();
long long ui_mouse_y();
long long ui_transform(long long, long long, long long, long long);
long long ui_begin_drawing();
long long ui_scissor(long long, long long, long long, long long);
long long ui_mouse_pressed();
long long android_text_watch(long long, long long);
long long android_input_init(long long);
long long android_input_take();
long long android_keyboard(long long);
long long android_input_close();
long long android_input_overflowed();
long long android_pointer_take();
long long process_integer(long long, long long);
long long process_spawn_streams(long long, long long, long long, long long, long long, long long, long long);
long long process_poll(long long);
long long process_start(long long, long long);
long long process_launch(long long, long long, long long);
long long process_detached(long long, long long, long long);
long long process_spawn(long long, long long, long long, long long);
long long native_system();
long long native_bytes_write(long long, long long, long long, long long);
long long native_variadic_int(long long, long long, long long, long long);
long long native_open(long long, long long, long long);
long long native_openat(long long, long long, long long, long long);
long long native_fcntl_int(long long, long long, long long);
long long native_android();
long long native_errno_pointer();
long long native_signed_int(long long);
long long native_android_open_flags(long long);
long long native_at_nofollow();
long long native_dirent_name(long long);
long long native_rename_exclusive(long long, long long, long long, long long);
long long is_digit(long long);
long long is_alpha(long long);
long long is_alphanumeric(long long);
long long is_space(long long);
long long to_upper_char(long long);
long long to_lower_char(long long);
long long string_equals(long long, long long);
long long starts_with(long long, long long);
long long ends_with(long long, long long);
long long string_last_index_of(long long, long long);
long long string_count(long long, long long);
long long repeat_string(long long, long long);
long long string_to_upper(long long);
long long string_to_lower(long long);
long long trim_left(long long);
long long trim_right(long long);
long long reverse_string(long long);
long long string_pad_left(long long, long long, long long);
long long string_pad_right(long long, long long, long long);
long long split(long long, long long);
long long join(long long, long long);
long long create_builder();
long long builder_append(long long, long long);
long long builder_append_int(long long, long long);
long long builder_to_string(long long);
long long builder_length(long long);
long long builder_clear(long long);
long long string_format(long long, long long);
long long android_jni_function(long long);
long long android_jni_clear();
long long android_jni_release(long long);
long long android_jni_object(long long, long long, long long, long long);
long long android_keyboard_inset(long long);
long long native_write(long long, long long, long long, long long);
long long native_f32(long long);
long long native_struct(long long);
long long native_cif(long long, long long);
long long font_init(long long);
long long font_draw(long long, long long, long long, long long, long long);
long long font_measure(long long, long long);
long long get_env(long long);
long long set_env(long long, long long);
long long get_args();
long long get_cwd();
long long get_home_dir();
long long get_pid();
long long os_name();
long long arch_name();
long long exit_program(long long);
long long transport_error(long long);
long long transport_number(long long, long long, long long);
long long transport_parser();
long long transport_parse(long long, long long, long long);
long long transport_u32(long long, long long, long long);
long long transport_now(long long);
long long transport_errno(long long);
long long transport_wait_cancel(long long, long long, long long, long long, long long, long long);
long long transport_request_cancel(long long, long long, long long, long long, long long, long long, long long, long long);
long long local_post(long long, long long, long long);
long long transport_post(long long, long long, long long, long long, long long, long long);
long long transport_get(long long, long long, long long);
long long transport_wait(long long, long long, long long, long long, long long);
long long transport_request(long long, long long, long long, long long, long long, long long, long long);
long long create_json_int(long long);
long long create_json_string(long long);
long long create_json_list(long long);
long long create_json_object(long long, long long);
long long get_json_type(long long);
long long get_json_value(long long);
long long get_json_object_value(long long, long long);
long long json_escape_string(long long);
long long json_stringify(long long);
long long json_skip_whitespace(long long);
long long json_hex_val(long long);
long long json_parse_hex4(long long, long long, long long);
long long json_append_utf8(long long, long long);
long long json_parse_string(long long);
long long json_parse_number(long long);
long long json_parse_value(long long);
long long json_parse_object(long long);
long long json_parse_list(long long);
long long json_parse(long long);
long long read_file(long long);
long long read_lines(long long);
long long write_file(long long, long long);
long long append_file(long long, long long);
long long is_directory(long long);
long long file_size(long long);
long long list_directory(long long);
long long create_directory(long long);
long long remove_file(long long);
long long remove_directory(long long);
long long rename_file(long long, long long);
long long copy_file(long long, long long);
long long path_join(long long, long long);
long long path_extension(long long);
long long path_basename(long long);
long long path_dirname(long long);
long long raylib_load();
long long raylib_init_window(long long, long long, long long);
long long raylib_close_window();
long long raylib_window_should_close();
long long raylib_set_target_fps(long long);
long long raylib_get_fps();
long long raylib_get_screen_width();
long long raylib_get_screen_height();
long long raylib_set_window_title(long long);
long long raylib_toggle_fullscreen();
long long raylib_set_window_size(long long, long long);
long long raylib_is_window_resized();
long long raylib_is_window_focused();
long long raylib_set_window_icon(long long);
long long raylib_begin_drawing();
long long raylib_end_drawing();
long long raylib_clear_background(long long);
long long raylib_draw_pixel(long long, long long, long long);
long long raylib_draw_line(long long, long long, long long, long long, long long);
long long raylib_draw_circle(long long, long long, long long, long long);
long long raylib_draw_circle_lines(long long, long long, long long, long long);
long long raylib_draw_rectangle(long long, long long, long long, long long, long long);
long long raylib_draw_rectangle_lines(long long, long long, long long, long long, long long);
long long raylib_draw_triangle(long long, long long, long long, long long, long long, long long, long long);
long long raylib_draw_poly(long long, long long, long long, long long, long long, long long);
long long raylib_draw_ring(long long, long long, long long, long long, long long, long long, long long, long long);
long long raylib_draw_text(long long, long long, long long, long long, long long);
long long raylib_measure_text(long long, long long);
long long raylib_draw_fps(long long, long long);
long long raylib_load_font(long long);
long long raylib_unload_font(long long);
long long raylib_load_texture(long long);
long long raylib_unload_texture(long long);
long long raylib_draw_texture(long long, long long, long long, long long);
long long raylib_draw_texture_ex(long long, long long, long long, long long, long long, long long);
long long raylib_load_image(long long);
long long raylib_unload_image(long long);
long long raylib_load_texture_from_image(long long);
long long raylib_is_key_pressed(long long);
long long raylib_is_key_down(long long);
long long raylib_is_key_released(long long);
long long raylib_is_key_up(long long);
long long raylib_get_key_pressed();
long long raylib_get_char_pressed();
long long raylib_is_mouse_button_pressed(long long);
long long raylib_is_mouse_button_down(long long);
long long raylib_is_mouse_button_released(long long);
long long raylib_get_mouse_x();
long long raylib_get_mouse_y();
long long raylib_get_mouse_wheel_move();
long long raylib_set_mouse_position(long long, long long);
long long raylib_show_cursor();
long long raylib_hide_cursor();
long long raylib_init_audio();
long long raylib_close_audio();
long long raylib_is_audio_ready();
long long raylib_set_master_volume(long long);
long long raylib_load_sound(long long);
long long raylib_unload_sound(long long);
long long raylib_play_sound(long long);
long long raylib_stop_sound(long long);
long long raylib_pause_sound(long long);
long long raylib_resume_sound(long long);
long long raylib_is_sound_playing(long long);
long long raylib_set_sound_volume(long long, long long);
long long raylib_load_music(long long);
long long raylib_unload_music(long long);
long long raylib_play_music(long long);
long long raylib_stop_music(long long);
long long raylib_update_music(long long);
long long raylib_is_music_playing(long long);
long long raylib_set_music_volume(long long, long long);
long long raylib_check_collision_recs(long long, long long, long long, long long, long long, long long, long long, long long);
long long raylib_check_collision_circles(long long, long long, long long, long long, long long, long long);
long long raylib_check_collision_point_rec(long long, long long, long long, long long, long long, long long);
long long raylib_get_frame_time();
long long raylib_get_time();
long long raylib_wait(long long);
long long raylib_set_trace_log_level(long long);
long long raylib_take_screenshot(long long);
long long raylib_set_config_flags(long long);
long long raylib_is_window_ready();
long long sql_open(long long);
long long sql_close(long long);
long long sql_execute(long long, long long);
long long sql_query(long long, long long);
long long sql_bind_params(long long, long long);
long long sql_execute_params(long long, long long, long long);
long long sql_query_params(long long, long long, long long);
long long layout_boundary(long long, long long);
long long layout_prefix(long long, long long, long long);
long long layout_ranges(long long, long long, long long);
long long layout_lines(long long, long long, long long);
long long chat_backspace(long long);
long long chat_character(long long);
long long chat_sessions(long long, long long);
long long chat_turns(long long, long long);
long long chat_wheel(long long);
long long chat_sources(long long, long long);
long long source_rows(long long, long long);
long long source_reply(long long, long long, long long);
long long source_target(long long);
long long source_host(long long);
long long source_title(long long, long long);
long long source_open(long long);
long long result_cache_error(long long);
long long result_cache_scalar(long long, long long, long long);
long long result_cache_key(long long, long long, long long);
long long result_cache_epoch(long long, long long);
long long result_cache_get(long long, long long, long long, long long);
long long result_cache_put(long long, long long, long long, long long, long long);
long long md5(long long);
long long sha256(long long);
long long progress_scope(long long, long long, long long);
long long progress_initialize(long long);
long long progress_publish(long long, long long, long long, long long);
long long progress_answer(long long, long long);
long long ui_sources(long long, long long, long long, long long, long long, long long);
long long ui_color(long long, long long, long long);
long long ui_frame(long long, long long, long long, long long, long long, long long);
long long ui_bitmap(long long, long long, long long, long long, long long, long long);
long long ui_letter(long long);
long long ui_wordmark(long long, long long, long long, long long);
long long ui_icon(long long, long long, long long, long long, long long);
long long ui_text_fit(long long, long long, long long);
long long ui_nav(long long, long long, long long, long long);
long long ui_plain_inline(long long);
long long ui_code_block(long long, long long, long long, long long, long long);
long long ui_response(long long, long long, long long, long long, long long);
long long ui_capture(long long);
long long editor_previous(long long, long long);
long long editor_next(long long, long long);
long long editor_selected(long long, long long, long long);
long long editor_splice(long long, long long, long long, long long);
long long editor_snapshot();
long long editor_insert(long long);
long long editor_history(long long);
long long editor_row(long long, long long);
long long editor_hit(long long, long long, long long, long long, long long);
long long editor_move(long long, long long, long long, long long, long long);
long long editor_key(long long);
long long editor_clipboard();
long long editor_handle(long long, long long, long long, long long, long long, long long);
long long editor_paint(long long, long long, long long, long long, long long, long long, long long, long long, long long);
long long editor_draw(long long, long long, long long, long long, long long, long long);
long long selectable_text(long long, long long, long long, long long, long long, long long);
long long editor_min(long long, long long);
long long editor_max(long long, long long);
long long editor_state();
long long editor_word(long long, long long);
long long editor_menu_open(long long, long long);
long long editor_menu_draw();
long long attachment_pick();
long long attachment_begin(long long, long long, long long);
long long attachment_finish(long long, long long, long long, long long);
long long pdf_message(long long, long long);
long long pdf_argument(long long, long long, long long);
long long pdf_error(long long, long long);
long long pdf_snapshot(long long, long long);
long long pdf_extract(long long, long long, long long);
long long filesystem_error(long long, long long, long long);
long long filesystem_signature(long long, long long);
long long filesystem_uri(long long);
long long filesystem_partial_utf8(long long, long long, long long);
long long filesystem_read(long long, long long, long long);
long long filesystem_list(long long, long long, long long);
long long filesystem_lookup(long long, long long, long long, long long);
long long lease_error(long long);
long long lease_integer(long long, long long, long long);
long long private_lock(long long, long long);
long long state_lease(long long, long long);
long long native_stat_mode(long long);
long long native_stat_links(long long);
long long native_stat_owner(long long);
long long native_stat_size(long long);
long long native_stat_time(long long, long long);
long long native_available_bytes(long long);
long long document_error(long long);
long long document_utf8(long long, long long);
long long read_document(long long);
long long snapshot_hex(long long, long long);
long long snapshot_name(long long);
long long snapshot_private(long long, long long);
long long snapshot_hash(long long, long long);
long long snapshot_read_hex(long long, long long);
long long snapshot_seal_verify(long long, long long);
long long snapshot_seal_create(long long, long long);
long long ui_schedule_ready(long long, long long, long long, long long, long long, long long, long long);
long long ui_schedule_rows(long long, long long);
long long schedule_init(long long);
long long schedule_error(long long, long long);
long long schedule_result(long long, long long);
long long schedule_set(long long, long long, long long, long long, long long, long long);
long long schedule_cancel(long long, long long, long long);
long long schedule_due(long long, long long);
long long schedule_claim(long long, long long, long long, long long, long long);
long long schedule_needs_work(long long, long long);
long long network_mode(long long);
long long android_files_directory();
long long android_library_directory(long long);



/* Thread Spawn Wrappers */

long long color(long long red, long long green, long long blue) {
    long long ret_val = 0;

    ret_val = (((red + (green * 256)) + (blue * 65536)) + 4278190080);
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long panel(long long x, long long y, long long width, long long height, long long tint) {
    long long ret_val = 0;

    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);
    ep_gc_push_root(&height);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    ret_val = ui_frame(x, y, width, height, tint, color(46, 54, 62));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long label(long long text, long long x, long long y, long long size, long long tint) {
    long long ret_val = 0;

    ep_gc_push_root(&text);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&size);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    font_draw(text, x, y, size, tint);
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long hit(long long x, long long y, long long width, long long height) {
    long long mx = 0;
    long long my = 0;
    long long ret_val = 0;

    mx = (raylib_get_mouse_x() / UI_SCALE);
    my = ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP);
    ret_val = (((mx >= x && mx <= (x + width)) && my >= y) && my <= (y + height));
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long wrap_text(long long text, long long x, long long y, long long width, long long size, long long tint) {
    long long ret_val = 0;

    ep_gc_push_root(&text);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);
    ep_gc_push_root(&size);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    ret_val = selectable_text(text, x, y, width, size, tint);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long _main() {
    long long active = 0;
    long long active_turn = 0;
    long long args = 0;
    long long arrow = 0;
    long long attachment = 0;
    long long attachment_path = 0;
    long long bg = 0;
    long long body_height = 0;
    long long border = 0;
    long long button_tint = 0;
    long long capture = 0;
    long long card_height = 0;
    long long card_y = 0;
    long long child = 0;
    long long choose_image = 0;
    long long chosen = 0;
    long long clicked = 0;
    long long composer_edge = 0;
    long long composer_status = 0;
    long long content_width = 0;
    long long core = 0;
    long long current_session = 0;
    long long db = 0;
    long long draft = 0;
    long long escape = 0;
    long long exercise = 0;
    long long exercise_draft_seen = 0;
    long long exercise_finished = 0;
    long long exercise_image = 0;
    long long exercise_imported = 0;
    long long exercise_live_seen = 0;
    long long exercise_schedule = 0;
    long long exercise_schedule_done = 0;
    long long exercise_schedule_interrupt = 0;
    long long exercise_sent = 0;
    long long exercise_stop = 0;
    long long exit_code = 0;
    long long flags = 0;
    long long follow_bottom = 0;
    long long frames = 0;
    long long full_path = 0;
    long long height = 0;
    long long home = 0;
    long long identities = 0;
    long long identity = 0;
    long long ii = 0;
    long long image_index = 0;
    long long image_record = 0;
    long long image_row = 0;
    long long image_turns = 0;
    long long import_file = 0;
    long long import_path = 0;
    long long imported = 0;
    long long initial_height = 0;
    long long initial_width = 0;
    long long item = 0;
    long long last_activity = 0;
    long long last_dispatch = 0;
    long long layout_index = 0;
    long long layout_row = 0;
    long long left = 0;
    long long library = 0;
    long long mint = 0;
    long long mobile_menu = 0;
    long long muted = 0;
    long long native_directory = 0;
    long long network_label = 0;
    long long note = 0;
    long long note_count = 0;
    long long note_index = 0;
    long long notes = 0;
    long long notice = 0;
    long long now = 0;
    long long operation = 0;
    long long pane_scroll = 0;
    long long pane_total = 0;
    long long pending = 0;
    long long pending_text = 0;
    long long previous_draft = 0;
    long long prior_sources_open = 0;
    long long project = 0;
    long long resolved = 0;
    long long root = 0;
    long long row_height = 0;
    long long row_tint = 0;
    long long row_y = 0;
    long long runtime_child = 0;
    long long runtime_executable = 0;
    long long runtime_exit = 0;
    long long runtime_ready = 0;
    long long scheduled_run = 0;
    long long scroll = 0;
    long long section = 0;
    long long selected = 0;
    long long send_requested = 0;
    long long sessions = 0;
    long long si = 0;
    long long sidebar = 0;
    long long speaker = 0;
    long long state_text = 0;
    long long state_tint = 0;
    long long stop_child = 0;
    long long stop_clicked = 0;
    long long stop_exit = 0;
    long long stop_requested = 0;
    long long stop_started = 0;
    long long submitted = 0;
    long long submitted_attachment = 0;
    long long submitted_attachment_path = 0;
    long long subtitle = 0;
    long long surface = 0;
    long long task_detail = 0;
    long long task_height = 0;
    long long task_i = 0;
    long long task_row = 0;
    long long task_rows = 0;
    long long task_scroll = 0;
    long long task_title = 0;
    long long task_total = 0;
    long long task_y = 0;
    long long thinking_label = 0;
    long long thinking_open = 0;
    long long thought = 0;
    long long thumb_height = 0;
    long long thumb_y = 0;
    long long ti = 0;
    long long title = 0;
    long long token_path = 0;
    long long turn = 0;
    long long turn_floor = 0;
    long long turns = 0;
    long long user_activity = 0;
    long long user_height = 0;
    long long viewport = 0;
    long long was_stopped = 0;
    long long wheel = 0;
    long long white = 0;
    long long width = 0;
    long long window_flags = 0;
    long long ret_val = 0;

    ep_gc_push_root(&active_turn);
    ep_gc_push_root(&args);
    ep_gc_push_root(&arrow);
    ep_gc_push_root(&attachment);
    ep_gc_push_root(&attachment_path);
    ep_gc_push_root(&bg);
    ep_gc_push_root(&body_height);
    ep_gc_push_root(&button_tint);
    ep_gc_push_root(&capture);
    ep_gc_push_root(&card_height);
    ep_gc_push_root(&card_y);
    ep_gc_push_root(&child);
    ep_gc_push_root(&chosen);
    ep_gc_push_root(&composer_edge);
    ep_gc_push_root(&composer_status);
    ep_gc_push_root(&content_width);
    ep_gc_push_root(&core);
    ep_gc_push_root(&current_session);
    ep_gc_push_root(&db);
    ep_gc_push_root(&draft);
    ep_gc_push_root(&escape);
    ep_gc_push_root(&exercise);
    ep_gc_push_root(&exit_code);
    ep_gc_push_root(&flags);
    ep_gc_push_root(&height);
    ep_gc_push_root(&home);
    ep_gc_push_root(&identities);
    ep_gc_push_root(&identity);
    ep_gc_push_root(&ii);
    ep_gc_push_root(&image_index);
    ep_gc_push_root(&image_record);
    ep_gc_push_root(&image_row);
    ep_gc_push_root(&image_turns);
    ep_gc_push_root(&import_file);
    ep_gc_push_root(&import_path);
    ep_gc_push_root(&imported);
    ep_gc_push_root(&item);
    ep_gc_push_root(&last_activity);
    ep_gc_push_root(&last_dispatch);
    ep_gc_push_root(&layout_index);
    ep_gc_push_root(&layout_row);
    ep_gc_push_root(&left);
    ep_gc_push_root(&library);
    ep_gc_push_root(&mint);
    ep_gc_push_root(&mobile_menu);
    ep_gc_push_root(&muted);
    ep_gc_push_root(&native_directory);
    ep_gc_push_root(&network_label);
    ep_gc_push_root(&note);
    ep_gc_push_root(&note_index);
    ep_gc_push_root(&notes);
    ep_gc_push_root(&notice);
    ep_gc_push_root(&now);
    ep_gc_push_root(&operation);
    ep_gc_push_root(&pane_scroll);
    ep_gc_push_root(&pane_total);
    ep_gc_push_root(&pending);
    ep_gc_push_root(&pending_text);
    ep_gc_push_root(&previous_draft);
    ep_gc_push_root(&prior_sources_open);
    ep_gc_push_root(&project);
    ep_gc_push_root(&resolved);
    ep_gc_push_root(&root);
    ep_gc_push_root(&row_height);
    ep_gc_push_root(&row_y);
    ep_gc_push_root(&runtime_child);
    ep_gc_push_root(&runtime_executable);
    ep_gc_push_root(&runtime_ready);
    ep_gc_push_root(&section);
    ep_gc_push_root(&selected);
    ep_gc_push_root(&sessions);
    ep_gc_push_root(&si);
    ep_gc_push_root(&speaker);
    ep_gc_push_root(&state_text);
    ep_gc_push_root(&stop_child);
    ep_gc_push_root(&stop_started);
    ep_gc_push_root(&submitted);
    ep_gc_push_root(&submitted_attachment);
    ep_gc_push_root(&submitted_attachment_path);
    ep_gc_push_root(&subtitle);
    ep_gc_push_root(&surface);
    ep_gc_push_root(&task_detail);
    ep_gc_push_root(&task_height);
    ep_gc_push_root(&task_i);
    ep_gc_push_root(&task_row);
    ep_gc_push_root(&task_rows);
    ep_gc_push_root(&task_title);
    ep_gc_push_root(&task_y);
    ep_gc_push_root(&thinking_label);
    ep_gc_push_root(&thinking_open);
    ep_gc_push_root(&thought);
    ep_gc_push_root(&ti);
    ep_gc_push_root(&title);
    ep_gc_push_root(&token_path);
    ep_gc_push_root(&turn);
    ep_gc_push_root(&turn_floor);
    ep_gc_push_root(&turns);
    ep_gc_push_root(&user_height);
    ep_gc_push_root(&viewport);
    ep_gc_push_root(&wheel);
    ep_gc_push_root(&white);
    ep_gc_push_root(&width);
    ep_gc_push_root(&window_flags);

    ep_gc_maybe_collect();

    args = ep_get_args();
    root = (long long)"";
    core = (long long)"";
    runtime_executable = (long long)"";
    if (native_android()) {
    RAYLIB_HANDLE = ep_dlopen((long long)"libmain.so");
    root = android_files_directory();
    native_directory = android_library_directory(RAYLIB_HANDLE);
    if ((ep_str_equals(root, (long long)"") || ep_str_equals(native_directory, (long long)""))) {
    ret_val = 1;
    goto L_cleanup;
    }
    ep_setenv((long long)"ECHOLITE_LIBRARY", concat(root, (long long)"/library"));
    ep_setenv((long long)"ICU_DATA", concat(root, (long long)"/library"));
    core = concat(native_directory, (long long)"/libecholite-core.so");
    runtime_executable = concat(native_directory, (long long)"/libecholite-runtime.so");
    } else {
    resolved = alloc_bytes(4096);
    full_path = ep_dlcall2(ep_dlsym(native_system(), (long long)"realpath"), get_list(args, 0), resolved);
    if (full_path == 0) {
    free_bytes(resolved);
    ret_val = 1;
    goto L_cleanup;
    }
    root = path_dirname(path_dirname(ptr_to_str(resolved)));
    free_bytes(resolved);
    core = concat(root, (long long)"/bin/echolite-core");
    runtime_executable = concat(root, (long long)"/bin/echolite-runtime");
    }
    project = ep_getenv((long long)"ECHOLITE_PROJECT");
    if (ep_str_equals(project, (long long)"")) {
    project = (long long)"local";
    }
    home = ep_getenv((long long)"ECHOLITE_HOME");
    if (ep_str_equals(home, (long long)"")) {
    home = concat(root, (long long)"/data");
    }
    if (ep_is_directory(home) == 0) {
    ep_dlcall2(ep_dlsym(native_system(), (long long)"mkdir"), home, 448);
    }
    ep_dlcall3(ep_dlsym(native_system(), (long long)"setenv"), (long long)"ECHOLITE_HOME", home, 1);
    child = 0;
    operation = (long long)"";
    child = process_spawn_streams(core, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"init"); _lit_list; }), -1, -1, 0, (long long)"", 0);
    operation = (long long)"init";
    db = 0;
    if (ep_file_exists(concat(home, (long long)"/memory.sqlite3")) == 1) {
    db = sql_open(concat(home, (long long)"/memory.sqlite3"));
    ep_sqlite3_exec(db, (long long)"PRAGMA query_only=ON; PRAGMA busy_timeout=1000;", 0, 0, 0);
    }
    library = ep_getenv((long long)"ECHOLITE_GRAPHICS_LIBRARY");
    if (ep_str_equals(library, (long long)"")) {
    library = concat(root, (long long)"/models/runtime/libraylib.dylib");
    }
    if (native_android()) {
    library = (long long)"libmain.so";
    }
    RAYLIB_HANDLE = ep_dlopen(library);
    if (RAYLIB_HANDLE == 0) {
    printf("%s\n", (char*)(long long)"Unable to load native graphics library.");
    ret_val = 1;
    goto L_cleanup;
    }
    flags = ep_dlsym(RAYLIB_HANDLE, (long long)"SetConfigFlags");
    window_flags = 8196;
    if (native_android()) {
    window_flags = 4;
    }
    ep_dlcall1(flags, window_flags);
    initial_width = 1180;
    initial_height = 800;
    if (length_list(args) > 1) {
    if ((!ep_str_equals(ep_getenv((long long)"ECHOLITE_PREVIEW_WIDTH"), (long long)""))) {
    initial_width = editor_max(900, editor_min(1800, string_to_int(get_env((long long)"ECHOLITE_PREVIEW_WIDTH"))));
    }
    if ((!ep_str_equals(ep_getenv((long long)"ECHOLITE_PREVIEW_HEIGHT"), (long long)""))) {
    initial_height = editor_max(600, editor_min(1000, string_to_int(get_env((long long)"ECHOLITE_PREVIEW_HEIGHT"))));
    }
    }
    if (native_android()) {
    initial_width = 0;
    initial_height = 0;
    }
    raylib_init_window(initial_width, initial_height, (long long)"EchoLite");
    if ((native_android() && android_input_init(RAYLIB_HANDLE) == 0)) {
    raylib_close_window();
    ret_val = 1;
    goto L_cleanup;
    }
    if (native_android() == 0) {
    ep_dlcall2(ep_dlsym(RAYLIB_HANDLE, (long long)"SetWindowMinSize"), 900, 600);
    }
    raylib_set_target_fps(30);
    font_init(RAYLIB_HANDLE);
    escape = ep_dlsym(RAYLIB_HANDLE, (long long)"SetExitKey");
    ep_dlcall1(escape, 0);
    bg = 4280031252;
    sidebar = 4279768081;
    surface = 4280754716;
    border = 4282201389;
    mint = 4291421629;
    white = 4293586664;
    muted = 4289306516;
    attachment = (long long)"";
    attachment_path = (long long)"";
    import_path = (long long)"";
    import_file = 0;
    submitted_attachment = (long long)"";
    submitted_attachment_path = (long long)"";
    exercise_image = (long long)"";
    exercise_imported = 0;
    stop_child = 0;
    stop_started = 0;
    stop_requested = 0;
    active_turn = (long long)"";
    turn_floor = (long long)"0";
    exercise_stop = 0;
    submitted = (long long)"";
    exercise = (long long)"";
    exercise_sent = 0;
    exercise_finished = 0;
    exercise_live_seen = 0;
    exercise_draft_seen = 0;
    draft = (long long)"";
    thinking_open = (long long)"";
    selected = (long long)"";
    sessions = create_list();
    turns = create_list();
    image_turns = create_list();
    scroll = 0;
    body_height = 0;
    follow_bottom = 1;
    notice = (long long)"";
    current_session = (long long)"";
    section = (long long)"chat";
    scheduled_run = 0;
    last_activity = transport_now(native_system());
    last_dispatch = (last_activity - 60000);
    pane_scroll = 0;
    task_scroll = 0;
    task_rows = create_list();
    exercise_schedule = 0;
    exercise_schedule_done = 0;
    exercise_schedule_interrupt = 0;
    frames = 0;
    args = ep_get_args();
    capture = (long long)"";
    if (length_list(args) > 1) {
    capture = get_list(args, 1);
    if ((ep_str_equals(capture, (long long)"--exercise") && length_list(args) == 4)) {
    exercise = get_list(args, 2);
    draft = exercise;
    capture = get_list(args, 3);
    }
    }
    if ((length_list(args) == 5 && ep_str_equals(get_list(args, 1), (long long)"--exercise-image"))) {
    exercise_image = get_list(args, 2);
    exercise = get_list(args, 3);
    draft = exercise;
    capture = get_list(args, 4);
    }
    if ((length_list(args) == 4 && ep_str_equals(get_list(args, 1), (long long)"--exercise-stop"))) {
    exercise_stop = 1;
    exercise = get_list(args, 2);
    draft = exercise;
    capture = get_list(args, 3);
    }
    if ((length_list(args) == 4 && (ep_str_equals(get_list(args, 1), (long long)"--exercise-schedule") || ep_str_equals(get_list(args, 1), (long long)"--exercise-schedule-stop")))) {
    exercise_schedule = 1;
    if (ep_str_equals(get_list(args, 1), (long long)"--exercise-schedule-stop")) {
    exercise_schedule_interrupt = 1;
    }
    exercise = get_list(args, 2);
    draft = exercise;
    capture = get_list(args, 3);
    }
    if ((length_list(args) == 3 && ep_str_equals(get_list(args, 1), (long long)"--exercise-due-stop"))) {
    exercise_schedule = 1;
    exercise_schedule_interrupt = 1;
    exercise = (long long)"Existing scheduled task restart exercise";
    exercise_sent = 1;
    exercise_finished = 1;
    capture = get_list(args, 2);
    }
    if ((length_list(args) == 3 && ep_str_equals(get_list(args, 1), (long long)"--tasks"))) {
    section = (long long)"tasks";
    capture = get_list(args, 2);
    }
    if ((length_list(args) == 3 && (ep_str_equals(get_list(args, 1), (long long)"--memory") || ep_str_equals(get_list(args, 1), (long long)"--identity")))) {
    section = (long long)substring((char*)get_list(args, 1), 2, (string_length((char*)get_list(args, 1)) - 2));
    capture = get_list(args, 2);
    }
    if ((length_list(args) == 3 && ep_str_equals(get_list(args, 1), (long long)"--sources"))) {
    capture = get_list(args, 2);
    }
    mobile_menu = 0;
    runtime_ready = 0;
    runtime_child = 0;
    token_path = ep_getenv((long long)"ECHOLITE_NATIVE_TOKEN_FILE");
    if (ep_str_equals(token_path, (long long)"")) {
    token_path = concat(home, (long long)"/native-runtime.token");
    ep_dlcall3(ep_dlsym(native_system(), (long long)"setenv"), (long long)"ECHOLITE_NATIVE_TOKEN_FILE", token_path, 1);
    }
    if (((!ep_str_equals(capture, (long long)"")) && ep_str_equals(exercise, (long long)""))) {
    runtime_ready = 1;
    } else {
    runtime_child = process_spawn_streams(runtime_executable, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)root); append_list(_lit_list, (long long)home); append_list(_lit_list, (long long)token_path); _lit_list; }), -1, -1, 0, (long long)"", 0);
    if (runtime_child == 0) {
    runtime_ready = -1;
    notice = (long long)"Unable to start the native runtime manager.";
    }
    }
    while (raylib_window_should_close() == 0) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetMouseCursor"), 0);
    ui_viewport_update();
    width = (raylib_get_screen_width() / UI_SCALE);
    height = (((raylib_get_screen_height() / UI_SCALE) - UI_TOP) - UI_BOTTOM);
    content_width = editor_min(864, (width - 312));
    left = (248 + (((width - 248) - content_width) / 2));
    if (native_android()) {
    left = 16;
    content_width = (width - 32);
    }
    SELECT_TOP = 110;
    SELECT_BOTTOM = (height - 64);
    if (ep_str_equals(section, (long long)"chat")) {
    SELECT_BOTTOM = (height - 230);
    }
    if (runtime_child > 0) {
    runtime_exit = process_poll(runtime_child);
    if (runtime_exit != -1) {
    runtime_child = 0;
    if (runtime_exit == 0) {
    runtime_ready = 1;
    notice = (long long)"";
    } else {
    runtime_ready = -1;
    notice = (long long)"Local model startup needs attention. See native-runtime.log in your state folder.";
    if ((!ep_str_equals(exercise, (long long)""))) {
    printf("%s\n", (char*)notice);
    raylib_close_window();
    ret_val = 1;
    goto L_cleanup;
    }
    }
    }
    }
    if (stop_child > 0) {
    stop_exit = process_poll(stop_child);
    if (stop_exit != -1) {
    stop_child = 0;
    if (stop_exit != 0) {
    notice = (long long)"Stop request finished; checking the saved turn.";
    }
    }
    }
    if (child > 0) {
    exit_code = process_poll(child);
    if (exit_code != -1) {
    child = 0;
    if (ep_str_equals(operation, (long long)"image-import")) {
    imported = attachment_finish(db, project, import_file, exit_code);
    import_file = 0;
    if (ep_str_equals(result_cache_scalar(db, (long long)"SELECT json_extract(?,'$.status')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)imported); _lit_list; })), (long long)"ok")) {
    attachment = result_cache_scalar(db, (long long)"SELECT json_extract(?,'$.memory')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)imported); _lit_list; }));
    attachment_path = import_path;
    exercise_imported = 1;
    notice = (long long)"";
    } else {
    notice = result_cache_scalar(db, (long long)"SELECT json_extract(?,'$.text')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)imported); _lit_list; }));
    if ((!ep_str_equals(exercise_image, (long long)""))) {
    printf("%s\n", (char*)notice);
    raylib_close_window();
    ret_val = 1;
    goto L_cleanup;
    }
    }
    }
    was_stopped = 0;
    if (ep_str_equals(operation, (long long)"chat")) {
    exercise_finished = 1;
    if ((db != 0 && (!ep_str_equals(active_turn, (long long)"")))) {
    was_stopped = ep_str_equals(result_cache_scalar(db, (long long)"SELECT status FROM turns WHERE id=? AND project=?", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)active_turn); append_list(_lit_list, (long long)project); _lit_list; })), (long long)"abandoned");
    }
    }
    if (exit_code != 0) {
    if (((ep_str_equals(operation, (long long)"chat") && was_stopped == 0) && scheduled_run == 0)) {
    draft = submitted;
    attachment = submitted_attachment;
    attachment_path = submitted_attachment_path;
    }
    if ((!ep_str_equals(operation, (long long)"image-import"))) {
    notice = concat((long long)"The local operation stopped (exit ", concat(int_to_string(exit_code), (long long)"). Your draft and saved conversation are retained."));
    }
    } else {
    if ((!ep_str_equals(operation, (long long)"image-import"))) {
    notice = (long long)"";
    }
    }
    if (was_stopped) {
    notice = (long long)"Stopped. Conversation saved; completed tool effects remain.";
    printf("%s\n", (char*)(long long)"UI confirmed abandoned turn and retained conversation");
    if (stop_started > 0) {
    printf("%s\n", (char*)concat((long long)"UI stop-to-idle milliseconds: ", int_to_string((transport_now(native_system()) - stop_started))));
    }
    }
    if ((((exit_code != 0 && ep_str_equals(operation, (long long)"chat")) && (!ep_str_equals(exercise, (long long)""))) && was_stopped == 0)) {
    printf("%s\n", (char*)notice);
    raylib_close_window();
    ret_val = 1;
    goto L_cleanup;
    }
    if (ep_str_equals(operation, (long long)"new")) {
    selected = (long long)"";
    }
    if (scheduled_run) {
    scheduled_run = 0;
    exercise_schedule_done = 1;
    last_activity = transport_now(native_system());
    if (was_stopped) {
    notice = (long long)"Scheduled work stopped. Your draft is retained; inspect Tasks before rescheduling.";
    if ((exercise_schedule_interrupt == 2 && ep_str_equals(draft, (long long)"User draft preserved while scheduled work stops."))) {
    printf("%s\n", (char*)(long long)"UI preserved the unsent draft after scheduled interruption");
    }
    }
    }
    operation = (long long)"";
    }
    }
    if ((frames % 15) == 0) {
    if ((db == 0 && ep_file_exists(concat(home, (long long)"/memory.sqlite3")) == 1)) {
    db = sql_open(concat(home, (long long)"/memory.sqlite3"));
    ep_sqlite3_exec(db, (long long)"PRAGMA query_only=ON; PRAGMA busy_timeout=100;", 0, 0, 0);
    }
    if (db != 0) {
    sessions = chat_sessions(db, project);
    task_rows = ui_schedule_rows(db, project);
    current_session = result_cache_scalar(db, (long long)"SELECT memory FROM sessions WHERE project=? AND closed IS NULL", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)project); _lit_list; }));
    if (ep_str_equals(selected, (long long)"")) {
    selected = current_session;
    }
    turns = chat_turns(db, selected);
    image_turns = sql_query_params(db, (long long)"SELECT i.turn_id,a.path FROM turn_images i JOIN image_assets a ON a.memory=i.image JOIN session_turns s ON s.turn_id=i.turn_id WHERE s.session=? AND a.project=?", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)selected); append_list(_lit_list, (long long)project); _lit_list; }));
    }
    }
    wheel = chat_wheel(RAYLIB_HANDLE);
    if ((((((native_android() && mobile_menu == 0) && EDIT_MENU == 0) && UI_TOUCH_START_X >= left) && UI_TOUCH_START_Y >= 110) && UI_TOUCH_START_Y < (height - 200))) {
    wheel = UI_TOUCH_DELTA;
    }
    if ((wheel != 0 && ep_str_equals(section, (long long)"chat"))) {
    scroll = (scroll - wheel);
    follow_bottom = 0;
    }
    if (raylib_is_key_pressed(266)) {
    scroll = (scroll - 260);
    follow_bottom = 0;
    }
    if (raylib_is_key_pressed(267)) {
    scroll = (scroll + 260);
    }
    if (scroll < 0) {
    scroll = 0;
    }
    clicked = (UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0));
    user_activity = ((((((clicked || wheel != 0) || raylib_is_key_pressed(259)) || raylib_is_key_pressed(257)) || raylib_is_key_down(343)) || raylib_is_key_pressed(266)) || raylib_is_key_pressed(267));
    if ((wheel != 0 && (ep_str_equals(section, (long long)"memory") || ep_str_equals(section, (long long)"identity")))) {
    pane_scroll = editor_max(0, (pane_scroll - wheel));
    }
    if ((wheel != 0 && ep_str_equals(section, (long long)"tasks"))) {
    task_scroll = (task_scroll - wheel);
    }
    if (task_scroll < 0) {
    task_scroll = 0;
    }
    if (user_activity) {
    last_activity = transport_now(native_system());
    }
    if ((clicked == 1 && (native_android() == 0 || mobile_menu))) {
    if (((hit(24, 104, 208, 40) && child == 0) && stop_child == 0)) {
    child = process_spawn_streams(core, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"session-start"); append_list(_lit_list, (long long)project); append_list(_lit_list, (long long)(long long)"New conversation"); _lit_list; }), -1, -1, 0, (long long)"", 0);
    operation = (long long)"new";
    draft = (long long)"";
    attachment = (long long)"";
    attachment_path = (long long)"";
    mobile_menu = 0;
    section = (long long)"chat";
    follow_bottom = 1;
    }
    if (hit(16, (height - 214), 216, 38)) {
    mobile_menu = 0;
    section = (long long)"tasks";
    }
    if (hit(16, (height - 168), 216, 38)) {
    mobile_menu = 0;
    section = (long long)"memory";
    }
    if (hit(16, (height - 122), 216, 38)) {
    mobile_menu = 0;
    section = (long long)"identity";
    }
    si = 0;
    while (si < length_list(sessions)) {
    if ((hit(16, (192 + (si * 42)), 216, 38) && (192 + (si * 42)) < (height - 256))) {
    selected = get_list(get_list(sessions, si), 0);
    turns = chat_turns(db, selected);
    mobile_menu = 0;
    section = (long long)"chat";
    follow_bottom = 1;
    }
    si = (si + 1);
    }
    }
    if (((native_android() && clicked) && hit((width - 56), 18, 40, 40))) {
    mobile_menu = (1 - mobile_menu);
    android_keyboard(0);
    clicked = 0;
    }
    choose_image = (clicked && hit((left + 16), (height - 108), 152, 28));
    if (((((((!ep_str_equals(exercise_image, (long long)"")) && exercise_imported == 0) && frames > 3) && child == 0) && stop_child == 0) && db != 0)) {
    choose_image = 1;
    }
    if ((((((choose_image && ep_str_equals(section, (long long)"chat")) && child == 0) && stop_child == 0) && db != 0) && (ep_str_equals(selected, (long long)"") || string_equals(selected, current_session)))) {
    chosen = exercise_image;
    if (ep_str_equals(chosen, (long long)"")) {
    chosen = attachment_pick();
    }
    if ((!ep_str_equals(chosen, (long long)""))) {
    pending = attachment_begin(core, project, chosen);
    child = get_list(pending, 0);
    import_file = get_list(pending, 1);
    if (child > 0) {
    import_path = chosen;
    operation = (long long)"image-import";
    notice = (long long)"Adding image...";
    } else {
    notice = (long long)"Unable to start image import";
    }
    }
    }
    if (((((clicked && child == 0) && stop_child == 0) && (!ep_str_equals(attachment, (long long)""))) && hit(((left + content_width) - 58), (height - 220), 28, 28))) {
    attachment = (long long)"";
    attachment_path = (long long)"";
    }
    previous_draft = draft;
    draft = editor_handle(draft, (left + 20), (height - 176), (content_width - 88), 60, (ep_str_equals(section, (long long)"chat") && mobile_menu == 0));
    if (string_equals(previous_draft, draft) == 0) {
    user_activity = 1;
    last_activity = transport_now(native_system());
    }
    if (EDIT_MENU_USED) {
    clicked = 0;
    }
    send_requested = (((EDIT_FOCUS && raylib_is_key_pressed(257)) && raylib_is_key_down(340) == 0) && raylib_is_key_down(344) == 0);
    if (((((((((!ep_str_equals(exercise, (long long)"")) && (ep_str_equals(exercise_image, (long long)"") || exercise_imported == 1)) && exercise_sent == 0) && frames > 3) && db != 0) && child == 0) && stop_child == 0) && runtime_ready == 1)) {
    send_requested = 1;
    exercise_sent = 1;
    }
    stop_clicked = 0;
    if ((clicked && hit(((left + content_width) - 56), (height - 112), 36, 32))) {
    if ((child > 0 && ep_str_equals(operation, (long long)"chat"))) {
    stop_clicked = 1;
    } else {
    send_requested = 1;
    }
    }
    if (((exercise_stop && exercise_live_seen) && stop_requested == 0)) {
    stop_clicked = 1;
    }
    if (((scheduled_run && exercise_schedule_interrupt == 1) && exercise_live_seen)) {
    draft = (long long)"User draft preserved while scheduled work stops.";
    user_activity = 1;
    exercise_schedule_interrupt = 2;
    printf("%s\n", (char*)(long long)"UI inserted a draft during scheduled thinking through the activity cancellation path");
    }
    if ((scheduled_run && user_activity)) {
    stop_clicked = 1;
    }
    if (((child > 0 && ep_str_equals(operation, (long long)"chat")) && db != 0)) {
    if (ep_str_equals(active_turn, (long long)"")) {
    active_turn = result_cache_scalar(db, (long long)"SELECT id FROM turns WHERE project=? AND id>CAST(? AS INTEGER) ORDER BY id LIMIT 1", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)project); append_list(_lit_list, (long long)turn_floor); _lit_list; }));
    }
    if (stop_clicked) {
    if (stop_requested == 0) {
    stop_started = transport_now(native_system());
    }
    stop_requested = 1;
    notice = (long long)"Stopping...";
    }
    if (((stop_requested && stop_child == 0) && (!ep_str_equals(active_turn, (long long)"")))) {
    if (ep_str_equals(result_cache_scalar(db, (long long)"SELECT status FROM turns WHERE id=? AND project=?", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)active_turn); append_list(_lit_list, (long long)project); _lit_list; })), (long long)"pending")) {
    stop_child = process_spawn_streams(core, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"turn-abandon"); append_list(_lit_list, (long long)project); append_list(_lit_list, (long long)active_turn); _lit_list; }), -1, -1, 0, (long long)"", 0);
    if (stop_child == 0) {
    stop_requested = 0;
    notice = (long long)"Unable to send stop request. Try Stop again.";
    }
    }
    }
    }
    if (((((((send_requested && ep_str_equals(section, (long long)"chat")) && runtime_ready == 1) && child == 0) && stop_child == 0) && ((!ep_str_equals(string_trim(draft), (long long)"")) || (!ep_str_equals(attachment, (long long)"")))) && (ep_str_equals(selected, (long long)"") || string_equals(selected, current_session)))) {
    stop_requested = 0;
    active_turn = (long long)"";
    turn_floor = result_cache_scalar(db, (long long)"SELECT coalesce(max(id),0) FROM turns", ({ long long _lit_list = create_list(); _lit_list; }));
    if ((ep_str_equals(string_trim(draft), (long long)"") && (!ep_str_equals(attachment, (long long)"")))) {
    draft = (long long)"Describe this image.";
    }
    if (ep_str_equals(attachment, (long long)"")) {
    child = process_spawn_streams(core, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"chat"); append_list(_lit_list, (long long)project); append_list(_lit_list, (long long)draft); _lit_list; }), -1, -1, 0, (long long)"", 0);
    } else {
    child = process_spawn_streams(core, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"chat-image"); append_list(_lit_list, (long long)project); append_list(_lit_list, (long long)attachment); append_list(_lit_list, (long long)draft); _lit_list; }), -1, -1, 0, (long long)"", 0);
    }
    if (child > 0) {
    operation = (long long)"chat";
    submitted = draft;
    submitted_attachment = attachment;
    submitted_attachment_path = attachment_path;
    attachment = (long long)"";
    attachment_path = (long long)"";
    draft = (long long)"";
    follow_bottom = 1;
    notice = (long long)"";
    } else {
    notice = (long long)"Unable to start the local conversation core.";
    }
    }
    if (((((frames % 30) == 0 && db != 0) && (ep_str_equals(capture, (long long)"") || exercise_schedule)) && (ep_str_equals(exercise, (long long)"") || exercise_finished))) {
    now = transport_now(native_system());
    if (ui_schedule_ready(now, last_activity, last_dispatch, (child > 0 || stop_child > 0), runtime_ready, draft, attachment)) {
    if ((!ep_str_equals(schedule_due(db, project), (long long)""))) {
    last_dispatch = now;
    turn_floor = result_cache_scalar(db, (long long)"SELECT coalesce(max(id),0) FROM turns", ({ long long _lit_list = create_list(); _lit_list; }));
    active_turn = (long long)"";
    stop_requested = 0;
    child = process_spawn_streams(core, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"chat-due"); append_list(_lit_list, (long long)project); _lit_list; }), -1, -1, 0, (long long)"", 0);
    if (child > 0) {
    scheduled_run = 1;
    exercise_live_seen = 0;
    operation = (long long)"chat";
    submitted = (long long)"";
    submitted_attachment = (long long)"";
    submitted_attachment_path = (long long)"";
    selected = current_session;
    follow_bottom = 1;
    notice = (long long)"Running a due task locally. Type or click Stop to interrupt.";
    printf("%s\n", (char*)(long long)"UI dispatched one due task through the normal conversation core");
    }
    }
    }
    }
    if (((((!ep_str_equals(capture, (long long)"")) && length_list(args) == 3) && ep_str_equals(get_list(args, 1), (long long)"--sources")) && length_list(turns) > 0)) {
    SOURCES_OPEN = get_list(get_list(turns, (length_list(turns) - 1)), 0);
    }
    ui_begin_drawing();
    raylib_clear_background(bg);
    if ((native_android() == 0 || mobile_menu)) {
    raylib_draw_rectangle(0, 0, 248, height, sidebar);
    raylib_draw_rectangle(247, 0, 1, height, border);
    ui_icon((long long)"echo", 24, 29, 4, mint);
    ui_wordmark(60, 34, 2, white);
    label((long long)"A MIND OF YOUR OWN", 24, 70, 11, muted);
    button_tint = surface;
    if (hit(24, 104, 208, 40)) {
    button_tint = 4281283881;
    }
    ui_frame(24, 104, 208, 40, button_tint, color(46, 54, 62));
    ui_icon((long long)"plus", 38, 117, 2, mint);
    label((long long)"New conversation", 62, 117, 14, white);
    label((long long)"CONVERSATIONS", 24, 170, 11, muted);
    si = 0;
    while ((si < length_list(sessions) && (192 + (si * 42)) < (height - 256))) {
    item = get_list(sessions, si);
    active = (string_equals(selected, get_list(item, 0)) && ep_str_equals(section, (long long)"chat"));
    row_tint = sidebar;
    if ((active || hit(16, (192 + (si * 42)), 216, 38))) {
    row_tint = surface;
    }
    raylib_draw_rectangle(16, (192 + (si * 42)), 216, 38, row_tint);
    if (active) {
    raylib_draw_rectangle(16, (192 + (si * 42)), 2, 38, mint);
    }
    ui_icon((long long)"chat", 30, (204 + (si * 42)), 2, muted);
    label(ui_text_fit(get_list(item, 1), 164, 14), 54, (204 + (si * 42)), 14, white);
    si = (si + 1);
    }
    if (length_list(sessions) == 0) {
    label((long long)"Nothing here yet.", 24, 208, 12, muted);
    }
    raylib_draw_line(24, (height - 233), 224, (height - 233), border);
    ui_nav((long long)"Tasks", (long long)"tasks", (height - 214), ep_str_equals(section, (long long)"tasks"));
    ui_nav((long long)"Memory", (long long)"memory", (height - 168), ep_str_equals(section, (long long)"memory"));
    ui_nav((long long)"Me", (long long)"me", (height - 122), ep_str_equals(section, (long long)"identity"));
    raylib_draw_line(24, (height - 70), 224, (height - 70), border);
    state_tint = mint;
    state_text = (long long)"LOCAL RUNTIME";
    if (runtime_ready != 1) {
    state_tint = 4286954457;
    state_text = (long long)"PREPARING RUNTIME";
    }
    raylib_draw_rectangle(26, (height - 44), 6, 6, state_tint);
    label(state_text, 44, (height - 46), 11, muted);
    }
    if ((native_android() == 0 || mobile_menu == 0)) {
    title = (long long)"Conversation";
    subtitle = (long long)"Qwen3.5 4B / 262K context";
    if (ep_str_equals(section, (long long)"tasks")) {
    title = (long long)"Tasks";
    subtitle = (long long)"Commitments, progress and outcomes";
    } else {
    if (ep_str_equals(section, (long long)"memory")) {
    title = (long long)"Memory";
    subtitle = (long long)"Continuity through experience";
    } else {
    if (ep_str_equals(section, (long long)"identity")) {
    title = (long long)"Me";
    subtitle = (long long)"Identity and working perspective";
    }
    }
    }
    label(title, left, 28, 22, white);
    label(subtitle, left, 61, 12, muted);
    network_label = (long long)"WEB + LOCAL";
    if (native_android() == 0) {
    ui_frame(((left + content_width) - 114), 30, 114, 28, surface, color(46, 54, 62));
    label(network_label, ((left + content_width) - 104), 39, 11, mint);
    }
    raylib_draw_line(left, 92, (left + content_width), 92, border);
    if (ep_str_equals(section, (long long)"chat")) {
    viewport = (height - 340);
    if ((!ep_str_equals(attachment, (long long)""))) {
    viewport = (viewport - 32);
    }
    SELECT_BOTTOM = (110 + viewport);
    if (follow_bottom == 1) {
    scroll = (body_height - viewport);
    }
    if (scroll > (body_height - viewport)) {
    scroll = (body_height - viewport);
    }
    if (scroll < 0) {
    scroll = 0;
    }
    ep_dlcall4(ep_dlsym(RAYLIB_HANDLE, (long long)"BeginScissorMode"), (left * UI_SCALE), ((110 + UI_TOP) * UI_SCALE), (content_width * UI_SCALE), (viewport * UI_SCALE));
    row_y = (125 - scroll);
    if (length_list(turns) == 0) {
    ui_icon((long long)"echo", (left + 40), 140, 4, mint);
    label((long long)"Space to think.", (left + 40), 188, 24, white);
    label((long long)"Room to remember.", (left + 40), 226, 24, mint);
    selectable_text((long long)"Ask a question, explore an idea, or pick up where you left off. Your conversations and memories stay with you.", (left + 40), 278, (content_width - 80), 15, muted);
    }
    ti = 0;
    while (ti < length_list(turns)) {
    turn = get_list(turns, ti);
    speaker = (long long)"YOU";
    if (ep_str_equals(get_list(turn, 8), (long long)"scheduled-event")) {
    speaker = (long long)"SCHEDULED TASK";
    }
    user_height = ((length_list(layout_lines(get_list(turn, 1), (content_width - 60), 18)) * 27) + 56);
    image_index = 0;
    while (image_index < length_list(image_turns)) {
    image_record = get_list(image_turns, image_index);
    if (string_equals(get_list(image_record, 0), get_list(turn, 0))) {
    user_height = ((user_height + (length_list(layout_lines(concat((long long)"Image · ", path_basename(get_list(image_record, 1))), (content_width - 60), 13)) * 22)) + 8);
    }
    image_index = (image_index + 1);
    }
    ui_frame((left + 8), (row_y - 12), (content_width - 16), user_height, surface, color(46, 54, 62));
    label(speaker, (left + 24), row_y, 11, muted);
    row_y = (row_y + 24);
    ii = 0;
    while (ii < length_list(image_turns)) {
    image_row = get_list(image_turns, ii);
    if (string_equals(get_list(image_row, 0), get_list(turn, 0))) {
    row_y = selectable_text(concat((long long)"Image · ", path_basename(get_list(image_row, 1))), (left + 24), row_y, (content_width - 60), 13, mint);
    row_y = (row_y + 8);
    }
    ii = (ii + 1);
    }
    row_y = selectable_text(get_list(turn, 1), (left + 24), row_y, (content_width - 60), 18, white);
    row_y = (row_y + 45);
    ui_icon((long long)"echo", (left + 24), (row_y - 1), 2, mint);
    label((long long)"ECHOLITE", (left + 46), row_y, 11, mint);
    if ((!ep_str_equals(get_list(turn, 2), (long long)""))) {
    label((long long)"Copy", ((left + content_width) - 64), row_y, 12, muted);
    if ((((clicked && hit(((left + content_width) - 74), (row_y - 4), 60, 24)) && row_y >= 110) && row_y < (height - 220))) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetClipboardText"), get_list(turn, 2));
    }
    }
    row_y = (row_y + 26);
    thought = get_list(turn, 4);
    if ((((!ep_str_equals(exercise, (long long)"")) && ep_str_equals(get_list(turn, 7), (long long)"1")) && (!ep_str_equals(thought, (long long)"")))) {
    thinking_open = get_list(turn, 0);
    if (exercise_live_seen == 0) {
    printf("%s\n", (char*)(long long)"UI observed live model thinking before turn completion");
    exercise_live_seen = 1;
    }
    }
    if ((!ep_str_equals(thought, (long long)""))) {
    ui_frame((left + 24), row_y, (content_width - 48), 32, surface, color(46, 54, 62));
    arrow = (long long)">  Thinking";
    if (string_equals(thinking_open, get_list(turn, 0))) {
    arrow = (long long)"v  Thinking";
    }
    thinking_label = concat(arrow, concat((long long)"  ·  ", concat(get_list(turn, 5), (long long)" output tokens")));
    if (ep_str_equals(get_list(turn, 7), (long long)"1")) {
    thinking_label = concat(arrow, (long long)"  ·  generating");
    }
    label(thinking_label, (left + 38), (row_y + 10), 12, mint);
    if ((((clicked && hit((left + 24), row_y, (content_width - 48), 36)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= 110) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < (height - 200))) {
    if (string_equals(thinking_open, get_list(turn, 0))) {
    thinking_open = (long long)"";
    } else {
    thinking_open = get_list(turn, 0);
    }
    follow_bottom = 0;
    }
    row_y = (row_y + 46);
    if (string_equals(thinking_open, get_list(turn, 0))) {
    row_y = selectable_text(thought, (left + 38), row_y, (content_width - 90), 15, muted);
    row_y = (row_y + 15);
    }
    }
    if ((!ep_str_equals(get_list(turn, 6), (long long)""))) {
    row_y = selectable_text(get_list(turn, 6), (left + 24), row_y, (content_width - 60), 13, mint);
    row_y = (row_y + 10);
    }
    if (((((!ep_str_equals(exercise, (long long)"")) && ep_str_equals(get_list(turn, 7), (long long)"1")) && starts_with(get_list(turn, 2), (long long)"Draft while generating:")) && exercise_draft_seen == 0)) {
    printf("%s\n", (char*)(long long)"UI observed a streaming answer draft before turn completion");
    exercise_draft_seen = 1;
    }
    if ((!ep_str_equals(get_list(turn, 2), (long long)""))) {
    row_y = ui_response(get_list(turn, 2), (left + 24), row_y, (content_width - 48), white);
    } else {
    pending_text = concat((long long)"Turn ", get_list(turn, 3));
    if (ep_str_equals(get_list(turn, 3), (long long)"pending")) {
    pending_text = (long long)"Working locally...";
    } else {
    if (ep_str_equals(get_list(turn, 3), (long long)"abandoned")) {
    pending_text = (long long)"Response stopped. Your message is saved.";
    if (ep_str_equals(get_list(turn, 8), (long long)"scheduled-event")) {
    pending_text = (long long)"Scheduled work stopped. Completed effects remain.";
    }
    }
    }
    row_y = selectable_text(pending_text, (left + 24), row_y, (content_width - 60), 17, muted);
    }
    prior_sources_open = SOURCES_OPEN;
    row_y = ui_sources(db, get_list(turn, 0), get_list(turn, 9), (left + 24), row_y, (content_width - 48));
    if (string_equals(prior_sources_open, SOURCES_OPEN) == 0) {
    follow_bottom = 0;
    }
    row_y = (row_y + 40);
    ti = (ti + 1);
    }
    body_height = ((row_y + scroll) - 125);
    ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"EndScissorMode"));
    if (body_height > viewport) {
    thumb_height = editor_max(24, ((viewport * viewport) / body_height));
    thumb_y = (110 + ((scroll * (viewport - thumb_height)) / (body_height - viewport)));
    raylib_draw_rectangle(((left + content_width) - 3), thumb_y, 2, thumb_height, border);
    }
    if ((!ep_str_equals(attachment, (long long)""))) {
    ui_frame((left + 24), (height - 220), (content_width - 48), 28, surface, color(46, 54, 62));
    ep_dlcall4(ep_dlsym(RAYLIB_HANDLE, (long long)"BeginScissorMode"), ((left + 35) * UI_SCALE), (((height - 218) + UI_TOP) * UI_SCALE), ((content_width - 106) * UI_SCALE), (26 * UI_SCALE));
    label(concat((long long)"Image: ", path_basename(attachment_path)), (left + 38), (height - 213), 13, mint);
    ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"EndScissorMode"));
    label((long long)"x", ((left + content_width) - 50), (height - 213), 14, muted);
    }
    composer_edge = border;
    if (EDIT_FOCUS) {
    composer_edge = 4285102169;
    }
    ui_frame(left, (height - 196), content_width, 132, surface, composer_edge);
    raylib_draw_rectangle((left + 20), (height - 196), 24, 2, mint);
    ep_dlcall4(ep_dlsym(RAYLIB_HANDLE, (long long)"BeginScissorMode"), ((left + 20) * UI_SCALE), (((height - 176) + UI_TOP) * UI_SCALE), ((content_width - 88) * UI_SCALE), (60 * UI_SCALE));
    if (ep_str_equals(draft, (long long)"")) {
    label((long long)"Message EchoLite...", (left + 20), (height - 176), 18, muted);
    }
    editor_draw((left + 20), (height - 176), (content_width - 88), 60, white, mint);
    ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"EndScissorMode"));
    raylib_draw_rectangle(((left + content_width) - 56), (height - 112), 36, 32, mint);
    if ((child > 0 && ep_str_equals(operation, (long long)"chat"))) {
    raylib_draw_rectangle(((left + content_width) - 44), (height - 102), 12, 12, bg);
    } else {
    ui_icon((long long)"up", ((left + content_width) - 43), (height - 103), 2, bg);
    }
    composer_status = (long long)"";
    if ((!ep_str_equals(EDIT_ERROR, (long long)""))) {
    composer_status = EDIT_ERROR;
    }
    if (child > 0) {
    composer_status = (long long)"Working locally...";
    if (ep_str_equals(operation, (long long)"chat")) {
    composer_status = (long long)"Generating locally · Click square to stop";
    }
    } else {
    if (((!ep_str_equals(selected, (long long)"")) && string_equals(selected, current_session) == 0)) {
    composer_status = (long long)"Saved conversation  ·  Start a new conversation to continue";
    }
    }
    if (runtime_child > 0) {
    composer_status = (long long)"Preparing local models...";
    }
    if ((!ep_str_equals(notice, (long long)""))) {
    composer_status = notice;
    }
    ui_icon((long long)"image", (left + 20), (height - 104), 2, mint);
    label((long long)"Attach image", (left + 42), (height - 104), 12, mint);
    label(ui_text_fit(composer_status, (content_width - 250), 11), (left + 170), (height - 103), 11, muted);
    label((long long)"Enter to send / Shift+Enter for a new line", (left + 4), (height - 38), 11, muted);
    label((long long)"ON DEVICE", ((left + content_width) - 64), (height - 38), 10, mint);
    } else {
    if (ep_str_equals(section, (long long)"tasks")) {
    label((long long)"Your next steps", (left + 24), 143, 24, white);
    selectable_text((long long)"Due tasks run while open and idle. Typing interrupts background work.", (left + 24), 184, (content_width - 48), 12, muted);
    SELECT_TOP = 232;
    task_height = (height - 300);
    task_total = 0;
    layout_index = 0;
    while (layout_index < length_list(task_rows)) {
    layout_row = get_list(task_rows, layout_index);
    task_total = ((task_total + (length_list(layout_lines(get_list(layout_row, 4), (content_width - 101), 16)) * 25)) + 89);
    layout_index = (layout_index + 1);
    }
    if (task_scroll > (task_total - task_height)) {
    task_scroll = (task_total - task_height);
    }
    if (task_scroll < 0) {
    task_scroll = 0;
    }
    ep_dlcall4(ep_dlsym(RAYLIB_HANDLE, (long long)"BeginScissorMode"), ((left + 20) * UI_SCALE), ((232 + UI_TOP) * UI_SCALE), ((content_width - 40) * UI_SCALE), (task_height * UI_SCALE));
    task_y = (238 - task_scroll);
    task_i = 0;
    while (task_i < length_list(task_rows)) {
    task_row = get_list(task_rows, task_i);
    row_height = ((length_list(layout_lines(get_list(task_row, 4), (content_width - 101), 16)) * 25) + 75);
    ui_frame((left + 24), task_y, (content_width - 48), row_height, surface, color(46, 54, 62));
    task_title = concat((long long)"Task ", concat(get_list(task_row, 1), concat((long long)"  ·  ", get_list(task_row, 5))));
    label(task_title, (left + 40), (task_y + 12), 13, mint);
    selectable_text(get_list(task_row, 4), (left + 40), (task_y + 35), (content_width - 100), 16, white);
    task_detail = get_list(task_row, 2);
    if ((!ep_str_equals(get_list(task_row, 3), (long long)""))) {
    task_detail = concat(task_detail, concat((long long)"  ·  ", get_list(task_row, 3)));
    }
    if ((!ep_str_equals(get_list(task_row, 7), (long long)""))) {
    task_detail = concat(task_detail, concat((long long)"  ·  turn ", get_list(task_row, 7)));
    }
    label(ui_text_fit(task_detail, (content_width - 90), 12), (left + 40), ((task_y + row_height) - 23), 12, muted);
    if (ep_str_equals(get_list(task_row, 2), (long long)"armed")) {
    label((long long)"Cancel", ((left + content_width) - 104), (task_y + 12), 13, mint);
    if ((((((clicked && child == 0) && stop_child == 0) && hit(((left + content_width) - 116), (task_y + 5), 80, 28)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= 232) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < (232 + task_height))) {
    child = process_spawn_streams(core, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"schedule-cancel"); append_list(_lit_list, (long long)project); append_list(_lit_list, get_list(task_row, 0)); _lit_list; }), -1, -1, 0, (long long)"", 0);
    if (child > 0) {
    operation = (long long)"schedule-cancel";
    notice = (long long)"Cancelling saved schedule...";
    }
    }
    }
    task_y = ((task_y + row_height) + 14);
    task_i = (task_i + 1);
    }
    if (length_list(task_rows) == 0) {
    ui_frame((left + 24), 238, (content_width - 48), 180, surface, color(46, 54, 62));
    ui_icon((long long)"tasks", (left + 44), 262, 3, mint);
    label((long long)"Make room for what matters", (left + 76), 266, 17, white);
    selectable_text((long long)"Ask EchoLite to save a task and when to do it. Its objective, due time and outcome will appear here.", (left + 44), 312, (content_width - 88), 15, muted);
    }
    ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"EndScissorMode"));
    if ((!ep_str_equals(notice, (long long)""))) {
    label(notice, (left + 24), (height - 38), 12, muted);
    }
    } else {
    if (ep_str_equals(section, (long long)"memory")) {
    label((long long)"What stays with you", (left + 24), 143, 24, white);
    label((long long)"Recent retained records / current project", (left + 24), 184, 12, muted);
    SELECT_TOP = 220;
    ep_dlcall4(ep_dlsym(RAYLIB_HANDLE, (long long)"BeginScissorMode"), (left * UI_SCALE), ((220 + UI_TOP) * UI_SCALE), (content_width * UI_SCALE), ((height - 284) * UI_SCALE));
    row_y = (228 - pane_scroll);
    note_count = 0;
    if (db != 0) {
    notes = sql_query_params(db, (long long)"SELECT layer,substr(body,1,600),id,substr(created,1,10) FROM memories WHERE project=? AND status='active' AND source NOT IN ('tool-request','tool-receipt','session') ORDER BY id DESC LIMIT 24", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)project); _lit_list; }));
    note_count = length_list(notes);
    note_index = 0;
    while (note_index < length_list(notes)) {
    note = get_list(notes, note_index);
    card_height = ((length_list(layout_lines(get_list(note, 1), (content_width - 88), 16)) * 25) + 64);
    ui_frame((left + 24), row_y, (content_width - 48), card_height, surface, color(46, 54, 62));
    label(get_list(note, 0), (left + 44), (row_y + 16), 12, mint);
    label(concat((long long)"#", get_list(note, 2)), ((left + content_width) - 90), (row_y + 16), 12, muted);
    selectable_text(get_list(note, 1), (left + 44), (row_y + 42), (content_width - 88), 16, white);
    row_y = ((row_y + card_height) + 16);
    note_index = (note_index + 1);
    }
    }
    pane_total = ((row_y + pane_scroll) - 228);
    pane_scroll = editor_min(pane_scroll, editor_max(0, (pane_total - (height - 292))));
    if (note_count == 0) {
    ui_frame((left + 24), 228, (content_width - 48), 160, surface, color(46, 54, 62));
    ui_icon((long long)"memory", (left + 44), 250, 3, mint);
    label((long long)"Room for experience", (left + 76), 252, 17, white);
    selectable_text((long long)"Relevant experiences and notes will appear here as your conversations develop.", (left + 44), 300, (content_width - 88), 15, muted);
    }
    ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"EndScissorMode"));
    label((long long)"Stored locally / scroll to explore", (left + 24), (height - 38), 11, muted);
    } else {
    label((long long)"An evolving identity", (left + 24), 143, 24, white);
    label((long long)"Loaded each turn. Revised through experience.", (left + 24), 184, 12, muted);
    SELECT_TOP = 220;
    ep_dlcall4(ep_dlsym(RAYLIB_HANDLE, (long long)"BeginScissorMode"), (left * UI_SCALE), ((220 + UI_TOP) * UI_SCALE), (content_width * UI_SCALE), ((height - 284) * UI_SCALE));
    if (db != 0) {
    identities = sql_query_params(db, (long long)"SELECT body,id FROM me_versions ORDER BY id DESC LIMIT 1", ({ long long _lit_list = create_list(); _lit_list; }));
    if (length_list(identities) > 0) {
    identity = get_list(identities, 0);
    card_height = ((length_list(layout_lines(get_list(identity, 0), (content_width - 96), 18)) * 27) + 88);
    pane_scroll = editor_min(pane_scroll, editor_max(0, (card_height - (height - 292))));
    card_y = (228 - pane_scroll);
    ui_frame((left + 24), card_y, (content_width - 48), card_height, surface, color(46, 54, 62));
    raylib_draw_rectangle((left + 24), card_y, 3, card_height, mint);
    label((long long)"ME.TXT", (left + 48), (card_y + 18), 12, mint);
    label(concat((long long)"REV ", get_list(identity, 1)), ((left + content_width) - 100), (card_y + 18), 12, muted);
    selectable_text(get_list(identity, 0), (left + 48), (card_y + 56), (content_width - 96), 18, white);
    }
    }
    ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"EndScissorMode"));
    label((long long)"Versioned identity / changes apply at the next turn", (left + 24), (height - 38), 11, muted);
    }
    }
    }
    }
    if (native_android()) {
    ui_frame((width - 56), 18, 40, 40, surface, color(46, 54, 62));
    label((long long)"=", (width - 43), 29, 20, mint);
    }
    editor_menu_draw();
    raylib_end_drawing();
    frames = (frames + 1);
    if (((exercise_finished && (frames % 15) == 0) && length_list(turns) > 0)) {
    thinking_open = get_list(get_list(turns, (length_list(turns) - 1)), 0);
    }
    if (((((!ep_str_equals(capture, (long long)"")) && (exercise_schedule == 0 || exercise_schedule_done)) && stop_child == 0) && ((((ep_str_equals(exercise, (long long)"") && frames >= 3) && child == 0) && stop_child == 0) || (((((!ep_str_equals(exercise, (long long)"")) && exercise_finished) && (frames % 15) == 3) && length_list(turns) > 0) && (!ep_str_equals(get_list(get_list(turns, (length_list(turns) - 1)), 3), (long long)"pending")))))) {
    ui_capture(capture);
    raylib_close_window();
    ret_val = 0;
    goto L_cleanup;
    }
    }
    if (native_android()) {
    android_input_close();
    }
    raylib_close_window();
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(103);
    free_list(identities);
    identities = 0;
    free_list(image_turns);
    image_turns = 0;
    free_list(notes);
    notes = 0;
    free_list(pending);
    pending = 0;
    free_list(sessions);
    sessions = 0;
    free_list(task_rows);
    task_rows = 0;
    free_list(turns);
    turns = 0;
    return ret_val;
}

long long ui_viewport_update() {
    long long delta = 0;
    long long horizontal = 0;
    long long keyboard = 0;
    long long safe = 0;
    long long top = 0;
    long long usable = 0;
    long long ret_val = 0;

    ep_gc_push_root(&safe);

    ep_gc_maybe_collect();

    UI_POINTER_PRESSED = android_pointer_take();
    if (native_android()) {
    UI_SCALE = (raylib_get_screen_width() / 400);
    if (UI_SCALE < 1) {
    UI_SCALE = 1;
    }
    if (UI_SCALE > 4) {
    UI_SCALE = 4;
    }
    safe = alloc_bytes(16);
    if (ep_dlcall2(ep_dlsym(ANDROID_SDL, (long long)"SDL_GetWindowSafeArea"), ANDROID_INPUT_WINDOW, safe)) {
    top = process_integer((safe + 4), 4);
    usable = process_integer((safe + 12), 4);
    UI_TOP = (top / UI_SCALE);
    UI_BOTTOM = (((raylib_get_screen_height() - top) - usable) / UI_SCALE);
    }
    free_bytes(safe);
    keyboard = (android_keyboard_inset(ANDROID_SDL) / UI_SCALE);
    if (keyboard > UI_BOTTOM) {
    UI_BOTTOM = keyboard;
    }
    UI_TOUCH_DELTA = 0;
    if (UI_POINTER_PRESSED) {
    UI_TOUCH_START_X = (raylib_get_mouse_x() / UI_SCALE);
    UI_TOUCH_START_Y = ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP);
    UI_TOUCH_LAST_Y = UI_TOUCH_START_Y;
    UI_TOUCH_MOVED = 0;
    UI_TOUCH_STARTED = transport_now(native_system());
    }
    if (raylib_is_mouse_button_down(0)) {
    delta = (((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) - UI_TOUCH_START_Y);
    horizontal = ((raylib_get_mouse_x() / UI_SCALE) - UI_TOUCH_START_X);
    if ((((delta > 8 || delta < -8) || horizontal > 8) || horizontal < -8)) {
    UI_TOUCH_MOVED = 1;
    }
    if (UI_TOUCH_MOVED) {
    UI_TOUCH_DELTA = (((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) - UI_TOUCH_LAST_Y);
    }
    UI_TOUCH_LAST_Y = ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP);
    }
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long ui_screen_width() {
    long long ret_val = 0;

    ret_val = (raylib_get_screen_width() / UI_SCALE);
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long ui_screen_height() {
    long long ret_val = 0;

    ret_val = (((raylib_get_screen_height() / UI_SCALE) - UI_TOP) - UI_BOTTOM);
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long ui_mouse_x() {
    long long ret_val = 0;

    ret_val = (raylib_get_mouse_x() / UI_SCALE);
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long ui_mouse_y() {
    long long ret_val = 0;

    ret_val = ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP);
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long ui_transform(long long name, long long x, long long y, long long z) {
    long long a = 0;
    long long b = 0;
    long long c = 0;
    long long float_type = 0;
    long long values = 0;
    long long ret_val = 0;

    ep_gc_push_root(&a);
    ep_gc_push_root(&b);
    ep_gc_push_root(&c);
    ep_gc_push_root(&float_type);
    ep_gc_push_root(&values);
    ep_gc_push_root(&name);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&z);

    ep_gc_maybe_collect();

    if (UI_TRANSFORM_CIF == 0) {
    float_type = ep_dlsym(FONT_FFI, (long long)"ffi_type_float");
    UI_TRANSFORM_CIF = native_cif(ep_dlsym(FONT_FFI, (long long)"ffi_type_void"), ({ long long _lit_list = create_list(); append_list(_lit_list, float_type); append_list(_lit_list, float_type); append_list(_lit_list, float_type); _lit_list; }));
    }
    a = ({ long long _lit_list = create_list(); append_list(_lit_list, native_f32(x)); _lit_list; });
    b = ({ long long _lit_list = create_list(); append_list(_lit_list, native_f32(y)); _lit_list; });
    c = ({ long long _lit_list = create_list(); append_list(_lit_list, native_f32(z)); _lit_list; });
    values = ({ long long _lit_list = create_list(); append_list(_lit_list, get_list_data_ptr(a)); append_list(_lit_list, get_list_data_ptr(b)); append_list(_lit_list, get_list_data_ptr(c)); _lit_list; });
    ep_dlcall4(FONT_CALL, UI_TRANSFORM_CIF, ep_dlsym(RAYLIB_HANDLE, name), 0, get_list_data_ptr(values));
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    free_list(a);
    a = 0;
    free_list(b);
    b = 0;
    free_list(c);
    c = 0;
    free_list(values);
    values = 0;
    return ret_val;
}

long long ui_begin_drawing() {
    long long ret_val = 0;

    raylib_begin_drawing();
    if (native_android()) {
    ui_transform((long long)"rlScalef", UI_SCALE, UI_SCALE, 1);
    ui_transform((long long)"rlTranslatef", 0, UI_TOP, 0);
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long ui_scissor(long long x, long long y, long long width, long long height) {
    long long ret_val = 0;

    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);
    ep_gc_push_root(&height);

    ep_gc_maybe_collect();

    ret_val = ep_dlcall4(ep_dlsym(RAYLIB_HANDLE, (long long)"BeginScissorMode"), (x * UI_SCALE), ((y + UI_TOP) * UI_SCALE), (width * UI_SCALE), (height * UI_SCALE));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long ui_mouse_pressed() {
    long long ret_val = 0;

    ret_val = (UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0));
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long android_text_watch(long long userdata, long long event) {
    long long count = 0;
    long long event_type = 0;
    long long pointer = 0;
    long long ret_val = 0;

    ep_gc_push_root(&count);
    ep_gc_push_root(&pointer);
    ep_gc_push_root(&event);

    ep_gc_maybe_collect();

    event_type = process_integer(event, 4);
    if (event_type == 1025) {
    ep_dlcall1(ANDROID_INPUT_LOCK, ANDROID_INPUT_MUTEX);
    ANDROID_POINTER_PENDING = 1;
    ep_dlcall1(ANDROID_INPUT_UNLOCK, ANDROID_INPUT_MUTEX);
    }
    if (event_type != 771) {
    ret_val = 1;
    goto L_cleanup;
    }
    pointer = process_integer((event + 24), 8);
    if (pointer == 0) {
    ret_val = 1;
    goto L_cleanup;
    }
    count = ep_dlcall1(ANDROID_INPUT_LENGTH, pointer);
    ep_dlcall1(ANDROID_INPUT_LOCK, ANDROID_INPUT_MUTEX);
    if ((count > 0 && count <= (1048576 - ANDROID_INPUT_USED))) {
    ep_dlcall3(ANDROID_INPUT_COPY, (ANDROID_INPUT_BUFFER + ANDROID_INPUT_USED), pointer, count);
    ANDROID_INPUT_USED = (ANDROID_INPUT_USED + count);
    } else {
    if (count > 0) {
    ANDROID_INPUT_OVERFLOW = 1;
    }
    }
    ep_dlcall1(ANDROID_INPUT_UNLOCK, ANDROID_INPUT_MUTEX);
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long android_input_init(long long self_library) {
    long long count = 0;
    long long windows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&count);
    ep_gc_push_root(&windows);
    ep_gc_push_root(&self_library);

    ep_gc_maybe_collect();

    if (native_android() == 0) {
    ret_val = 1;
    goto L_cleanup;
    }
    if (ANDROID_INPUT_MUTEX != 0) {
    android_input_close();
    }
    ANDROID_SDL = ep_dlopen((long long)"libSDL3.so");
    if (ANDROID_SDL == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    ANDROID_INPUT_MUTEX = ep_dlcall0(ep_dlsym(ANDROID_SDL, (long long)"SDL_CreateMutex"));
    ANDROID_INPUT_BUFFER = ep_dlcall1(ep_dlsym(ANDROID_SDL, (long long)"SDL_malloc"), 1048577);
    ANDROID_INPUT_LOCK = ep_dlsym(ANDROID_SDL, (long long)"SDL_LockMutex");
    ANDROID_INPUT_UNLOCK = ep_dlsym(ANDROID_SDL, (long long)"SDL_UnlockMutex");
    ANDROID_INPUT_COPY = ep_dlsym(native_system(), (long long)"memcpy");
    ANDROID_INPUT_LENGTH = ep_dlsym(native_system(), (long long)"strlen");
    ANDROID_INPUT_WATCH = ep_dlsym(self_library, (long long)"android_text_watch");
    if (((ANDROID_INPUT_MUTEX == 0 || ANDROID_INPUT_BUFFER == 0) || ANDROID_INPUT_WATCH == 0)) {
    android_input_close();
    ret_val = 0;
    goto L_cleanup;
    }
    count = alloc_bytes(4);
    windows = ep_dlcall1(ep_dlsym(ANDROID_SDL, (long long)"SDL_GetWindows"), count);
    if ((windows != 0 && process_integer(count, 4) > 0)) {
    ANDROID_INPUT_WINDOW = process_integer(windows, 8);
    }
    ep_dlcall1(ep_dlsym(ANDROID_SDL, (long long)"SDL_free"), windows);
    free_bytes(count);
    if (ANDROID_INPUT_WINDOW == 0) {
    android_input_close();
    ret_val = 0;
    goto L_cleanup;
    }
    ep_dlcall2(ep_dlsym(ANDROID_SDL, (long long)"SDL_SetHint"), (long long)"SDL_ENABLE_SCREEN_KEYBOARD", (long long)"1");
    ep_dlcall2(ep_dlsym(ANDROID_SDL, (long long)"SDL_SetHint"), (long long)"SDL_TOUCH_MOUSE_EVENTS", (long long)"1");
    if (ep_dlcall2(ep_dlsym(ANDROID_SDL, (long long)"SDL_AddEventWatch"), ANDROID_INPUT_WATCH, 0) == 0) {
    android_input_close();
    ret_val = 0;
    goto L_cleanup;
    }
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long android_input_take() {
    long long text = 0;
    long long ret_val = 0;

    ep_gc_push_root(&text);

    ep_gc_maybe_collect();

    if (ANDROID_INPUT_MUTEX == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    ep_dlcall1(ANDROID_INPUT_LOCK, ANDROID_INPUT_MUTEX);
    poke_byte(ANDROID_INPUT_BUFFER, ANDROID_INPUT_USED, 0);
    text = ptr_to_str(ANDROID_INPUT_BUFFER);
    ANDROID_INPUT_USED = 0;
    ep_dlcall1(ANDROID_INPUT_UNLOCK, ANDROID_INPUT_MUTEX);
    ret_val = text;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long android_keyboard(long long visible) {
    long long operation = 0;
    long long ret_val = 0;

    ep_gc_push_root(&operation);

    ep_gc_maybe_collect();

    if (ANDROID_INPUT_WINDOW == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    operation = (long long)"SDL_StopTextInput";
    if (visible) {
    ep_dlcall1(ep_dlsym(ANDROID_SDL, (long long)"SDL_StopTextInput"), ANDROID_INPUT_WINDOW);
    operation = (long long)"SDL_StartTextInput";
    }
    ret_val = ep_dlcall1(ep_dlsym(ANDROID_SDL, operation), ANDROID_INPUT_WINDOW);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long android_input_close() {
    long long ret_val = 0;

    if (ANDROID_INPUT_WATCH != 0) {
    ep_dlcall2(ep_dlsym(ANDROID_SDL, (long long)"SDL_RemoveEventWatch"), ANDROID_INPUT_WATCH, 0);
    }
    if (ANDROID_INPUT_MUTEX != 0) {
    ep_dlcall1(ep_dlsym(ANDROID_SDL, (long long)"SDL_DestroyMutex"), ANDROID_INPUT_MUTEX);
    }
    if (ANDROID_INPUT_BUFFER != 0) {
    ep_dlcall1(ep_dlsym(ANDROID_SDL, (long long)"SDL_free"), ANDROID_INPUT_BUFFER);
    }
    ANDROID_INPUT_MUTEX = 0;
    ANDROID_INPUT_BUFFER = 0;
    ANDROID_INPUT_WATCH = 0;
    ANDROID_INPUT_WINDOW = 0;
    ANDROID_INPUT_USED = 0;
    ANDROID_INPUT_OVERFLOW = 0;
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long android_input_overflowed() {
    long long overflow = 0;
    long long ret_val = 0;

    if (ANDROID_INPUT_MUTEX == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    ep_dlcall1(ANDROID_INPUT_LOCK, ANDROID_INPUT_MUTEX);
    overflow = ANDROID_INPUT_OVERFLOW;
    ANDROID_INPUT_OVERFLOW = 0;
    ep_dlcall1(ANDROID_INPUT_UNLOCK, ANDROID_INPUT_MUTEX);
    ret_val = overflow;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long android_pointer_take() {
    long long pressed = 0;
    long long ret_val = 0;

    if (ANDROID_INPUT_MUTEX == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    ep_dlcall1(ANDROID_INPUT_LOCK, ANDROID_INPUT_MUTEX);
    pressed = ANDROID_POINTER_PENDING;
    ANDROID_POINTER_PENDING = 0;
    ep_dlcall1(ANDROID_INPUT_UNLOCK, ANDROID_INPUT_MUTEX);
    ret_val = pressed;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long process_integer(long long pointer, long long count) {
    long long i = 0;
    long long multiplier = 0;
    long long value = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&pointer);

    ep_gc_maybe_collect();

    value = 0;
    multiplier = 1;
    i = 0;
    while (i < count) {
    value = (value + (peek_byte(pointer, i) * multiplier));
    multiplier = (multiplier * 256);
    i = (i + 1);
    }
    ret_val = value;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long process_spawn_streams(long long executable, long long arguments, long long output_fd, long long error_fd, long long detached, long long directory, long long closed_input) {
    long long action_error = 0;
    long long actions = 0;
    long long argument = 0;
    long long argv = 0;
    long long attribute_ready = 0;
    long long attributes = 0;
    long long change_directory = 0;
    long long environment = 0;
    long long environment_pointer = 0;
    long long i = 0;
    long long initialized = 0;
    long long pid = 0;
    long long pid_pointer = 0;
    long long rc = 0;
    long long session_flag = 0;
    long long system = 0;
    long long ret_val = 0;

    ep_gc_push_root(&actions);
    ep_gc_push_root(&argument);
    ep_gc_push_root(&argv);
    ep_gc_push_root(&attributes);
    ep_gc_push_root(&change_directory);
    ep_gc_push_root(&environment);
    ep_gc_push_root(&environment_pointer);
    ep_gc_push_root(&i);
    ep_gc_push_root(&pid_pointer);
    ep_gc_push_root(&session_flag);
    ep_gc_push_root(&system);
    ep_gc_push_root(&executable);
    ep_gc_push_root(&arguments);
    ep_gc_push_root(&output_fd);
    ep_gc_push_root(&error_fd);
    ep_gc_push_root(&directory);

    ep_gc_maybe_collect();

    system = native_system();
    argv = alloc_bytes(((length_list(arguments) + 2) * 8));
    native_bytes_write(argv, 0, str_to_ptr(executable), 8);
    i = 0;
    while (i < length_list(arguments)) {
    argument = get_list(arguments, i);
    native_bytes_write(argv, ((i + 1) * 8), str_to_ptr(argument), 8);
    i = (i + 1);
    }
    environment_pointer = 0;
    if (native_android()) {
    environment_pointer = ep_dlsym(system, (long long)"environ");
    } else {
    environment_pointer = ep_dlcall0(ep_dlsym(system, (long long)"_NSGetEnviron"));
    }
    environment = process_integer(environment_pointer, 8);
    pid_pointer = alloc_bytes(4);
    actions = 0;
    if ((((output_fd >= 0 || error_fd >= 0) || (!ep_str_equals(directory, (long long)""))) || closed_input == 1)) {
    actions = alloc_bytes(8);
    initialized = ep_dlcall1(ep_dlsym(system, (long long)"posix_spawn_file_actions_init"), actions);
    action_error = initialized;
    if ((action_error == 0 && output_fd >= 0)) {
    action_error = ep_dlcall3(ep_dlsym(system, (long long)"posix_spawn_file_actions_adddup2"), actions, output_fd, 1);
    }
    if ((action_error == 0 && error_fd >= 0)) {
    action_error = ep_dlcall3(ep_dlsym(system, (long long)"posix_spawn_file_actions_adddup2"), actions, error_fd, 2);
    }
    if ((action_error == 0 && (!ep_str_equals(directory, (long long)"")))) {
    change_directory = ep_dlsym(system, (long long)"posix_spawn_file_actions_addchdir_np");
    if (change_directory == 0) {
    action_error = 1;
    } else {
    action_error = ep_dlcall2(change_directory, actions, directory);
    }
    }
    if ((action_error == 0 && closed_input == 1)) {
    action_error = ep_dlcall5(ep_dlsym(system, (long long)"posix_spawn_file_actions_addopen"), actions, 0, (long long)"/dev/null", 0, 0);
    }
    if (action_error != 0) {
    if (initialized == 0) {
    ep_dlcall1(ep_dlsym(system, (long long)"posix_spawn_file_actions_destroy"), actions);
    }
    free_bytes(actions);
    free_bytes(pid_pointer);
    free_bytes(argv);
    ret_val = 0;
    goto L_cleanup;
    }
    }
    attributes = 0;
    attribute_ready = 0;
    rc = 0;
    if (detached == 1) {
    attributes = alloc_bytes(8);
    rc = ep_dlcall1(ep_dlsym(system, (long long)"posix_spawnattr_init"), attributes);
    if (rc == 0) {
    attribute_ready = 1;
    session_flag = 1024;
    if (native_android()) {
    session_flag = 128;
    }
    rc = ep_dlcall2(ep_dlsym(system, (long long)"posix_spawnattr_setflags"), attributes, session_flag);
    }
    }
    if (rc == 0) {
    rc = ep_dlcall6(ep_dlsym(system, (long long)"posix_spawn"), pid_pointer, executable, actions, attributes, argv, environment);
    }
    if (attributes != 0) {
    if (attribute_ready == 1) {
    ep_dlcall1(ep_dlsym(system, (long long)"posix_spawnattr_destroy"), attributes);
    }
    free_bytes(attributes);
    }
    if (actions != 0) {
    ep_dlcall1(ep_dlsym(system, (long long)"posix_spawn_file_actions_destroy"), actions);
    free_bytes(actions);
    }
    pid = 0;
    if (rc == 0) {
    pid = process_integer(pid_pointer, 4);
    }
    free_bytes(pid_pointer);
    free_bytes(argv);
    ret_val = pid;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(16);
    return ret_val;
}

long long process_poll(long long pid) {
    long long error_pointer = 0;
    long long raw = 0;
    long long result = 0;
    long long status = 0;
    long long waited = 0;
    long long ret_val = 0;

    ep_gc_push_root(&error_pointer);
    ep_gc_push_root(&status);
    ep_gc_push_root(&pid);

    ep_gc_maybe_collect();

    status = alloc_bytes(4);
    waited = ep_dlcall3(ep_dlsym(native_system(), (long long)"waitpid"), pid, status, 1);
    result = -2;
    if (waited == 0) {
    result = -1;
    } else {
    if (waited == pid) {
    raw = process_integer(status, 4);
    if ((raw % 128) == 0) {
    result = ((raw / 256) % 256);
    } else {
    result = (128 + (raw % 128));
    }
    }
    }
    if (waited >= 2147483648) {
    error_pointer = native_errno_pointer();
    if (process_integer(error_pointer, 4) == 4) {
    result = -1;
    }
    }
    free_bytes(status);
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long process_start(long long executable, long long arguments) {
    long long pid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&executable);
    ep_gc_push_root(&arguments);

    ep_gc_maybe_collect();

    pid = process_spawn_streams(executable, arguments, -1, -1, 0, (long long)"", 0);
    ret_val = pid;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long process_launch(long long executable, long long arguments, long long output_fd) {
    long long pid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&executable);
    ep_gc_push_root(&arguments);
    ep_gc_push_root(&output_fd);

    ep_gc_maybe_collect();

    pid = process_spawn_streams(executable, arguments, output_fd, output_fd, 0, (long long)"", 0);
    ret_val = pid;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long process_detached(long long executable, long long arguments, long long output_fd) {
    long long pid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&executable);
    ep_gc_push_root(&arguments);
    ep_gc_push_root(&output_fd);

    ep_gc_maybe_collect();

    pid = process_spawn_streams(executable, arguments, output_fd, output_fd, 1, (long long)"", 1);
    ret_val = pid;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long process_spawn(long long executable, long long arguments, long long output_fd, long long detached) {
    long long pid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&executable);
    ep_gc_push_root(&arguments);
    ep_gc_push_root(&output_fd);
    ep_gc_push_root(&detached);

    ep_gc_maybe_collect();

    pid = process_spawn_streams(executable, arguments, output_fd, output_fd, detached, (long long)"", detached);
    ret_val = pid;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long native_system() {
    long long ret_val = 0;

    if (NATIVE_SYSTEM == 0) {
    NATIVE_SYSTEM = ep_dlopen((long long)"/usr/lib/libSystem.B.dylib");
    if (NATIVE_SYSTEM == 0) {
    NATIVE_SYSTEM = ep_dlopen((long long)"libc.so");
    if (NATIVE_SYSTEM != 0) {
    NATIVE_ANDROID = 1;
    }
    }
    }
    ret_val = NATIVE_SYSTEM;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long native_bytes_write(long long pointer, long long offset, long long value, long long count) {
    long long byte = 0;
    long long i = 0;
    long long number = 0;
    long long ret_val = 0;

    ep_gc_push_root(&byte);
    ep_gc_push_root(&i);
    ep_gc_push_root(&pointer);
    ep_gc_push_root(&offset);

    ep_gc_maybe_collect();

    number = value;
    i = 0;
    while (i < count) {
    byte = (number % 256);
    if (byte < 0) {
    byte = (byte + 256);
    }
    poke_byte(pointer, (offset + i), byte);
    number = ((number - byte) / 256);
    i = (i + 1);
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long native_variadic_int(long long function, long long fixed_count, long long arguments, long long kinds) {
    long long cif = 0;
    long long code = 0;
    long long count = 0;
    long long i = 0;
    long long int_type = 0;
    long long kind = 0;
    long long pointer_type = 0;
    long long pointers = 0;
    long long prep = 0;
    long long result = 0;
    long long status = 0;
    long long type = 0;
    long long types = 0;
    long long value = 0;
    long long values = 0;
    long long width = 0;
    long long ret_val = 0;

    ep_gc_push_root(&cif);
    ep_gc_push_root(&count);
    ep_gc_push_root(&i);
    ep_gc_push_root(&int_type);
    ep_gc_push_root(&pointers);
    ep_gc_push_root(&prep);
    ep_gc_push_root(&result);
    ep_gc_push_root(&type);
    ep_gc_push_root(&types);
    ep_gc_push_root(&value);
    ep_gc_push_root(&values);
    ep_gc_push_root(&width);
    ep_gc_push_root(&function);
    ep_gc_push_root(&fixed_count);
    ep_gc_push_root(&arguments);
    ep_gc_push_root(&kinds);

    ep_gc_maybe_collect();

    if (NATIVE_VARIADIC_FFI == 0) {
    if (native_android()) {
    NATIVE_VARIADIC_FFI = ep_dlopen((long long)"libecholite_ffi.so");
    } else {
    NATIVE_VARIADIC_FFI = ep_dlopen((long long)"/usr/lib/libffi.dylib");
    }
    }
    if ((NATIVE_VARIADIC_FFI == 0 || function == 0)) {
    ret_val = -1;
    goto L_cleanup;
    }
    count = length_list(arguments);
    if (count != length_list(kinds)) {
    ret_val = -1;
    goto L_cleanup;
    }
    cif = alloc_bytes(256);
    types = alloc_bytes((count * 8));
    values = alloc_bytes((count * 8));
    pointers = alloc_bytes((count * 8));
    result = alloc_bytes(8);
    int_type = ep_dlsym(NATIVE_VARIADIC_FFI, (long long)"ffi_type_sint32");
    pointer_type = ep_dlsym(NATIVE_VARIADIC_FFI, (long long)"ffi_type_pointer");
    i = 0;
    while (i < count) {
    kind = get_list(kinds, i);
    type = int_type;
    value = get_list(arguments, i);
    width = 4;
    if (kind == 1) {
    type = pointer_type;
    width = 8;
    } else {
    if (kind == 2) {
    type = ep_dlsym(NATIVE_VARIADIC_FFI, (long long)"ffi_type_sint64");
    width = 8;
    } else {
    if (value < 0) {
    value = (value + 4294967296);
    }
    }
    }
    native_bytes_write(types, (i * 8), type, 8);
    native_bytes_write(values, (i * 8), value, width);
    native_bytes_write(pointers, (i * 8), (values + (i * 8)), 8);
    i = (i + 1);
    }
    prep = ep_dlsym(NATIVE_VARIADIC_FFI, (long long)"ffi_prep_cif_var");
    status = ep_dlcall6(prep, cif, 1, fixed_count, count, int_type, types);
    code = -1;
    if (status == 0) {
    ep_dlcall4(ep_dlsym(NATIVE_VARIADIC_FFI, (long long)"ffi_call"), cif, function, result, pointers);
    code = (((peek_byte(result, 0) + (peek_byte(result, 1) * 256)) + (peek_byte(result, 2) * 65536)) + (peek_byte(result, 3) * 16777216));
    if (code >= 2147483648) {
    code = (code - 4294967296);
    }
    }
    free_bytes(result);
    free_bytes(pointers);
    free_bytes(values);
    free_bytes(types);
    free_bytes(cif);
    ret_val = code;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(16);
    return ret_val;
}

long long native_open(long long path, long long flags, long long mode) {
    long long converted = 0;
    long long function = 0;
    long long ret_val = 0;

    ep_gc_push_root(&converted);
    ep_gc_push_root(&function);
    ep_gc_push_root(&path);
    ep_gc_push_root(&flags);
    ep_gc_push_root(&mode);

    ep_gc_maybe_collect();

    function = ep_dlsym(native_system(), (long long)"open");
    if (native_android()) {
    converted = native_android_open_flags(flags);
    if (converted < 0) {
    ret_val = -1;
    goto L_cleanup;
    }
    ret_val = native_signed_int(ep_dlcall3(function, path, converted, mode));
    goto L_cleanup;
    }
    ret_val = native_variadic_int(function, 2, ({ long long _lit_list = create_list(); append_list(_lit_list, str_to_ptr(path)); append_list(_lit_list, flags); append_list(_lit_list, mode); _lit_list; }), ({ long long _lit_list = create_list(); append_list(_lit_list, 1); append_list(_lit_list, 0); append_list(_lit_list, 0); _lit_list; }));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long native_openat(long long directory, long long path, long long flags, long long mode) {
    long long converted = 0;
    long long function = 0;
    long long ret_val = 0;

    ep_gc_push_root(&converted);
    ep_gc_push_root(&function);
    ep_gc_push_root(&directory);
    ep_gc_push_root(&path);
    ep_gc_push_root(&flags);
    ep_gc_push_root(&mode);

    ep_gc_maybe_collect();

    function = ep_dlsym(native_system(), (long long)"openat");
    if (native_android()) {
    converted = native_android_open_flags(flags);
    if (converted < 0) {
    ret_val = -1;
    goto L_cleanup;
    }
    ret_val = native_signed_int(ep_dlcall4(function, directory, path, converted, mode));
    goto L_cleanup;
    }
    ret_val = native_variadic_int(function, 3, ({ long long _lit_list = create_list(); append_list(_lit_list, directory); append_list(_lit_list, str_to_ptr(path)); append_list(_lit_list, flags); append_list(_lit_list, mode); _lit_list; }), ({ long long _lit_list = create_list(); append_list(_lit_list, 0); append_list(_lit_list, 1); append_list(_lit_list, 0); append_list(_lit_list, 0); _lit_list; }));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long native_fcntl_int(long long descriptor, long long command, long long argument) {
    long long function = 0;
    long long value = 0;
    long long ret_val = 0;

    ep_gc_push_root(&function);
    ep_gc_push_root(&value);
    ep_gc_push_root(&descriptor);
    ep_gc_push_root(&command);
    ep_gc_push_root(&argument);

    ep_gc_maybe_collect();

    function = ep_dlsym(native_system(), (long long)"fcntl");
    if (native_android()) {
    value = argument;
    if (command == 4) {
    value = native_android_open_flags(argument);
    if (value < 0) {
    ret_val = -1;
    goto L_cleanup;
    }
    }
    ret_val = native_signed_int(ep_dlcall3(function, descriptor, command, value));
    goto L_cleanup;
    }
    ret_val = native_variadic_int(function, 2, ({ long long _lit_list = create_list(); append_list(_lit_list, descriptor); append_list(_lit_list, command); append_list(_lit_list, argument); _lit_list; }), ({ long long _lit_list = create_list(); append_list(_lit_list, 0); append_list(_lit_list, 0); append_list(_lit_list, 0); _lit_list; }));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long native_android() {
    long long ret_val = 0;

    native_system();
    ret_val = NATIVE_ANDROID;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long native_errno_pointer() {
    long long name = 0;
    long long ret_val = 0;

    ep_gc_push_root(&name);

    ep_gc_maybe_collect();

    name = (long long)"__error";
    if (native_android()) {
    name = (long long)"__errno";
    }
    ret_val = ep_dlcall0(ep_dlsym(native_system(), name));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long native_signed_int(long long value) {
    long long ret_val = 0;

    if ((value >= 2147483648 && value <= 4294967295)) {
    ret_val = (value - 4294967296);
    goto L_cleanup;
    }
    ret_val = value;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long native_android_open_flags(long long flags) {
    long long bit = 0;
    long long i = 0;
    long long remainder = 0;
    long long result = 0;
    long long source_bits = 0;
    long long target_bits = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&source_bits);
    ep_gc_push_root(&target_bits);

    ep_gc_maybe_collect();

    source_bits = ({ long long _lit_list = create_list(); append_list(_lit_list, 1); append_list(_lit_list, 2); append_list(_lit_list, 4); append_list(_lit_list, 8); append_list(_lit_list, 256); append_list(_lit_list, 512); append_list(_lit_list, 1024); append_list(_lit_list, 2048); append_list(_lit_list, 1048576); append_list(_lit_list, 16777216); _lit_list; });
    target_bits = ({ long long _lit_list = create_list(); append_list(_lit_list, 1); append_list(_lit_list, 2); append_list(_lit_list, 2048); append_list(_lit_list, 1024); append_list(_lit_list, 32768); append_list(_lit_list, 64); append_list(_lit_list, 512); append_list(_lit_list, 128); append_list(_lit_list, 16384); append_list(_lit_list, 524288); _lit_list; });
    remainder = flags;
    result = 0;
    i = 0;
    while (i < length_list(source_bits)) {
    bit = get_list(source_bits, i);
    if (((flags / bit) % 2) == 1) {
    remainder = (remainder - bit);
    result = (result + get_list(target_bits, i));
    }
    i = (i + 1);
    }
    if (remainder != 0) {
    ret_val = -1;
    goto L_cleanup;
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    free_list(source_bits);
    source_bits = 0;
    free_list(target_bits);
    target_bits = 0;
    return ret_val;
}

long long native_at_nofollow() {
    long long ret_val = 0;

    if (native_android()) {
    ret_val = 256;
    goto L_cleanup;
    }
    ret_val = 32;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long native_dirent_name(long long entry) {
    long long ret_val = 0;

    ep_gc_push_root(&entry);

    ep_gc_maybe_collect();

    if (native_android()) {
    ret_val = ptr_to_str((entry + 19));
    goto L_cleanup;
    }
    ret_val = ptr_to_str((entry + 21));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long native_rename_exclusive(long long source_dir, long long source_name, long long target_dir, long long target_name) {
    long long flag = 0;
    long long function = 0;
    long long name = 0;
    long long ret_val = 0;

    ep_gc_push_root(&flag);
    ep_gc_push_root(&function);
    ep_gc_push_root(&name);
    ep_gc_push_root(&source_dir);
    ep_gc_push_root(&source_name);
    ep_gc_push_root(&target_dir);
    ep_gc_push_root(&target_name);

    ep_gc_maybe_collect();

    name = (long long)"renameatx_np";
    flag = 4;
    if (native_android()) {
    name = (long long)"renameat2";
    flag = 1;
    }
    function = ep_dlsym(native_system(), name);
    if (function == 0) {
    ret_val = -1;
    goto L_cleanup;
    }
    ret_val = native_signed_int(ep_dlcall5(function, source_dir, source_name, target_dir, target_name, flag));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long is_digit(long long ch) {
    long long ret_val = 0;

    if (ch > 47) {
    if (ch < 58) {
    ret_val = 1;
    goto L_cleanup;
    }
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long is_alpha(long long ch) {
    long long ret_val = 0;

    if (ch > 64) {
    if (ch < 91) {
    ret_val = 1;
    goto L_cleanup;
    }
    }
    if (ch > 96) {
    if (ch < 123) {
    ret_val = 1;
    goto L_cleanup;
    }
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long is_alphanumeric(long long ch) {
    long long ret_val = 0;

    ep_gc_push_root(&ch);

    ep_gc_maybe_collect();

    if (is_alpha(ch) == 1) {
    ret_val = 1;
    goto L_cleanup;
    }
    ret_val = is_digit(ch);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long is_space(long long ch) {
    long long ret_val = 0;

    if (ch == 32) {
    ret_val = 1;
    goto L_cleanup;
    }
    if (ch == 9) {
    ret_val = 1;
    goto L_cleanup;
    }
    if (ch == 10) {
    ret_val = 1;
    goto L_cleanup;
    }
    if (ch == 13) {
    ret_val = 1;
    goto L_cleanup;
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long to_upper_char(long long ch) {
    long long ret_val = 0;

    if (ch > 96) {
    if (ch < 123) {
    ret_val = (ch - 32);
    goto L_cleanup;
    }
    }
    ret_val = ch;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long to_lower_char(long long ch) {
    long long ret_val = 0;

    if (ch > 64) {
    if (ch < 91) {
    ret_val = (ch + 32);
    goto L_cleanup;
    }
    }
    ret_val = ch;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long string_equals(long long s1, long long s2) {
    long long c1 = 0;
    long long c2 = 0;
    long long i = 0;
    long long len1 = 0;
    long long len2 = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&s1);
    ep_gc_push_root(&s2);

    ep_gc_maybe_collect();

    len1 = string_length((char*)s1);
    len2 = string_length((char*)s2);
    if (len1 != len2) {
    ret_val = 0;
    goto L_cleanup;
    }
    i = 0;
    while (i < len1) {
    c1 = get_character((char*)s1, i);
    c2 = get_character((char*)s2, i);
    if (c1 != c2) {
    ret_val = 0;
    goto L_cleanup;
    }
    i = (i + 1);
    }
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long starts_with(long long s, long long prefix) {
    long long plen = 0;
    long long slen = 0;
    long long sub = 0;
    long long ret_val = 0;

    ep_gc_push_root(&plen);
    ep_gc_push_root(&sub);
    ep_gc_push_root(&s);
    ep_gc_push_root(&prefix);

    ep_gc_maybe_collect();

    plen = string_length((char*)prefix);
    slen = string_length((char*)s);
    if (plen > slen) {
    ret_val = 0;
    goto L_cleanup;
    }
    sub = (long long)substring((char*)s, 0, plen);
    ret_val = string_equals(sub, prefix);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long ends_with(long long s, long long suffix) {
    long long slen = 0;
    long long start = 0;
    long long sub = 0;
    long long suflen = 0;
    long long ret_val = 0;

    ep_gc_push_root(&start);
    ep_gc_push_root(&sub);
    ep_gc_push_root(&suflen);
    ep_gc_push_root(&s);
    ep_gc_push_root(&suffix);

    ep_gc_maybe_collect();

    slen = string_length((char*)s);
    suflen = string_length((char*)suffix);
    if (suflen > slen) {
    ret_val = 0;
    goto L_cleanup;
    }
    start = (slen - suflen);
    sub = (long long)substring((char*)s, start, suflen);
    ret_val = string_equals(sub, suffix);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long string_last_index_of(long long s, long long substr) {
    long long hlen = 0;
    long long i = 0;
    long long nlen = 0;
    long long sub = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&nlen);
    ep_gc_push_root(&sub);
    ep_gc_push_root(&s);
    ep_gc_push_root(&substr);

    ep_gc_maybe_collect();

    hlen = string_length((char*)s);
    nlen = string_length((char*)substr);
    if (nlen > hlen) {
    ret_val = -1;
    goto L_cleanup;
    }
    i = (hlen - nlen);
    while (i > -1) {
    sub = (long long)substring((char*)s, i, nlen);
    if (string_equals(sub, substr) == 1) {
    ret_val = i;
    goto L_cleanup;
    }
    i = (i - 1);
    }
    ret_val = -1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long string_count(long long s, long long substr) {
    long long count = 0;
    long long hlen = 0;
    long long i = 0;
    long long limit = 0;
    long long nlen = 0;
    long long sub = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&nlen);
    ep_gc_push_root(&sub);
    ep_gc_push_root(&s);
    ep_gc_push_root(&substr);

    ep_gc_maybe_collect();

    count = 0;
    hlen = string_length((char*)s);
    nlen = string_length((char*)substr);
    if (nlen > hlen) {
    ret_val = 0;
    goto L_cleanup;
    }
    i = 0;
    limit = ((hlen - nlen) + 1);
    while (i < limit) {
    sub = (long long)substring((char*)s, i, nlen);
    if (string_equals(sub, substr) == 1) {
    count = (count + 1);
    i = (i + nlen);
    } else {
    i = (i + 1);
    }
    }
    ret_val = count;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long repeat_string(long long s, long long count) {
    long long i = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&result);
    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    result = (long long)"";
    i = 0;
    while (i < count) {
    result = concat(result, s);
    i = (i + 1);
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long string_to_upper(long long s) {
    long long ch = 0;
    long long i = 0;
    long long len = 0;
    long long lst = 0;
    long long ok = 0;
    long long ret_val = 0;

    ep_gc_push_root(&ch);
    ep_gc_push_root(&i);
    ep_gc_push_root(&lst);
    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    len = string_length((char*)s);
    lst = create_list();
    i = 0;
    while (i < len) {
    ch = get_character((char*)s, i);
    ok = append_list(lst, to_upper_char(ch));
    i = (i + 1);
    }
    ret_val = (long long)string_from_list(lst);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    free_list(lst);
    lst = 0;
    return ret_val;
}

long long string_to_lower(long long s) {
    long long ch = 0;
    long long i = 0;
    long long len = 0;
    long long lst = 0;
    long long ok = 0;
    long long ret_val = 0;

    ep_gc_push_root(&ch);
    ep_gc_push_root(&i);
    ep_gc_push_root(&lst);
    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    len = string_length((char*)s);
    lst = create_list();
    i = 0;
    while (i < len) {
    ch = get_character((char*)s, i);
    ok = append_list(lst, to_lower_char(ch));
    i = (i + 1);
    }
    ret_val = (long long)string_from_list(lst);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    free_list(lst);
    lst = 0;
    return ret_val;
}

long long trim_left(long long s) {
    long long ch = 0;
    long long len = 0;
    long long rest = 0;
    long long start = 0;
    long long ret_val = 0;

    ep_gc_push_root(&ch);
    ep_gc_push_root(&len);
    ep_gc_push_root(&rest);
    ep_gc_push_root(&start);
    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    len = string_length((char*)s);
    start = 0;
    while (start < len) {
    ch = get_character((char*)s, start);
    if (is_space(ch) == 0) {
    rest = (long long)substring((char*)s, start, (len - start));
    ret_val = rest;
    goto L_cleanup;
    }
    start = (start + 1);
    }
    ret_val = (long long)"";
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long trim_right(long long s) {
    long long ch = 0;
    long long end_idx = 0;
    long long len = 0;
    long long ret_val = 0;

    ep_gc_push_root(&ch);
    ep_gc_push_root(&end_idx);
    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    len = string_length((char*)s);
    end_idx = (len - 1);
    while (end_idx > -1) {
    ch = get_character((char*)s, end_idx);
    if (is_space(ch) == 0) {
    ret_val = (long long)substring((char*)s, 0, (end_idx + 1));
    goto L_cleanup;
    }
    end_idx = (end_idx - 1);
    }
    ret_val = (long long)"";
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long reverse_string(long long s) {
    long long i = 0;
    long long len = 0;
    long long lst = 0;
    long long ok = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&lst);
    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    len = string_length((char*)s);
    lst = create_list();
    i = (len - 1);
    while (i > -1) {
    ok = append_list(lst, get_character((char*)s, i));
    i = (i - 1);
    }
    ret_val = (long long)string_from_list(lst);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    free_list(lst);
    lst = 0;
    return ret_val;
}

long long string_pad_left(long long s, long long width, long long pad_char) {
    long long ch_str = 0;
    long long i = 0;
    long long needed = 0;
    long long pad_str = 0;
    long long slen = 0;
    long long ret_val = 0;

    ep_gc_push_root(&ch_str);
    ep_gc_push_root(&pad_str);
    ep_gc_push_root(&s);
    ep_gc_push_root(&pad_char);

    ep_gc_maybe_collect();

    slen = string_length((char*)s);
    if (slen > (width - 1)) {
    ret_val = s;
    goto L_cleanup;
    }
    pad_str = (long long)"";
    i = 0;
    needed = (width - slen);
    while (i < needed) {
    ch_str = (long long)substring((char*)pad_char, 0, 1);
    pad_str = concat(pad_str, ch_str);
    i = (i + 1);
    }
    ret_val = concat(pad_str, s);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long string_pad_right(long long s, long long width, long long pad_char) {
    long long ch_str = 0;
    long long i = 0;
    long long needed = 0;
    long long result = 0;
    long long slen = 0;
    long long ret_val = 0;

    ep_gc_push_root(&ch_str);
    ep_gc_push_root(&result);
    ep_gc_push_root(&s);
    ep_gc_push_root(&pad_char);

    ep_gc_maybe_collect();

    slen = string_length((char*)s);
    if (slen > (width - 1)) {
    ret_val = s;
    goto L_cleanup;
    }
    result = s;
    i = 0;
    needed = (width - slen);
    while (i < needed) {
    ch_str = (long long)substring((char*)pad_char, 0, 1);
    result = concat(result, ch_str);
    i = (i + 1);
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long split(long long s, long long delimiter) {
    long long current = 0;
    long long dlen = 0;
    long long i = 0;
    long long ok = 0;
    long long result = 0;
    long long slen = 0;
    long long sub = 0;
    long long word = 0;
    long long ret_val = 0;

    ep_gc_push_root(&current);
    ep_gc_push_root(&dlen);
    ep_gc_push_root(&i);
    ep_gc_push_root(&result);
    ep_gc_push_root(&sub);
    ep_gc_push_root(&word);
    ep_gc_push_root(&s);
    ep_gc_push_root(&delimiter);

    ep_gc_maybe_collect();

    result = create_list();
    current = create_list();
    slen = string_length((char*)s);
    dlen = string_length((char*)delimiter);
    i = 0;
    while (i < slen) {
    if ((i + dlen) < (slen + 1)) {
    sub = (long long)substring((char*)s, i, dlen);
    if (string_equals(sub, delimiter) == 1) {
    word = (long long)string_from_list(current);
    ok = append_list(result, word);
    current = create_list();
    i = (i + dlen);
    } else {
    ok = append_list(current, get_character((char*)s, i));
    i = (i + 1);
    }
    } else {
    ok = append_list(current, get_character((char*)s, i));
    i = (i + 1);
    }
    }
    word = (long long)string_from_list(current);
    ok = append_list(result, word);
    ret_val = result;
    result = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long join(long long parts, long long separator) {
    long long i = 0;
    long long item = 0;
    long long plen = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&item);
    ep_gc_push_root(&result);
    ep_gc_push_root(&parts);
    ep_gc_push_root(&separator);

    ep_gc_maybe_collect();

    plen = length_list(parts);
    if (plen == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    result = get_list(parts, 0);
    i = 1;
    while (i < plen) {
    result = concat(result, separator);
    item = get_list(parts, i);
    result = concat(result, item);
    i = (i + 1);
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long create_builder() {
    long long ret_val = 0;

    ret_val = ep_sb_create(0);
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long builder_append(long long builder, long long s) {
    long long ret_val = 0;

    ep_gc_push_root(&builder);
    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    ret_val = ep_sb_append(builder, s);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long builder_append_int(long long builder, long long n) {
    long long ret_val = 0;

    ep_gc_push_root(&builder);
    ep_gc_push_root(&n);

    ep_gc_maybe_collect();

    ret_val = ep_sb_append_int(builder, n);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long builder_to_string(long long builder) {
    long long ret_val = 0;

    ep_gc_push_root(&builder);

    ep_gc_maybe_collect();

    ret_val = ep_sb_to_string(builder);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long builder_length(long long builder) {
    long long ret_val = 0;

    ep_gc_push_root(&builder);

    ep_gc_maybe_collect();

    ret_val = ep_sb_length(builder);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long builder_clear(long long builder) {
    long long ret_val = 0;

    ret_val = ep_sb_create(0);
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long string_format(long long template, long long args) {
    long long arg_val = 0;
    long long ch = 0;
    long long ch2 = 0;
    long long ch2_str = 0;
    long long ch_str = 0;
    long long i = 0;
    long long idx = 0;
    long long idx_str = 0;
    long long j = 0;
    long long result = 0;
    long long tlen = 0;
    long long ret_val = 0;

    ep_gc_push_root(&arg_val);
    ep_gc_push_root(&ch2_str);
    ep_gc_push_root(&ch_str);
    ep_gc_push_root(&i);
    ep_gc_push_root(&idx);
    ep_gc_push_root(&idx_str);
    ep_gc_push_root(&j);
    ep_gc_push_root(&result);
    ep_gc_push_root(&template);
    ep_gc_push_root(&args);

    ep_gc_maybe_collect();

    result = (long long)"";
    tlen = string_length((char*)template);
    i = 0;
    while (i < tlen) {
    ch = get_character((char*)template, i);
    if (ch == 123) {
    j = (i + 1);
    idx_str = (long long)"";
    while (j < tlen) {
    ch2 = get_character((char*)template, j);
    if (ch2 == 125) {
    idx = string_to_int(idx_str);
    if (idx < length_list(args)) {
    arg_val = get_list(args, idx);
    result = concat(result, arg_val);
    }
    i = (j + 1);
    j = tlen;
    } else {
    ch2_str = (long long)substring((char*)template, j, 1);
    idx_str = concat(idx_str, ch2_str);
    j = (j + 1);
    }
    }
    } else {
    ch_str = (long long)substring((char*)template, i, 1);
    result = concat(result, ch_str);
    i = (i + 1);
    }
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(10);
    return ret_val;
}

long long android_jni_function(long long slot) {
    long long ret_val = 0;

    ep_gc_push_root(&slot);

    ep_gc_maybe_collect();

    ret_val = process_integer((ANDROID_JNI_TABLE + (slot * 8)), 8);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long android_jni_clear() {
    long long ret_val = 0;

    if (ep_dlcall1(android_jni_function(228), ANDROID_JNI_ENV)) {
    ep_dlcall1(android_jni_function(17), ANDROID_JNI_ENV);
    ret_val = 1;
    goto L_cleanup;
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long android_jni_release(long long object) {
    long long ret_val = 0;

    ep_gc_push_root(&object);

    ep_gc_maybe_collect();

    if (object != 0) {
    ep_dlcall2(android_jni_function(23), ANDROID_JNI_ENV, object);
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long android_jni_object(long long object, long long name, long long signature, long long arguments) {
    long long kind = 0;
    long long method = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&kind);
    ep_gc_push_root(&method);
    ep_gc_push_root(&result);
    ep_gc_push_root(&object);
    ep_gc_push_root(&name);
    ep_gc_push_root(&signature);
    ep_gc_push_root(&arguments);

    ep_gc_maybe_collect();

    if (object == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    kind = ep_dlcall2(android_jni_function(31), ANDROID_JNI_ENV, object);
    if (kind == 0) {
    android_jni_clear();
    ret_val = 0;
    goto L_cleanup;
    }
    method = ep_dlcall4(android_jni_function(33), ANDROID_JNI_ENV, kind, name, signature);
    android_jni_release(kind);
    if (method == 0) {
    android_jni_clear();
    ret_val = 0;
    goto L_cleanup;
    }
    result = ep_dlcall4(android_jni_function(36), ANDROID_JNI_ENV, object, method, arguments);
    if (android_jni_clear()) {
    android_jni_release(result);
    ret_val = 0;
    goto L_cleanup;
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long android_keyboard_inset(long long sdl) {
    long long activity = 0;
    long long argument = 0;
    long long bottom = 0;
    long long field = 0;
    long long ime = 0;
    long long insets = 0;
    long long kind = 0;
    long long view = 0;
    long long window = 0;
    long long ret_val = 0;

    ep_gc_push_root(&activity);
    ep_gc_push_root(&argument);
    ep_gc_push_root(&field);
    ep_gc_push_root(&ime);
    ep_gc_push_root(&insets);
    ep_gc_push_root(&kind);
    ep_gc_push_root(&view);
    ep_gc_push_root(&window);
    ep_gc_push_root(&sdl);

    ep_gc_maybe_collect();

    ANDROID_JNI_ENV = ep_dlcall0(ep_dlsym(sdl, (long long)"SDL_GetAndroidJNIEnv"));
    if (ANDROID_JNI_ENV == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    ANDROID_JNI_TABLE = process_integer(ANDROID_JNI_ENV, 8);
    activity = ep_dlcall0(ep_dlsym(sdl, (long long)"SDL_GetAndroidActivity"));
    window = android_jni_object(activity, (long long)"getWindow", (long long)"()Landroid/view/Window;", 0);
    view = android_jni_object(window, (long long)"getDecorView", (long long)"()Landroid/view/View;", 0);
    insets = android_jni_object(view, (long long)"getRootWindowInsets", (long long)"()Landroid/view/WindowInsets;", 0);
    argument = alloc_bytes(8);
    native_bytes_write(argument, 0, 8, 4);
    ime = android_jni_object(insets, (long long)"getInsets", (long long)"(I)Landroid/graphics/Insets;", argument);
    free_bytes(argument);
    bottom = 0;
    if (ime != 0) {
    kind = ep_dlcall2(android_jni_function(31), ANDROID_JNI_ENV, ime);
    field = ep_dlcall4(android_jni_function(94), ANDROID_JNI_ENV, kind, (long long)"bottom", (long long)"I");
    if (field != 0) {
    bottom = native_signed_int(ep_dlcall3(android_jni_function(100), ANDROID_JNI_ENV, ime, field));
    }
    if (android_jni_clear()) {
    bottom = 0;
    }
    android_jni_release(kind);
    }
    android_jni_release(ime);
    android_jni_release(insets);
    android_jni_release(view);
    android_jni_release(window);
    android_jni_release(activity);
    ret_val = bottom;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    return ret_val;
}

long long native_write(long long ptr, long long offset, long long value, long long count) {
    long long ret_val = 0;

    ep_gc_push_root(&ptr);
    ep_gc_push_root(&offset);
    ep_gc_push_root(&value);
    ep_gc_push_root(&count);

    ep_gc_maybe_collect();

    ret_val = native_bytes_write(ptr, offset, value, count);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long native_f32(long long value) {
    long long exponent = 0;
    long long power = 0;
    long long ret_val = 0;

    ep_gc_push_root(&value);

    ep_gc_maybe_collect();

    if (value < 0) {
    ret_val = (2147483648 + native_f32((0 - value)));
    goto L_cleanup;
    }
    if (value == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    exponent = 0;
    power = 1;
    while ((power + power) <= value) {
    power = (power + power);
    exponent = (exponent + 1);
    }
    ret_val = (((exponent + 127) * 8388608) + (((value - power) * 8388608) / power));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long native_struct(long long members) {
    long long descriptor = 0;
    long long elements = 0;
    long long i = 0;
    long long ret_val = 0;

    ep_gc_push_root(&descriptor);
    ep_gc_push_root(&elements);
    ep_gc_push_root(&i);
    ep_gc_push_root(&members);

    ep_gc_maybe_collect();

    append_list(members, 0);
    elements = alloc_bytes((length_list(members) * 8));
    i = 0;
    while (i < length_list(members)) {
    native_bytes_write(elements, (i * 8), get_list(members, i), 8);
    i = (i + 1);
    }
    descriptor = alloc_bytes(24);
    native_bytes_write(descriptor, 10, 13, 2);
    native_bytes_write(descriptor, 16, elements, 8);
    ret_val = descriptor;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long native_cif(long long result_type, long long types) {
    long long code = 0;
    long long descriptor = 0;
    long long index = 0;
    long long prep = 0;
    long long type_storage = 0;
    long long ret_val = 0;

    ep_gc_push_root(&descriptor);
    ep_gc_push_root(&index);
    ep_gc_push_root(&prep);
    ep_gc_push_root(&type_storage);
    ep_gc_push_root(&result_type);
    ep_gc_push_root(&types);

    ep_gc_maybe_collect();

    descriptor = alloc_bytes(256);
    prep = ep_dlsym(FONT_FFI, (long long)"ffi_prep_cif");
    type_storage = alloc_bytes((length_list(types) * 8));
    index = 0;
    while (index < length_list(types)) {
    native_bytes_write(type_storage, (index * 8), get_list(types, index), 8);
    index = (index + 1);
    }
    code = ep_dlcall5(prep, descriptor, 1, length_list(types), result_type, type_storage);
    if (code != 0) {
    printf("%s\n", (char*)(long long)"Native font signature rejected");
    ep_exit(1);
    }
    ret_val = descriptor;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long font_init(long long raylib) {
    long long byte_type = 0;
    long long codepoints = 0;
    long long codepoints_cell = 0;
    long long color_type = 0;
    long long count_cell = 0;
    long long extra = 0;
    long long filter_args = 0;
    long long filter_cell = 0;
    long long filter_cif = 0;
    long long float_type = 0;
    long long font_type = 0;
    long long glyph = 0;
    long long int_type = 0;
    long long load_args = 0;
    long long load_cif = 0;
    long long path = 0;
    long long path_cell = 0;
    long long pointer_type = 0;
    long long size_cell = 0;
    long long texture_type = 0;
    long long vector_type = 0;
    long long ret_val = 0;

    ep_gc_push_root(&byte_type);
    ep_gc_push_root(&codepoints);
    ep_gc_push_root(&codepoints_cell);
    ep_gc_push_root(&color_type);
    ep_gc_push_root(&count_cell);
    ep_gc_push_root(&extra);
    ep_gc_push_root(&filter_args);
    ep_gc_push_root(&filter_cell);
    ep_gc_push_root(&filter_cif);
    ep_gc_push_root(&float_type);
    ep_gc_push_root(&font_type);
    ep_gc_push_root(&glyph);
    ep_gc_push_root(&int_type);
    ep_gc_push_root(&load_args);
    ep_gc_push_root(&load_cif);
    ep_gc_push_root(&path);
    ep_gc_push_root(&path_cell);
    ep_gc_push_root(&pointer_type);
    ep_gc_push_root(&size_cell);
    ep_gc_push_root(&texture_type);
    ep_gc_push_root(&vector_type);
    ep_gc_push_root(&raylib);

    ep_gc_maybe_collect();

    FONT_FFI = ep_dlopen((long long)"/usr/lib/libffi.dylib");
    if (native_android()) {
    FONT_FFI = ep_dlopen((long long)"libecholite_ffi.so");
    }
    if (FONT_FFI == 0) {
    printf("%s\n", (char*)(long long)"Native font library unavailable");
    ep_exit(1);
    }
    FONT_CALL = ep_dlsym(FONT_FFI, (long long)"ffi_call");
    int_type = ep_dlsym(FONT_FFI, (long long)"ffi_type_sint32");
    pointer_type = ep_dlsym(FONT_FFI, (long long)"ffi_type_pointer");
    float_type = ep_dlsym(FONT_FFI, (long long)"ffi_type_float");
    byte_type = ep_dlsym(FONT_FFI, (long long)"ffi_type_uint8");
    texture_type = native_struct(({ long long _lit_list = create_list(); append_list(_lit_list, int_type); append_list(_lit_list, int_type); append_list(_lit_list, int_type); append_list(_lit_list, int_type); append_list(_lit_list, int_type); _lit_list; }));
    font_type = native_struct(({ long long _lit_list = create_list(); append_list(_lit_list, int_type); append_list(_lit_list, int_type); append_list(_lit_list, int_type); append_list(_lit_list, texture_type); append_list(_lit_list, pointer_type); append_list(_lit_list, pointer_type); _lit_list; }));
    vector_type = native_struct(({ long long _lit_list = create_list(); append_list(_lit_list, float_type); append_list(_lit_list, float_type); _lit_list; }));
    color_type = native_struct(({ long long _lit_list = create_list(); append_list(_lit_list, byte_type); append_list(_lit_list, byte_type); append_list(_lit_list, byte_type); append_list(_lit_list, byte_type); _lit_list; }));
    load_cif = native_cif(font_type, ({ long long _lit_list = create_list(); append_list(_lit_list, pointer_type); append_list(_lit_list, int_type); append_list(_lit_list, pointer_type); append_list(_lit_list, int_type); _lit_list; }));
    FONT_VALUE = alloc_bytes(64);
    path = (long long)"/System/Library/Fonts/SFNSMono.ttf";
    if (native_android()) {
    path = (long long)"/system/fonts/Roboto-Regular.ttf";
    }
    path_cell = ({ long long _lit_list = create_list(); append_list(_lit_list, str_to_ptr(path)); _lit_list; });
    size_cell = ({ long long _lit_list = create_list(); append_list(_lit_list, 64); _lit_list; });
    codepoints = alloc_bytes(5016);
    glyph = 0;
    while (glyph < 1248) {
    native_bytes_write(codepoints, ((glyph + glyph) + (glyph + glyph)), (glyph + 32), 4);
    glyph = (glyph + 1);
    }
    extra = ({ long long _lit_list = create_list(); append_list(_lit_list, 8211); append_list(_lit_list, 8212); append_list(_lit_list, 8216); append_list(_lit_list, 8217); append_list(_lit_list, 8220); append_list(_lit_list, 8221); _lit_list; });
    native_bytes_write(codepoints, 4992, get_list(extra, 0), 4);
    native_bytes_write(codepoints, 4996, get_list(extra, 1), 4);
    native_bytes_write(codepoints, 5000, get_list(extra, 2), 4);
    native_bytes_write(codepoints, 5004, get_list(extra, 3), 4);
    native_bytes_write(codepoints, 5008, get_list(extra, 4), 4);
    native_bytes_write(codepoints, 5012, get_list(extra, 5), 4);
    glyph = 6;
    codepoints_cell = ({ long long _lit_list = create_list(); append_list(_lit_list, codepoints); _lit_list; });
    count_cell = ({ long long _lit_list = create_list(); append_list(_lit_list, 1254); _lit_list; });
    load_args = ({ long long _lit_list = create_list(); append_list(_lit_list, get_list_data_ptr(path_cell)); append_list(_lit_list, get_list_data_ptr(size_cell)); append_list(_lit_list, get_list_data_ptr(codepoints_cell)); append_list(_lit_list, get_list_data_ptr(count_cell)); _lit_list; });
    ep_dlcall4(FONT_CALL, load_cif, ep_dlsym(raylib, (long long)"LoadFontEx"), FONT_VALUE, get_list_data_ptr(load_args));
    free_bytes(codepoints);
    filter_cif = native_cif(ep_dlsym(FONT_FFI, (long long)"ffi_type_void"), ({ long long _lit_list = create_list(); append_list(_lit_list, texture_type); append_list(_lit_list, int_type); _lit_list; }));
    filter_cell = ({ long long _lit_list = create_list(); append_list(_lit_list, 1); _lit_list; });
    filter_args = ({ long long _lit_list = create_list(); append_list(_lit_list, (FONT_VALUE + 12)); append_list(_lit_list, get_list_data_ptr(filter_cell)); _lit_list; });
    ep_dlcall4(FONT_CALL, filter_cif, ep_dlsym(raylib, (long long)"SetTextureFilter"), 0, get_list_data_ptr(filter_args));
    FONT_TEXT = alloc_bytes(8);
    FONT_POSITION = alloc_bytes(8);
    FONT_SIZE = alloc_bytes(4);
    FONT_SPACE = alloc_bytes(4);
    FONT_COLOR = alloc_bytes(4);
    FONT_RESULT = alloc_bytes(8);
    native_bytes_write(FONT_SPACE, 0, native_f32(0), 4);
    FONT_DRAW_CIF = native_cif(ep_dlsym(FONT_FFI, (long long)"ffi_type_void"), ({ long long _lit_list = create_list(); append_list(_lit_list, font_type); append_list(_lit_list, pointer_type); append_list(_lit_list, vector_type); append_list(_lit_list, float_type); append_list(_lit_list, float_type); append_list(_lit_list, color_type); _lit_list; }));
    FONT_MEASURE_CIF = native_cif(vector_type, ({ long long _lit_list = create_list(); append_list(_lit_list, font_type); append_list(_lit_list, pointer_type); append_list(_lit_list, float_type); append_list(_lit_list, float_type); _lit_list; }));
    FONT_DRAW_ARGS = ({ long long _lit_list = create_list(); append_list(_lit_list, FONT_VALUE); append_list(_lit_list, FONT_TEXT); append_list(_lit_list, FONT_POSITION); append_list(_lit_list, FONT_SIZE); append_list(_lit_list, FONT_SPACE); append_list(_lit_list, FONT_COLOR); _lit_list; });
    FONT_MEASURE_ARGS = ({ long long _lit_list = create_list(); append_list(_lit_list, FONT_VALUE); append_list(_lit_list, FONT_TEXT); append_list(_lit_list, FONT_SIZE); append_list(_lit_list, FONT_SPACE); _lit_list; });
    FONT_DRAW = ep_dlsym(raylib, (long long)"DrawTextEx");
    FONT_MEASURE = ep_dlsym(raylib, (long long)"MeasureTextEx");
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(22);
    free_list(codepoints_cell);
    codepoints_cell = 0;
    free_list(count_cell);
    count_cell = 0;
    free_list(extra);
    extra = 0;
    free_list(filter_args);
    filter_args = 0;
    free_list(filter_cell);
    filter_cell = 0;
    free_list(load_args);
    load_args = 0;
    free_list(path_cell);
    path_cell = 0;
    free_list(size_cell);
    size_cell = 0;
    return ret_val;
}

long long font_draw(long long text, long long x, long long y, long long size, long long tint) {
    long long ret_val = 0;

    ep_gc_push_root(&text);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&size);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    native_bytes_write(FONT_TEXT, 0, str_to_ptr(text), 8);
    native_bytes_write(FONT_POSITION, 0, native_f32(x), 4);
    native_bytes_write(FONT_POSITION, 4, native_f32(y), 4);
    native_bytes_write(FONT_SIZE, 0, native_f32(size), 4);
    native_bytes_write(FONT_COLOR, 0, tint, 4);
    ep_dlcall4(FONT_CALL, FONT_DRAW_CIF, FONT_DRAW, 0, get_list_data_ptr(FONT_DRAW_ARGS));
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long font_measure(long long text, long long size) {
    long long bits = 0;
    long long exponent = 0;
    long long mantissa = 0;
    long long ret_val = 0;

    ep_gc_push_root(&text);
    ep_gc_push_root(&size);

    ep_gc_maybe_collect();

    native_bytes_write(FONT_TEXT, 0, str_to_ptr(text), 8);
    native_bytes_write(FONT_SIZE, 0, native_f32(size), 4);
    ep_dlcall4(FONT_CALL, FONT_MEASURE_CIF, FONT_MEASURE, FONT_RESULT, get_list_data_ptr(FONT_MEASURE_ARGS));
    bits = (((peek_byte(FONT_RESULT, 0) + (peek_byte(FONT_RESULT, 1) * 256)) + (peek_byte(FONT_RESULT, 2) * 65536)) + (peek_byte(FONT_RESULT, 3) * 16777216));
    if (bits == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    exponent = ((bits / 8388608) - 127);
    mantissa = ((bits % 8388608) + 8388608);
    while (exponent < 23) {
    mantissa = (mantissa / 2);
    exponent = (exponent + 1);
    }
    ret_val = mantissa;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long get_env(long long name) {
    long long ret_val = 0;

    ep_gc_push_root(&name);

    ep_gc_maybe_collect();

    ret_val = ep_getenv(name);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long set_env(long long name, long long value) {
    long long ret_val = 0;

    ep_gc_push_root(&name);
    ep_gc_push_root(&value);

    ep_gc_maybe_collect();

    ret_val = ep_setenv(name, value);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long get_args() {
    long long ret_val = 0;

    ret_val = ep_get_args();
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long get_cwd() {
    long long ret_val = 0;

    ret_val = ep_get_cwd();
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long get_home_dir() {
    long long ret_val = 0;

    ret_val = ep_get_home_dir();
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long get_pid() {
    long long ret_val = 0;

    ret_val = ep_get_pid();
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long os_name() {
    long long ret_val = 0;

    ret_val = ep_os_name();
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long arch_name() {
    long long ret_val = 0;

    ret_val = ep_arch_name();
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long exit_program(long long code) {
    long long ret_val = 0;

    ep_gc_push_root(&code);

    ep_gc_maybe_collect();

    ret_val = ep_exit(code);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long transport_error(long long message) {
    long long result = 0;
    long long values = 0;
    long long ret_val = 0;

    ep_gc_push_root(&result);
    ep_gc_push_root(&values);
    ep_gc_push_root(&message);

    ep_gc_maybe_collect();

    values = ({ long long _lit_list = create_list(); append_list(_lit_list, create_json_string((long long)"transport_error")); append_list(_lit_list, create_json_string(concat(message, (long long)"; execution outcome may be unknown. No automatic retry."))); _lit_list; });
    result = json_stringify(create_json_object(({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"status"); append_list(_lit_list, (long long)(long long)"text"); _lit_list; }), values));
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    free_list(values);
    values = 0;
    return ret_val;
}

long long transport_number(long long value, long long base, long long ceiling) {
    long long code = 0;
    long long digit = 0;
    long long i = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&value);

    ep_gc_maybe_collect();

    if (string_length((char*)value) == 0) {
    ret_val = -1;
    goto L_cleanup;
    }
    result = 0;
    i = 0;
    while (i < string_length((char*)value)) {
    code = to_lower_char(get_character((char*)value, i));
    digit = -1;
    if ((code >= 48 && code <= 57)) {
    digit = (code - 48);
    }
    if ((code >= 97 && code <= 102)) {
    digit = (code - 87);
    }
    if ((digit < 0 || digit >= base)) {
    ret_val = -1;
    goto L_cleanup;
    }
    if (result > ((ceiling - digit) / base)) {
    ret_val = -1;
    goto L_cleanup;
    }
    result = ((result * base) + digit);
    if (result > ceiling) {
    ret_val = -1;
    goto L_cleanup;
    }
    i = (i + 1);
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long transport_parser() {
    long long state = 0;
    long long ret_val = 0;

    ep_gc_push_root(&state);

    ep_gc_maybe_collect();

    state = create_list();
    append_list(state, 0);
    append_list(state, (long long)"");
    append_list(state, (long long)"");
    append_list(state, 0);
    append_list(state, (long long)"");
    append_list(state, 0);
    ret_val = state;
    state = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long transport_parse(long long state, long long incoming, long long eof) {
    long long advance = 0;
    long long body = 0;
    long long buffer = 0;
    long long colon = 0;
    long long end = 0;
    long long error = 0;
    long long extension = 0;
    long long i = 0;
    long long length_seen = 0;
    long long line = 0;
    long long lines = 0;
    long long name = 0;
    long long phase = 0;
    long long remaining = 0;
    long long size_text = 0;
    long long status = 0;
    long long transfer_seen = 0;
    long long value = 0;
    long long wire = 0;
    long long ret_val = 0;

    ep_gc_push_root(&body);
    ep_gc_push_root(&buffer);
    ep_gc_push_root(&colon);
    ep_gc_push_root(&end);
    ep_gc_push_root(&error);
    ep_gc_push_root(&extension);
    ep_gc_push_root(&i);
    ep_gc_push_root(&line);
    ep_gc_push_root(&lines);
    ep_gc_push_root(&name);
    ep_gc_push_root(&phase);
    ep_gc_push_root(&remaining);
    ep_gc_push_root(&size_text);
    ep_gc_push_root(&status);
    ep_gc_push_root(&value);
    ep_gc_push_root(&wire);
    ep_gc_push_root(&state);
    ep_gc_push_root(&incoming);

    ep_gc_maybe_collect();

    wire = (get_list(state, 5) + string_length((char*)incoming));
    set_list(state, 5, wire);
    if (wire > 2097152) {
    set_list(state, 4, (long long)"Local response exceeded wire limit");
    ret_val = 0;
    goto L_cleanup;
    }
    buffer = concat(get_list(state, 1), incoming);
    body = get_list(state, 2);
    phase = get_list(state, 0);
    remaining = get_list(state, 3);
    error = get_list(state, 4);
    advance = 1;
    while (((advance == 1 && ep_str_equals(error, (long long)"")) && phase != 6)) {
    advance = 0;
    if (phase == 0) {
    end = string_index_of(buffer, (long long)"\r\n\r\n");
    if (end < 0) {
    if (string_length((char*)buffer) > 16384) {
    error = (long long)"Local response headers exceeded limit";
    }
    } else {
    if (end > 16384) {
    error = (long long)"Local response headers exceeded limit";
    } else {
    lines = string_split((long long)substring((char*)buffer, 0, end), (long long)"\r\n");
    status = get_list(lines, 0);
    if ((starts_with(status, (long long)"HTTP/1.1 200 ") == 0 && starts_with(status, (long long)"HTTP/1.0 200 ") == 0)) {
    error = (long long)"Local runtime returned a non-success HTTP status";
    }
    length_seen = 0;
    transfer_seen = 0;
    phase = 2;
    i = 1;
    while ((i < length_list(lines) && ep_str_equals(error, (long long)""))) {
    line = get_list(lines, i);
    colon = string_index_of(line, (long long)":");
    if (colon <= 0) {
    error = (long long)"Malformed HTTP header";
    } else {
    name = string_to_lower((long long)substring((char*)line, 0, colon));
    value = string_trim((long long)substring((char*)line, (colon + 1), ((string_length((char*)line) - colon) - 1)));
    if (ep_str_equals(name, (long long)"content-length")) {
    length_seen = (length_seen + 1);
    remaining = transport_number(value, 10, 1048576);
    if ((remaining < 0 || length_seen > 1)) {
    error = (long long)"Invalid or oversized Content-Length";
    }
    phase = 1;
    } else {
    if (ep_str_equals(name, (long long)"transfer-encoding")) {
    transfer_seen = (transfer_seen + 1);
    if (((!ep_str_equals(string_to_lower(value), (long long)"chunked")) || transfer_seen > 1)) {
    error = (long long)"Unsupported Transfer-Encoding";
    }
    } else {
    if ((ep_str_equals(name, (long long)"content-encoding") && (!ep_str_equals(string_to_lower(value), (long long)"identity")))) {
    error = (long long)"Unsupported Content-Encoding";
    }
    }
    }
    }
    i = (i + 1);
    }
    if (transfer_seen == 1) {
    phase = 3;
    if (length_seen != 0) {
    error = (long long)"Ambiguous HTTP framing";
    }
    }
    buffer = (long long)substring((char*)buffer, (end + 4), ((string_length((char*)buffer) - end) - 4));
    advance = 1;
    }
    }
    } else {
    if (phase == 1) {
    if (string_length((char*)buffer) >= remaining) {
    body = (long long)substring((char*)buffer, 0, remaining);
    buffer = (long long)substring((char*)buffer, remaining, (string_length((char*)buffer) - remaining));
    phase = 6;
    }
    } else {
    if (phase == 2) {
    body = concat(body, buffer);
    buffer = (long long)"";
    if (eof == 1) {
    phase = 6;
    }
    } else {
    if (phase == 3) {
    end = string_index_of(buffer, (long long)"\r\n");
    if (end < 0) {
    if (string_length((char*)buffer) > 1024) {
    error = (long long)"Oversized chunk header";
    }
    } else {
    if (end > 1024) {
    error = (long long)"Oversized chunk header";
    } else {
    size_text = (long long)substring((char*)buffer, 0, end);
    extension = string_index_of(size_text, (long long)";");
    if (extension >= 0) {
    size_text = (long long)substring((char*)size_text, 0, extension);
    }
    remaining = transport_number(size_text, 16, (1048576 - string_length((char*)body)));
    buffer = (long long)substring((char*)buffer, (end + 2), ((string_length((char*)buffer) - end) - 2));
    if (remaining < 0) {
    error = (long long)"Invalid or oversized chunk";
    } else {
    if (remaining == 0) {
    phase = 5;
    } else {
    phase = 4;
    }
    }
    advance = 1;
    }
    }
    } else {
    if (phase == 4) {
    if (string_length((char*)buffer) >= (remaining + 2)) {
    if ((!ep_str_equals((long long)substring((char*)buffer, remaining, 2), (long long)"\r\n"))) {
    error = (long long)"Invalid chunk terminator";
    } else {
    body = concat(body, (long long)substring((char*)buffer, 0, remaining));
    buffer = (long long)substring((char*)buffer, (remaining + 2), ((string_length((char*)buffer) - remaining) - 2));
    phase = 3;
    advance = 1;
    }
    }
    } else {
    if (phase == 5) {
    if (starts_with(buffer, (long long)"\r\n") == 1) {
    buffer = (long long)substring((char*)buffer, 2, (string_length((char*)buffer) - 2));
    phase = 6;
    } else {
    end = string_index_of(buffer, (long long)"\r\n\r\n");
    if ((end >= 0 && end <= 8192)) {
    buffer = (long long)substring((char*)buffer, (end + 4), ((string_length((char*)buffer) - end) - 4));
    phase = 6;
    } else {
    if (string_length((char*)buffer) > 8192) {
    error = (long long)"Oversized HTTP trailers";
    }
    }
    }
    }
    }
    }
    }
    }
    }
    if ((string_length((char*)body) > 1048576 || string_length((char*)buffer) > 1064960)) {
    error = (long long)"Local response exceeded 1 MiB body limit";
    }
    }
    if (((eof == 1 && phase != 6) && ep_str_equals(error, (long long)""))) {
    error = (long long)"Truncated local HTTP response";
    }
    if ((phase == 6 && (!ep_str_equals(buffer, (long long)"")))) {
    error = (long long)"Unexpected bytes after local response";
    }
    set_list(state, 0, phase);
    set_list(state, 1, buffer);
    set_list(state, 2, body);
    set_list(state, 3, remaining);
    set_list(state, 4, error);
    ret_val = (phase == 6 && ep_str_equals(error, (long long)""));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(18);
    free_list(lines);
    lines = 0;
    return ret_val;
}

long long transport_u32(long long pointer, long long offset, long long value) {
    long long i = 0;
    long long number = 0;
    long long ret_val = 0;

    ep_gc_push_root(&number);
    ep_gc_push_root(&pointer);
    ep_gc_push_root(&offset);

    ep_gc_maybe_collect();

    number = value;
    poke_byte(pointer, offset, (number % 256));
    number = (number / 256);
    poke_byte(pointer, (offset + 1), (number % 256));
    number = (number / 256);
    poke_byte(pointer, (offset + 2), (number % 256));
    number = (number / 256);
    poke_byte(pointer, (offset + 3), (number % 256));
    number = (number / 256);
    i = 4;
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long transport_now(long long libc) {
    long long nanos = 0;
    long long seconds = 0;
    long long stamp = 0;
    long long ret_val = 0;

    ep_gc_push_root(&stamp);
    ep_gc_push_root(&libc);

    ep_gc_maybe_collect();

    if (native_android()) {
    stamp = alloc_bytes(16);
    ep_dlcall2(ep_dlsym(libc, (long long)"clock_gettime"), 1, stamp);
    seconds = (((peek_byte(stamp, 0) + (peek_byte(stamp, 1) * 256)) + (peek_byte(stamp, 2) * 65536)) + (peek_byte(stamp, 3) * 16777216));
    nanos = (((peek_byte(stamp, 8) + (peek_byte(stamp, 9) * 256)) + (peek_byte(stamp, 10) * 65536)) + (peek_byte(stamp, 11) * 16777216));
    free_bytes(stamp);
    ret_val = ((seconds * 1000) + (nanos / 1000000));
    goto L_cleanup;
    }
    ret_val = (ep_dlcall1(ep_dlsym(libc, (long long)"clock_gettime_nsec_np"), 6) / 1000000);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long transport_errno(long long libc) {
    long long pointer = 0;
    long long ret_val = 0;

    ep_gc_push_root(&pointer);

    ep_gc_maybe_collect();

    pointer = native_errno_pointer();
    ret_val = peek_byte(pointer, 0);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long transport_wait_cancel(long long libc, long long pollfd, long long fd, long long event, long long deadline, long long cancel) {
    long long result = 0;
    long long timeout = 0;
    long long ret_val = 0;

    ep_gc_push_root(&timeout);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&pollfd);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&event);
    ep_gc_push_root(&cancel);

    ep_gc_maybe_collect();

    transport_u32(pollfd, 0, fd);
    poke_byte(pollfd, 4, event);
    poke_byte(pollfd, 5, 0);
    while (transport_now(libc) < deadline) {
    if (((!ep_str_equals(cancel, (long long)"")) && ep_file_exists(cancel))) {
    ret_val = -1;
    goto L_cleanup;
    }
    poke_byte(pollfd, 6, 0);
    poke_byte(pollfd, 7, 0);
    timeout = (deadline - transport_now(libc));
    if (timeout < 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    if (((!ep_str_equals(cancel, (long long)"")) && timeout > 100)) {
    timeout = 100;
    }
    result = ep_dlcall3(ep_dlsym(libc, (long long)"poll"), pollfd, 1, timeout);
    if ((result > 0 && result < 2147483647)) {
    ret_val = 1;
    goto L_cleanup;
    }
    if ((result == 0 && transport_now(libc) >= deadline)) {
    ret_val = 0;
    goto L_cleanup;
    }
    if ((result != 0 && transport_errno(libc) != 4)) {
    ret_val = 0;
    goto L_cleanup;
    }
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long transport_request_cancel(long long method, long long port, long long path, long long token, long long payload, long long long_running, long long progress, long long cancel) {
    long long address = 0;
    long long again = 0;
    long long ch = 0;
    long long connect_deadline = 0;
    long long data = 0;
    long long deadline = 0;
    long long decoded = 0;
    long long delta = 0;
    long long emitted = 0;
    long long error = 0;
    long long fd = 0;
    long long header = 0;
    long long host = 0;
    long long i = 0;
    long long idle = 0;
    long long idle_setting = 0;
    long long in_progress = 0;
    long long inference = 0;
    long long last_activity = 0;
    long long libc = 0;
    long long n = 0;
    long long option = 0;
    long long pollfd = 0;
    long long rc = 0;
    long long receive_deadline = 0;
    long long request = 0;
    long long result = 0;
    long long send_flags = 0;
    long long sent = 0;
    long long setting = 0;
    long long socket_error = 0;
    long long socket_level = 0;
    long long state = 0;
    long long timeout = 0;
    long long ret_val = 0;

    ep_gc_push_root(&address);
    ep_gc_push_root(&connect_deadline);
    ep_gc_push_root(&data);
    ep_gc_push_root(&deadline);
    ep_gc_push_root(&decoded);
    ep_gc_push_root(&delta);
    ep_gc_push_root(&emitted);
    ep_gc_push_root(&error);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&header);
    ep_gc_push_root(&host);
    ep_gc_push_root(&i);
    ep_gc_push_root(&idle_setting);
    ep_gc_push_root(&inference);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&n);
    ep_gc_push_root(&option);
    ep_gc_push_root(&pollfd);
    ep_gc_push_root(&receive_deadline);
    ep_gc_push_root(&request);
    ep_gc_push_root(&send_flags);
    ep_gc_push_root(&sent);
    ep_gc_push_root(&setting);
    ep_gc_push_root(&socket_error);
    ep_gc_push_root(&socket_level);
    ep_gc_push_root(&state);
    ep_gc_push_root(&method);
    ep_gc_push_root(&port);
    ep_gc_push_root(&path);
    ep_gc_push_root(&token);
    ep_gc_push_root(&payload);
    ep_gc_push_root(&progress);
    ep_gc_push_root(&cancel);

    ep_gc_maybe_collect();

    if (((!ep_str_equals(cancel, (long long)"")) && ep_file_exists(cancel))) {
    ret_val = transport_error((long long)"Local request cancelled");
    goto L_cleanup;
    }
    if (((!ep_str_equals(method, (long long)"POST")) && (!ep_str_equals(method, (long long)"GET")))) {
    ret_val = transport_error((long long)"Unsupported local request method");
    goto L_cleanup;
    }
    if ((port < 1 || port > 65535)) {
    ret_val = transport_error((long long)"Invalid local runtime port");
    goto L_cleanup;
    }
    if (((starts_with(path, (long long)"/") == 0 || string_length((char*)path) > 8192) || string_length((char*)token) > 512)) {
    ret_val = transport_error((long long)"Invalid local request");
    goto L_cleanup;
    }
    i = 0;
    while (i < string_length((char*)path)) {
    ch = get_character((char*)path, i);
    if (((ch <= 32 || ch >= 127) || ch == 35)) {
    ret_val = transport_error((long long)"Invalid local request path");
    goto L_cleanup;
    }
    i = (i + 1);
    }
    if ((string_contains(token, (long long)"\r") || string_contains(token, (long long)"\n"))) {
    ret_val = transport_error((long long)"Invalid local authorization");
    goto L_cleanup;
    }
    setting = ep_getenv((long long)"ECHOLITE_REQUEST_TIMEOUT_MS");
    timeout = 120000;
    if ((!ep_str_equals(setting, (long long)""))) {
    timeout = transport_number(setting, 10, 600000);
    if (timeout < 100) {
    ret_val = transport_error((long long)"Invalid request timeout");
    goto L_cleanup;
    }
    }
    idle = 120000;
    if (long_running == 1) {
    inference = ep_getenv((long long)"ECHOLITE_INFERENCE_TIMEOUT_MS");
    if ((!ep_str_equals(inference, (long long)""))) {
    timeout = transport_number(inference, 10, 86400000);
    if (timeout < 100) {
    ret_val = transport_error((long long)"Invalid inference timeout");
    goto L_cleanup;
    }
    } else {
    if (ep_str_equals(setting, (long long)"")) {
    timeout = 86400000;
    }
    }
    idle_setting = ep_getenv((long long)"ECHOLITE_INFERENCE_IDLE_SECONDS");
    if ((!ep_str_equals(idle_setting, (long long)""))) {
    idle = (transport_number(idle_setting, 10, 600) * 1000);
    if (idle < 1000) {
    ret_val = transport_error((long long)"Invalid inference idle timeout");
    goto L_cleanup;
    }
    }
    }
    libc = native_system();
    socket_level = 65535;
    socket_error = 4103;
    in_progress = 36;
    again = 35;
    send_flags = 0;
    if (native_android()) {
    socket_level = 1;
    socket_error = 4;
    in_progress = 115;
    again = 11;
    send_flags = 16384;
    }
    fd = ep_dlcall3(ep_dlsym(libc, (long long)"socket"), 2, 1, 0);
    if ((fd < 0 || fd > 2147483647)) {
    ret_val = transport_error((long long)"Local socket creation failed");
    goto L_cleanup;
    }
    pollfd = alloc_bytes(8);
    address = alloc_bytes(16);
    option = alloc_bytes(4);
    poke_byte(address, 0, 16);
    poke_byte(address, 1, 2);
    if (native_android()) {
    poke_byte(address, 0, 2);
    poke_byte(address, 1, 0);
    }
    poke_byte(address, 2, (port / 256));
    poke_byte(address, 3, (port % 256));
    poke_byte(address, 4, 127);
    poke_byte(address, 7, 1);
    transport_u32(option, 0, 1);
    error = (long long)"";
    if ((native_fcntl_int(fd, 4, 4) != 0 || native_fcntl_int(fd, 2, 1) != 0)) {
    error = (long long)"Socket configuration failed";
    }
    if ((native_android() == 0 && ep_dlcall5(ep_dlsym(libc, (long long)"setsockopt"), fd, 65535, 4130, option, 4) != 0)) {
    error = (long long)"Socket signal configuration failed";
    }
    deadline = (transport_now(libc) + timeout);
    if (ep_str_equals(error, (long long)"")) {
    result = ep_dlcall3(ep_dlsym(libc, (long long)"connect"), fd, address, 16);
    if (result != 0) {
    if (transport_errno(libc) != in_progress) {
    error = (long long)"Local connection failed";
    } else {
    connect_deadline = (transport_now(libc) + 2000);
    if (connect_deadline > deadline) {
    connect_deadline = deadline;
    }
    if (transport_wait_cancel(libc, pollfd, fd, 4, connect_deadline, cancel) <= 0) {
    error = (long long)"Local connection deadline exceeded";
    } else {
    transport_u32(address, 0, 4);
    transport_u32(option, 0, 0);
    rc = ep_dlcall5(ep_dlsym(libc, (long long)"getsockopt"), fd, socket_level, socket_error, option, address);
    if ((rc != 0 || peek_byte(option, 0) != 0)) {
    error = (long long)"Local connection failed";
    }
    }
    }
    }
    }
    host = concat((long long)" HTTP/1.1\r\nHost: 127.0.0.1:", concat(int_to_string(port), (long long)"\r\nConnection: close\r\nContent-Type: application/json\r\nAuthorization: Bearer "));
    header = concat(method, concat((long long)" ", concat(path, host)));
    request = concat(header, concat(token, concat((long long)"\r\nContent-Length: ", concat(int_to_string(string_length((char*)payload)), concat((long long)"\r\n\r\n", payload)))));
    sent = 0;
    while ((sent < string_length((char*)request) && ep_str_equals(error, (long long)""))) {
    if (transport_wait_cancel(libc, pollfd, fd, 4, deadline, cancel) <= 0) {
    error = (long long)"Local request deadline exceeded";
    } else {
    n = ep_dlcall4(ep_dlsym(libc, (long long)"send"), fd, (str_to_ptr(request) + sent), (string_length((char*)request) - sent), send_flags);
    if (n > 0) {
    sent = (sent + n);
    } else {
    if (n == 0) {
    error = (long long)"Local connection closed during request";
    } else {
    if ((transport_errno(libc) != 4 && transport_errno(libc) != again)) {
    error = (long long)"Local request send failed";
    }
    }
    }
    }
    }
    state = transport_parser();
    data = alloc_bytes(16385);
    emitted = 0;
    last_activity = transport_now(libc);
    while ((ep_str_equals(error, (long long)"") && get_list(state, 0) != 6)) {
    receive_deadline = deadline;
    if ((long_running == 1 && (last_activity + idle) < receive_deadline)) {
    receive_deadline = (last_activity + idle);
    }
    if (transport_wait_cancel(libc, pollfd, fd, 1, receive_deadline, cancel) <= 0) {
    error = (long long)"Local request or inference idle deadline exceeded";
    } else {
    n = ep_dlcall4(ep_dlsym(libc, (long long)"recv"), fd, data, 16384, 0);
    if (n == 0) {
    transport_parse(state, (long long)"", 1);
    error = get_list(state, 4);
    } else {
    if (n < 0) {
    if ((transport_errno(libc) != 4 && transport_errno(libc) != again)) {
    error = (long long)"Local response read failed";
    }
    } else {
    last_activity = transport_now(libc);
    i = 0;
    while (i < n) {
    if (peek_byte(data, i) == 0) {
    error = (long long)"Local response contained NUL bytes";
    }
    i = (i + 1);
    }
    if (ep_str_equals(error, (long long)"")) {
    poke_byte(data, n, 0);
    transport_parse(state, ptr_to_str(data), 0);
    error = get_list(state, 4);
    }
    }
    }
    }
    if ((progress != 0 && ep_str_equals(error, (long long)""))) {
    decoded = get_list(state, 2);
    if (string_length((char*)decoded) > emitted) {
    delta = concat((long long)"data\n", (long long)substring((char*)decoded, emitted, (string_length((char*)decoded) - emitted)));
    send_channel(progress, delta);
    emitted = string_length((char*)decoded);
    }
    }
    }
    ep_dlcall1(ep_dlsym(libc, (long long)"close"), fd);
    free_bytes(data);
    free_bytes(option);
    free_bytes(address);
    free_bytes(pollfd);
    if (((!ep_str_equals(cancel, (long long)"")) && ep_file_exists(cancel))) {
    ret_val = transport_error((long long)"Local request cancelled");
    goto L_cleanup;
    }
    if ((!ep_str_equals(error, (long long)""))) {
    ret_val = transport_error(error);
    goto L_cleanup;
    }
    ret_val = get_list(state, 2);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(33);
    return ret_val;
}

long long local_post(long long path, long long token, long long payload) {
    long long long_running = 0;
    long long response = 0;
    long long ret_val = 0;

    ep_gc_push_root(&long_running);
    ep_gc_push_root(&response);
    ep_gc_push_root(&path);
    ep_gc_push_root(&token);
    ep_gc_push_root(&payload);

    ep_gc_maybe_collect();

    if (string_contains(path, (long long)"?")) {
    ret_val = transport_error((long long)"Invalid local request path");
    goto L_cleanup;
    }
    long_running = 0;
    if (ep_str_equals(path, (long long)"/generate")) {
    long_running = 1;
    }
    response = transport_request_cancel((long long)"POST", 8399, path, token, payload, long_running, 0, (long long)"");
    ret_val = response;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long transport_post(long long port, long long path, long long token, long long payload, long long long_running, long long progress) {
    long long response = 0;
    long long ret_val = 0;

    ep_gc_push_root(&response);
    ep_gc_push_root(&port);
    ep_gc_push_root(&path);
    ep_gc_push_root(&token);
    ep_gc_push_root(&payload);
    ep_gc_push_root(&long_running);
    ep_gc_push_root(&progress);

    ep_gc_maybe_collect();

    response = transport_request_cancel((long long)"POST", port, path, token, payload, long_running, progress, (long long)"");
    ret_val = response;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long transport_get(long long port, long long path, long long token) {
    long long response = 0;
    long long ret_val = 0;

    ep_gc_push_root(&response);
    ep_gc_push_root(&port);
    ep_gc_push_root(&path);
    ep_gc_push_root(&token);

    ep_gc_maybe_collect();

    response = transport_request_cancel((long long)"GET", port, path, token, (long long)"", 0, 0, (long long)"");
    ret_val = response;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long transport_wait(long long libc, long long pollfd, long long fd, long long event, long long deadline) {
    long long ret_val = 0;

    ep_gc_push_root(&libc);
    ep_gc_push_root(&pollfd);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&event);
    ep_gc_push_root(&deadline);

    ep_gc_maybe_collect();

    ret_val = transport_wait_cancel(libc, pollfd, fd, event, deadline, (long long)"");
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long transport_request(long long method, long long port, long long path, long long token, long long payload, long long long_running, long long progress) {
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&result);
    ep_gc_push_root(&method);
    ep_gc_push_root(&port);
    ep_gc_push_root(&path);
    ep_gc_push_root(&token);
    ep_gc_push_root(&payload);
    ep_gc_push_root(&long_running);
    ep_gc_push_root(&progress);

    ep_gc_maybe_collect();

    result = transport_request_cancel(method, port, path, token, payload, long_running, progress, (long long)"");
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long create_json_int(long long val) {
    long long node = 0;
    long long ok = 0;
    long long ret_val = 0;

    ep_gc_push_root(&node);
    ep_gc_push_root(&val);

    ep_gc_maybe_collect();

    node = create_list();
    ok = append_list(node, 1);
    ok = append_list(node, val);
    ret_val = node;
    node = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long create_json_string(long long val) {
    long long node = 0;
    long long ok = 0;
    long long ret_val = 0;

    ep_gc_push_root(&node);
    ep_gc_push_root(&val);

    ep_gc_maybe_collect();

    node = create_list();
    ok = append_list(node, 2);
    ok = append_list(node, val);
    ret_val = node;
    node = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long create_json_list(long long val) {
    long long node = 0;
    long long ok = 0;
    long long ret_val = 0;

    ep_gc_push_root(&node);
    ep_gc_push_root(&val);

    ep_gc_maybe_collect();

    node = create_list();
    ok = append_list(node, 3);
    ok = append_list(node, val);
    ret_val = node;
    node = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long create_json_object(long long keys, long long values) {
    long long node = 0;
    long long ok = 0;
    long long ret_val = 0;

    ep_gc_push_root(&node);
    ep_gc_push_root(&keys);
    ep_gc_push_root(&values);

    ep_gc_maybe_collect();

    node = create_list();
    ok = append_list(node, 4);
    ok = append_list(node, keys);
    ok = append_list(node, values);
    ret_val = node;
    node = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long get_json_type(long long node) {
    long long ret_val = 0;

    ep_gc_push_root(&node);

    ep_gc_maybe_collect();

    if (node == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    ret_val = get_list(node, 0);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long get_json_value(long long node) {
    long long ret_val = 0;

    ep_gc_push_root(&node);

    ep_gc_maybe_collect();

    if (node == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    ret_val = get_list(node, 1);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long get_json_object_value(long long node, long long key) {
    long long idx = 0;
    long long k = 0;
    long long keys = 0;
    long long len = 0;
    long long t = 0;
    long long values = 0;
    long long ret_val = 0;

    ep_gc_push_root(&idx);
    ep_gc_push_root(&keys);
    ep_gc_push_root(&values);
    ep_gc_push_root(&node);
    ep_gc_push_root(&key);

    ep_gc_maybe_collect();

    if (node == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    t = get_json_type(node);
    if (t != 4) {
    ret_val = 0;
    goto L_cleanup;
    }
    keys = get_list(node, 1);
    values = get_list(node, 2);
    len = length_list(keys);
    idx = 0;
    while (idx < len) {
    k = get_list(keys, idx);
    if (ep_str_equals(concat(key, (long long)""), k)) {
    ret_val = get_list(values, idx);
    goto L_cleanup;
    }
    idx = (idx + 1);
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long json_escape_string(long long str_val) {
    long long ch = 0;
    long long i = 0;
    long long len = 0;
    long long ok = 0;
    long long out = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&out);
    ep_gc_push_root(&str_val);

    ep_gc_maybe_collect();

    out = ep_sb_create(0);
    len = string_length((char*)str_val);
    i = 0;
    while (i < len) {
    ch = get_character((char*)str_val, i);
    if (ch == 34) {
    ok = ep_sb_append(out, (long long)"\\\"");
    } else {
    if (ch == 92) {
    ok = ep_sb_append(out, (long long)"\\\\");
    } else {
    if (ch == 10) {
    ok = ep_sb_append(out, (long long)"\\n");
    } else {
    if (ch == 13) {
    ok = ep_sb_append(out, (long long)"\\r");
    } else {
    if (ch == 9) {
    ok = ep_sb_append(out, (long long)"\\t");
    } else {
    ok = ep_sb_append(out, (long long)substring((char*)str_val, i, 1));
    }
    }
    }
    }
    }
    i = (i + 1);
    }
    ret_val = ep_sb_to_string(out);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long json_stringify(long long node) {
    long long escaped = 0;
    long long idx = 0;
    long long int_val = 0;
    long long item = 0;
    long long item_str = 0;
    long long k = 0;
    long long k_esc = 0;
    long long k_quoted = 0;
    long long keys = 0;
    long long len = 0;
    long long list_items = 0;
    long long res = 0;
    long long s1 = 0;
    long long str_val = 0;
    long long type = 0;
    long long v = 0;
    long long v_str = 0;
    long long values = 0;
    long long ret_val = 0;

    ep_gc_push_root(&escaped);
    ep_gc_push_root(&idx);
    ep_gc_push_root(&item);
    ep_gc_push_root(&item_str);
    ep_gc_push_root(&k);
    ep_gc_push_root(&k_esc);
    ep_gc_push_root(&k_quoted);
    ep_gc_push_root(&keys);
    ep_gc_push_root(&list_items);
    ep_gc_push_root(&res);
    ep_gc_push_root(&s1);
    ep_gc_push_root(&str_val);
    ep_gc_push_root(&v);
    ep_gc_push_root(&v_str);
    ep_gc_push_root(&values);
    ep_gc_push_root(&node);

    ep_gc_maybe_collect();

    type = get_json_type(node);
    if (type == 1) {
    int_val = get_list(node, 1);
    ret_val = int_to_string(int_val);
    goto L_cleanup;
    }
    if (type == 2) {
    str_val = get_list(node, 1);
    escaped = json_escape_string(str_val);
    s1 = concat((long long)"\"", escaped);
    ret_val = concat(s1, (long long)"\"");
    goto L_cleanup;
    }
    if (type == 3) {
    list_items = get_list(node, 1);
    len = length_list(list_items);
    res = (long long)"[";
    idx = 0;
    while (idx < len) {
    item = get_list(list_items, idx);
    item_str = json_stringify(item);
    res = concat(res, item_str);
    if (idx < (len - 1)) {
    res = concat(res, (long long)",");
    }
    idx = (idx + 1);
    }
    ret_val = concat(res, (long long)"]");
    goto L_cleanup;
    }
    if (type == 4) {
    keys = get_list(node, 1);
    values = get_list(node, 2);
    len = length_list(keys);
    res = (long long)"{";
    idx = 0;
    while (idx < len) {
    k = get_list(keys, idx);
    v = get_list(values, idx);
    v_str = json_stringify(v);
    k_esc = json_escape_string(k);
    k_quoted = concat((long long)"\"", k_esc);
    k_quoted = concat(k_quoted, (long long)"\":");
    res = concat(res, k_quoted);
    res = concat(res, v_str);
    if (idx < (len - 1)) {
    res = concat(res, (long long)",");
    }
    idx = (idx + 1);
    }
    ret_val = concat(res, (long long)"}");
    goto L_cleanup;
    }
    ret_val = (long long)"null";
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(16);
    return ret_val;
}

long long json_skip_whitespace(long long state) {
    long long ch = 0;
    long long len = 0;
    long long loop = 0;
    long long ok = 0;
    long long pos = 0;
    long long s = 0;
    long long ret_val = 0;

    ep_gc_push_root(&pos);
    ep_gc_push_root(&s);
    ep_gc_push_root(&state);

    ep_gc_maybe_collect();

    s = get_list(state, 0);
    len = get_list(state, 1);
    pos = get_list(state, 2);
    loop = 1;
    while ((pos < len && loop == 1)) {
    ch = get_character((char*)s, pos);
    if ((((ch == 32 || ch == 9) || ch == 10) || ch == 13)) {
    pos = (pos + 1);
    } else {
    loop = 0;
    }
    }
    ok = set_list(state, 2, pos);
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long json_hex_val(long long c) {
    long long ret_val = 0;

    if ((c >= 48 && c <= 57)) {
    ret_val = (c - 48);
    goto L_cleanup;
    }
    if ((c >= 97 && c <= 102)) {
    ret_val = (c - 87);
    goto L_cleanup;
    }
    if ((c >= 65 && c <= 70)) {
    ret_val = (c - 55);
    goto L_cleanup;
    }
    ret_val = -1;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long json_parse_hex4(long long s, long long p, long long len) {
    long long h0 = 0;
    long long h1 = 0;
    long long h2 = 0;
    long long h3 = 0;
    long long ret_val = 0;

    ep_gc_push_root(&s);
    ep_gc_push_root(&p);

    ep_gc_maybe_collect();

    if ((p + 3) >= len) {
    ret_val = -1;
    goto L_cleanup;
    }
    h0 = json_hex_val(get_character((char*)s, p));
    h1 = json_hex_val(get_character((char*)s, (p + 1)));
    h2 = json_hex_val(get_character((char*)s, (p + 2)));
    h3 = json_hex_val(get_character((char*)s, (p + 3)));
    if ((((h0 < 0 || h1 < 0) || h2 < 0) || h3 < 0)) {
    ret_val = -1;
    goto L_cleanup;
    }
    ret_val = (((h0 * 4096) + (h1 * 256)) + ((h2 * 16) + h3));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long json_append_utf8(long long lst, long long cp) {
    long long ok = 0;
    long long r2 = 0;
    long long r3 = 0;
    long long ret_val = 0;

    ep_gc_push_root(&r2);
    ep_gc_push_root(&r3);
    ep_gc_push_root(&lst);
    ep_gc_push_root(&cp);

    ep_gc_maybe_collect();

    if (cp < 128) {
    ok = append_list(lst, cp);
    } else {
    if (cp < 2048) {
    ok = append_list(lst, (192 + (cp / 64)));
    ok = append_list(lst, (128 + (cp - ((cp / 64) * 64))));
    } else {
    if (cp < 65536) {
    ok = append_list(lst, (224 + (cp / 4096)));
    r2 = (cp - ((cp / 4096) * 4096));
    ok = append_list(lst, (128 + (r2 / 64)));
    ok = append_list(lst, (128 + (r2 - ((r2 / 64) * 64))));
    } else {
    ok = append_list(lst, (240 + (cp / 262144)));
    r3 = (cp - ((cp / 262144) * 262144));
    ok = append_list(lst, (128 + (r3 / 4096)));
    r3 = (r3 - ((r3 / 4096) * 4096));
    ok = append_list(lst, (128 + (r3 / 64)));
    ok = append_list(lst, (128 + (r3 - ((r3 / 64) * 64))));
    }
    }
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long json_parse_string(long long state) {
    long long ch = 0;
    long long cp = 0;
    long long esc = 0;
    long long len = 0;
    long long lo = 0;
    long long loop = 0;
    long long lst = 0;
    long long ok = 0;
    long long pos = 0;
    long long s = 0;
    long long val = 0;
    long long ret_val = 0;

    ep_gc_push_root(&ch);
    ep_gc_push_root(&cp);
    ep_gc_push_root(&esc);
    ep_gc_push_root(&len);
    ep_gc_push_root(&lst);
    ep_gc_push_root(&pos);
    ep_gc_push_root(&s);
    ep_gc_push_root(&val);
    ep_gc_push_root(&state);

    ep_gc_maybe_collect();

    s = get_list(state, 0);
    len = get_list(state, 1);
    pos = get_list(state, 2);
    pos = (pos + 1);
    lst = create_list();
    loop = 1;
    while ((pos < len && loop == 1)) {
    ch = get_character((char*)s, pos);
    if (ch == 34) {
    pos = (pos + 1);
    loop = 0;
    } else {
    if (ch == 92) {
    pos = (pos + 1);
    if (pos < len) {
    esc = get_character((char*)s, pos);
    if (esc == 110) {
    ok = append_list(lst, 10);
    pos = (pos + 1);
    } else {
    if (esc == 116) {
    ok = append_list(lst, 9);
    pos = (pos + 1);
    } else {
    if (esc == 114) {
    ok = append_list(lst, 13);
    pos = (pos + 1);
    } else {
    if (esc == 98) {
    ok = append_list(lst, 8);
    pos = (pos + 1);
    } else {
    if (esc == 102) {
    ok = append_list(lst, 12);
    pos = (pos + 1);
    } else {
    if (esc == 117) {
    cp = json_parse_hex4(s, (pos + 1), len);
    if (cp < 0) {
    ok = append_list(lst, esc);
    pos = (pos + 1);
    } else {
    pos = (pos + 5);
    if ((cp >= 55296 && cp <= 56319)) {
    if ((pos + 1) < len) {
    if ((get_character((char*)s, pos) == 92 && get_character((char*)s, (pos + 1)) == 117)) {
    lo = json_parse_hex4(s, (pos + 2), len);
    if ((lo >= 56320 && lo <= 57343)) {
    cp = (65536 + (((cp - 55296) * 1024) + (lo - 56320)));
    pos = (pos + 6);
    }
    }
    }
    }
    ok = json_append_utf8(lst, cp);
    }
    } else {
    ok = append_list(lst, esc);
    pos = (pos + 1);
    }
    }
    }
    }
    }
    }
    }
    } else {
    ok = append_list(lst, ch);
    pos = (pos + 1);
    }
    }
    }
    ok = set_list(state, 2, pos);
    val = (long long)string_from_list(lst);
    ret_val = create_json_string(val);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    return ret_val;
}

long long json_parse_number(long long state) {
    long long ch = 0;
    long long is_neg = 0;
    long long len = 0;
    long long loop = 0;
    long long ok = 0;
    long long pos = 0;
    long long s = 0;
    long long val = 0;
    long long ret_val = 0;

    ep_gc_push_root(&pos);
    ep_gc_push_root(&s);
    ep_gc_push_root(&val);
    ep_gc_push_root(&state);

    ep_gc_maybe_collect();

    s = get_list(state, 0);
    len = get_list(state, 1);
    pos = get_list(state, 2);
    if (pos >= len) {
    ret_val = create_json_int(0);
    goto L_cleanup;
    }
    is_neg = 0;
    ch = get_character((char*)s, pos);
    if (ch == 45) {
    is_neg = 1;
    pos = (pos + 1);
    }
    val = 0;
    loop = 1;
    while ((pos < len && loop == 1)) {
    ch = get_character((char*)s, pos);
    if ((ch > 47 && ch < 58)) {
    if (val < 922337203685477580) {
    val = (val * 10);
    val = (val + (ch - 48));
    }
    pos = (pos + 1);
    } else {
    loop = 0;
    }
    }
    if (is_neg == 1) {
    val = (0 - val);
    }
    if (pos < len) {
    ch = get_character((char*)s, pos);
    if (ch == 46) {
    pos = (pos + 1);
    loop = 1;
    while ((pos < len && loop == 1)) {
    ch = get_character((char*)s, pos);
    if ((ch > 47 && ch < 58)) {
    pos = (pos + 1);
    } else {
    loop = 0;
    }
    }
    }
    }
    if (pos < len) {
    ch = get_character((char*)s, pos);
    if ((ch == 101 || ch == 69)) {
    pos = (pos + 1);
    if (pos < len) {
    ch = get_character((char*)s, pos);
    if ((ch == 43 || ch == 45)) {
    pos = (pos + 1);
    }
    }
    loop = 1;
    while ((pos < len && loop == 1)) {
    ch = get_character((char*)s, pos);
    if ((ch > 47 && ch < 58)) {
    pos = (pos + 1);
    } else {
    loop = 0;
    }
    }
    }
    }
    ok = set_list(state, 2, pos);
    ret_val = create_json_int(val);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long json_parse_value(long long state) {
    long long ch = 0;
    long long depth = 0;
    long long len = 0;
    long long lit = 0;
    long long ok = 0;
    long long pos = 0;
    long long ret_node = 0;
    long long s = 0;
    long long ret_val = 0;

    ep_gc_push_root(&depth);
    ep_gc_push_root(&lit);
    ep_gc_push_root(&pos);
    ep_gc_push_root(&ret_node);
    ep_gc_push_root(&s);
    ep_gc_push_root(&state);

    ep_gc_maybe_collect();

    ok = json_skip_whitespace(state);
    s = get_list(state, 0);
    len = get_list(state, 1);
    pos = get_list(state, 2);
    if (pos > (len - 1)) {
    ret_val = 0;
    goto L_cleanup;
    }
    depth = get_list(state, 3);
    if (depth > 100) {
    ret_val = 0;
    goto L_cleanup;
    }
    ok = set_list(state, 3, (depth + 1));
    ch = get_character((char*)s, pos);
    ret_node = 0;
    if (ch == 123) {
    ret_node = json_parse_object(state);
    } else {
    if (ch == 91) {
    ret_node = json_parse_list(state);
    } else {
    if (ch == 34) {
    ret_node = json_parse_string(state);
    } else {
    if (((ch > 47 && ch < 58) || ch == 45)) {
    ret_node = json_parse_number(state);
    } else {
    if (ch == 110) {
    if ((pos + 4) <= len) {
    lit = (long long)substring((char*)s, pos, 4);
    if (string_equals(lit, (long long)"null")) {
    pos = (pos + 4);
    ok = set_list(state, 2, pos);
    }
    }
    ret_node = 0;
    } else {
    if (ch == 116) {
    if ((pos + 4) <= len) {
    lit = (long long)substring((char*)s, pos, 4);
    if (string_equals(lit, (long long)"true")) {
    pos = (pos + 4);
    ok = set_list(state, 2, pos);
    ret_node = create_json_int(1);
    }
    }
    } else {
    if (ch == 102) {
    if ((pos + 5) <= len) {
    lit = (long long)substring((char*)s, pos, 5);
    if (string_equals(lit, (long long)"false")) {
    pos = (pos + 5);
    ok = set_list(state, 2, pos);
    ret_node = create_json_int(0);
    }
    }
    }
    }
    }
    }
    }
    }
    }
    ok = set_list(state, 3, depth);
    ret_val = ret_node;
    ret_node = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long json_parse_object(long long state) {
    long long ch = 0;
    long long count = 0;
    long long key_node = 0;
    long long key_val = 0;
    long long keys = 0;
    long long len = 0;
    long long loop = 0;
    long long ok = 0;
    long long pos = 0;
    long long s = 0;
    long long val_node = 0;
    long long values = 0;
    long long ret_val = 0;

    ep_gc_push_root(&key_node);
    ep_gc_push_root(&key_val);
    ep_gc_push_root(&keys);
    ep_gc_push_root(&pos);
    ep_gc_push_root(&s);
    ep_gc_push_root(&val_node);
    ep_gc_push_root(&values);
    ep_gc_push_root(&state);

    ep_gc_maybe_collect();

    s = get_list(state, 0);
    len = get_list(state, 1);
    pos = get_list(state, 2);
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    keys = create_list();
    values = create_list();
    count = 0;
    loop = 1;
    while (loop == 1) {
    ok = json_skip_whitespace(state);
    pos = get_list(state, 2);
    if (pos > (len - 1)) {
    loop = 0;
    } else {
    ch = get_character((char*)s, pos);
    if (ch == 125) {
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    loop = 0;
    } else {
    key_node = json_parse_string(state);
    key_val = get_json_value(key_node);
    ok = json_skip_whitespace(state);
    pos = get_list(state, 2);
    if (pos > (len - 1)) {
    loop = 0;
    } else {
    ch = get_character((char*)s, pos);
    if (ch == 58) {
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    }
    val_node = json_parse_value(state);
    ok = append_list(keys, key_val);
    ok = append_list(values, val_node);
    count = (count + 1);
    if (count >= 1000000) {
    loop = 0;
    }
    ok = json_skip_whitespace(state);
    pos = get_list(state, 2);
    if (pos > (len - 1)) {
    loop = 0;
    } else {
    ch = get_character((char*)s, pos);
    if (ch == 44) {
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    } else {
    if (ch == 125) {
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    loop = 0;
    } else {
    loop = 0;
    }
    }
    }
    }
    }
    }
    }
    ret_val = create_json_object(keys, values);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long json_parse_list(long long state) {
    long long ch = 0;
    long long count = 0;
    long long item_node = 0;
    long long items = 0;
    long long len = 0;
    long long loop = 0;
    long long ok = 0;
    long long pos = 0;
    long long s = 0;
    long long ret_val = 0;

    ep_gc_push_root(&item_node);
    ep_gc_push_root(&items);
    ep_gc_push_root(&pos);
    ep_gc_push_root(&s);
    ep_gc_push_root(&state);

    ep_gc_maybe_collect();

    s = get_list(state, 0);
    len = get_list(state, 1);
    pos = get_list(state, 2);
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    items = create_list();
    count = 0;
    loop = 1;
    while (loop == 1) {
    ok = json_skip_whitespace(state);
    pos = get_list(state, 2);
    if (pos > (len - 1)) {
    loop = 0;
    } else {
    ch = get_character((char*)s, pos);
    if (ch == 93) {
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    loop = 0;
    } else {
    item_node = json_parse_value(state);
    ok = append_list(items, item_node);
    count = (count + 1);
    if (count >= 1000000) {
    loop = 0;
    }
    ok = json_skip_whitespace(state);
    pos = get_list(state, 2);
    if (pos > (len - 1)) {
    loop = 0;
    } else {
    ch = get_character((char*)s, pos);
    if (ch == 44) {
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    } else {
    if (ch == 93) {
    pos = (pos + 1);
    ok = set_list(state, 2, pos);
    loop = 0;
    } else {
    loop = 0;
    }
    }
    }
    }
    }
    }
    ret_val = create_json_list(items);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long json_parse(long long json_str) {
    long long ok = 0;
    long long state = 0;
    long long ret_val = 0;

    ep_gc_push_root(&state);
    ep_gc_push_root(&json_str);

    ep_gc_maybe_collect();

    state = create_list();
    ok = append_list(state, json_str);
    ok = append_list(state, string_length((char*)json_str));
    ok = append_list(state, 0);
    ok = append_list(state, 0);
    ret_val = json_parse_value(state);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long read_file(long long path) {
    long long ret_val = 0;

    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    ret_val = ep_read_file(path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long read_lines(long long path) {
    long long content = 0;
    long long lines = 0;
    long long ret_val = 0;

    ep_gc_push_root(&content);
    ep_gc_push_root(&lines);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    content = ep_read_file(path);
    lines = string_split(content, (long long)"\n");
    ret_val = lines;
    lines = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long write_file(long long path, long long content) {
    long long ret_val = 0;

    ep_gc_push_root(&path);
    ep_gc_push_root(&content);

    ep_gc_maybe_collect();

    ret_val = ep_write_file(path, content);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long append_file(long long path, long long content) {
    long long ret_val = 0;

    ep_gc_push_root(&path);
    ep_gc_push_root(&content);

    ep_gc_maybe_collect();

    ret_val = ep_append_file(path, content);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long is_directory(long long path) {
    long long ret_val = 0;

    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    ret_val = ep_is_directory(path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long file_size(long long path) {
    long long ret_val = 0;

    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    ret_val = ep_file_size(path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long list_directory(long long path) {
    long long ret_val = 0;

    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    ret_val = ep_list_directory(path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long create_directory(long long path) {
    long long ret_val = 0;

    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    ret_val = ep_create_directory(path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long remove_file(long long path) {
    long long ret_val = 0;

    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    ret_val = ep_remove_file(path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long remove_directory(long long path) {
    long long ret_val = 0;

    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    ret_val = ep_remove_directory(path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long rename_file(long long old_path, long long new_path) {
    long long ret_val = 0;

    ep_gc_push_root(&old_path);
    ep_gc_push_root(&new_path);

    ep_gc_maybe_collect();

    ret_val = ep_rename_file(old_path, new_path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long copy_file(long long src, long long dst) {
    long long ret_val = 0;

    ep_gc_push_root(&src);
    ep_gc_push_root(&dst);

    ep_gc_maybe_collect();

    ret_val = ep_copy_file(src, dst);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long path_join(long long base, long long child) {
    long long ret_val = 0;

    ep_gc_push_root(&base);
    ep_gc_push_root(&child);

    ep_gc_maybe_collect();

    ret_val = concat(concat(base, (long long)"/"), child);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long path_extension(long long path) {
    long long ch = 0;
    long long i = 0;
    long long len = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&len);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    len = string_length((char*)path);
    i = (len - 1);
    while (i > -1) {
    ch = get_character((char*)path, i);
    if (ch == 46) {
    ret_val = (long long)substring((char*)path, (i + 1), ((len - i) - 1));
    goto L_cleanup;
    }
    if (ch == 47) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    i = (i - 1);
    }
    ret_val = (long long)"";
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long path_basename(long long path) {
    long long ch = 0;
    long long i = 0;
    long long len = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&len);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    len = string_length((char*)path);
    i = (len - 1);
    while (i > -1) {
    ch = get_character((char*)path, i);
    if (ch == 47) {
    ret_val = (long long)substring((char*)path, (i + 1), ((len - i) - 1));
    goto L_cleanup;
    }
    i = (i - 1);
    }
    ret_val = path;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long path_dirname(long long path) {
    long long ch = 0;
    long long i = 0;
    long long len = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    len = string_length((char*)path);
    i = (len - 1);
    while (i > -1) {
    ch = get_character((char*)path, i);
    if (ch == 47) {
    ret_val = (long long)substring((char*)path, 0, i);
    goto L_cleanup;
    }
    i = (i - 1);
    }
    ret_val = (long long)".";
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_load() {
    long long ret_val = 0;

    RAYLIB_HANDLE = ep_dlopen((long long)"libraylib.dylib");
    if (RAYLIB_HANDLE == 0) {
    RAYLIB_HANDLE = ep_dlopen((long long)"/opt/homebrew/lib/libraylib.dylib");
    }
    if (RAYLIB_HANDLE == 0) {
    RAYLIB_HANDLE = ep_dlopen((long long)"/usr/local/lib/libraylib.dylib");
    }
    if (RAYLIB_HANDLE == 0) {
    RAYLIB_HANDLE = ep_dlopen((long long)"libraylib.so");
    }
    if (RAYLIB_HANDLE == 0) {
    RAYLIB_HANDLE = ep_dlopen((long long)"libraylib.so.5");
    }
    if (RAYLIB_HANDLE == 0) {
    RAYLIB_HANDLE = ep_dlopen((long long)"/usr/lib/libraylib.so");
    }
    ret_val = RAYLIB_HANDLE;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long raylib_init_window(long long width, long long height, long long title) {
    long long fn = 0;
    long long ok = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&width);
    ep_gc_push_root(&height);
    ep_gc_push_root(&title);

    ep_gc_maybe_collect();

    if (RAYLIB_HANDLE == 0) {
    ok = raylib_load();
    }
    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"InitWindow");
    ret_val = ep_dlcall3(fn, width, height, title);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long raylib_close_window() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"CloseWindow");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_window_should_close() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"WindowShouldClose");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_set_target_fps(long long fps) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&fps);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetTargetFPS");
    ret_val = ep_dlcall1(fn, fps);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_get_fps() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetFPS");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_get_screen_width() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetScreenWidth");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_get_screen_height() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetScreenHeight");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_set_window_title(long long title) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&title);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetWindowTitle");
    ret_val = ep_dlcall1(fn, title);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_toggle_fullscreen() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"ToggleFullscreen");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_set_window_size(long long width, long long height) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&width);
    ep_gc_push_root(&height);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetWindowSize");
    ret_val = ep_dlcall2(fn, width, height);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long raylib_is_window_resized() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsWindowResized");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_is_window_focused() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsWindowFocused");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_set_window_icon(long long image) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&image);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetWindowIcon");
    ret_val = ep_dlcall1(fn, image);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_begin_drawing() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"BeginDrawing");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_end_drawing() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"EndDrawing");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_clear_background(long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"ClearBackground");
    ret_val = ep_dlcall1(fn, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_draw_pixel(long long x, long long y, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawPixel");
    ret_val = ep_dlcall3(fn, x, y, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long raylib_draw_line(long long startx, long long starty, long long endx, long long endy, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&startx);
    ep_gc_push_root(&starty);
    ep_gc_push_root(&endx);
    ep_gc_push_root(&endy);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawLine");
    ret_val = ep_dlcall5(fn, startx, starty, endx, endy, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long raylib_draw_circle(long long cx, long long cy, long long radius, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&cx);
    ep_gc_push_root(&cy);
    ep_gc_push_root(&radius);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawCircle");
    ret_val = ep_dlcall4(fn, cx, cy, radius, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long raylib_draw_circle_lines(long long cx, long long cy, long long radius, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&cx);
    ep_gc_push_root(&cy);
    ep_gc_push_root(&radius);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawCircleLines");
    ret_val = ep_dlcall4(fn, cx, cy, radius, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long raylib_draw_rectangle(long long x, long long y, long long width, long long height, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);
    ep_gc_push_root(&height);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawRectangle");
    ret_val = ep_dlcall5(fn, x, y, width, height, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long raylib_draw_rectangle_lines(long long x, long long y, long long width, long long height, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);
    ep_gc_push_root(&height);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawRectangleLines");
    ret_val = ep_dlcall5(fn, x, y, width, height, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long raylib_draw_triangle(long long x1, long long y1, long long x2, long long y2, long long x3, long long y3, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&x1);
    ep_gc_push_root(&y1);
    ep_gc_push_root(&x2);
    ep_gc_push_root(&y2);
    ep_gc_push_root(&x3);
    ep_gc_push_root(&y3);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawTriangle");
    ret_val = ep_dlcall7(fn, x1, y1, x2, y2, x3, y3, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long raylib_draw_poly(long long cx, long long cy, long long sides, long long radius, long long rotation, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&cx);
    ep_gc_push_root(&cy);
    ep_gc_push_root(&sides);
    ep_gc_push_root(&radius);
    ep_gc_push_root(&rotation);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawPoly");
    ret_val = ep_dlcall6(fn, cx, cy, sides, radius, rotation, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long raylib_draw_ring(long long cx, long long cy, long long inner_radius, long long outer_radius, long long start_angle, long long end_angle, long long segments, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&cx);
    ep_gc_push_root(&cy);
    ep_gc_push_root(&inner_radius);
    ep_gc_push_root(&outer_radius);
    ep_gc_push_root(&start_angle);
    ep_gc_push_root(&end_angle);
    ep_gc_push_root(&segments);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawRing");
    ret_val = ep_dlcall8(fn, cx, cy, inner_radius, outer_radius, start_angle, end_angle, segments, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    return ret_val;
}

long long raylib_draw_text(long long text, long long x, long long y, long long size, long long color) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&text);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&size);
    ep_gc_push_root(&color);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawText");
    ret_val = ep_dlcall5(fn, text, x, y, size, color);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long raylib_measure_text(long long text, long long size) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&text);
    ep_gc_push_root(&size);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"MeasureText");
    ret_val = ep_dlcall2(fn, text, size);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long raylib_draw_fps(long long x, long long y) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawFPS");
    ret_val = ep_dlcall2(fn, x, y);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long raylib_load_font(long long path) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"LoadFont");
    ret_val = ep_dlcall1(fn, path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_unload_font(long long font) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&font);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"UnloadFont");
    ret_val = ep_dlcall1(fn, font);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_load_texture(long long path) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"LoadTexture");
    ret_val = ep_dlcall1(fn, path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_unload_texture(long long tex) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&tex);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"UnloadTexture");
    ret_val = ep_dlcall1(fn, tex);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_draw_texture(long long tex, long long x, long long y, long long tint) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&tex);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawTexture");
    ret_val = ep_dlcall4(fn, tex, x, y, tint);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long raylib_draw_texture_ex(long long tex, long long x, long long y, long long rotation, long long scale, long long tint) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&tex);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&rotation);
    ep_gc_push_root(&scale);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"DrawTextureEx");
    ret_val = ep_dlcall6(fn, tex, x, y, rotation, scale, tint);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long raylib_load_image(long long path) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"LoadImage");
    ret_val = ep_dlcall1(fn, path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_unload_image(long long image) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&image);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"UnloadImage");
    ret_val = ep_dlcall1(fn, image);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_load_texture_from_image(long long image) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&image);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"LoadTextureFromImage");
    ret_val = ep_dlcall1(fn, image);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_key_pressed(long long key) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&key);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsKeyPressed");
    ret_val = ep_dlcall1(fn, key);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_key_down(long long key) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&key);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsKeyDown");
    ret_val = ep_dlcall1(fn, key);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_key_released(long long key) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&key);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsKeyReleased");
    ret_val = ep_dlcall1(fn, key);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_key_up(long long key) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&key);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsKeyUp");
    ret_val = ep_dlcall1(fn, key);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_get_key_pressed() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetKeyPressed");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_get_char_pressed() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetCharPressed");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_is_mouse_button_pressed(long long button) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&button);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsMouseButtonPressed");
    ret_val = ep_dlcall1(fn, button);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_mouse_button_down(long long button) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&button);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsMouseButtonDown");
    ret_val = ep_dlcall1(fn, button);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_mouse_button_released(long long button) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&button);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsMouseButtonReleased");
    ret_val = ep_dlcall1(fn, button);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_get_mouse_x() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetMouseX");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_get_mouse_y() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetMouseY");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_get_mouse_wheel_move() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetMouseWheelMove");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_set_mouse_position(long long x, long long y) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetMousePosition");
    ret_val = ep_dlcall2(fn, x, y);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long raylib_show_cursor() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"ShowCursor");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_hide_cursor() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"HideCursor");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_init_audio() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"InitAudioDevice");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_close_audio() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"CloseAudioDevice");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_is_audio_ready() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsAudioDeviceReady");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_set_master_volume(long long volume) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&volume);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetMasterVolume");
    ret_val = ep_dlcall1(fn, volume);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_load_sound(long long path) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"LoadSound");
    ret_val = ep_dlcall1(fn, path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_unload_sound(long long sound) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&sound);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"UnloadSound");
    ret_val = ep_dlcall1(fn, sound);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_play_sound(long long sound) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&sound);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"PlaySound");
    ret_val = ep_dlcall1(fn, sound);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_stop_sound(long long sound) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&sound);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"StopSound");
    ret_val = ep_dlcall1(fn, sound);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_pause_sound(long long sound) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&sound);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"PauseSound");
    ret_val = ep_dlcall1(fn, sound);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_resume_sound(long long sound) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&sound);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"ResumeSound");
    ret_val = ep_dlcall1(fn, sound);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_sound_playing(long long sound) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&sound);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsSoundPlaying");
    ret_val = ep_dlcall1(fn, sound);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_set_sound_volume(long long sound, long long volume) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&sound);
    ep_gc_push_root(&volume);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetSoundVolume");
    ret_val = ep_dlcall2(fn, sound, volume);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long raylib_load_music(long long path) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"LoadMusicStream");
    ret_val = ep_dlcall1(fn, path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_unload_music(long long music) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&music);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"UnloadMusicStream");
    ret_val = ep_dlcall1(fn, music);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_play_music(long long music) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&music);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"PlayMusicStream");
    ret_val = ep_dlcall1(fn, music);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_stop_music(long long music) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&music);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"StopMusicStream");
    ret_val = ep_dlcall1(fn, music);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_update_music(long long music) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&music);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"UpdateMusicStream");
    ret_val = ep_dlcall1(fn, music);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_music_playing(long long music) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&music);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsMusicStreamPlaying");
    ret_val = ep_dlcall1(fn, music);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_set_music_volume(long long music, long long volume) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&music);
    ep_gc_push_root(&volume);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetMusicVolume");
    ret_val = ep_dlcall2(fn, music, volume);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long raylib_check_collision_recs(long long x1, long long y1, long long w1, long long h1, long long x2, long long y2, long long w2, long long h2) {
    long long ret_val = 0;

    if ((((x1 < (x2 + w2) && (x1 + w1) > x2) && y1 < (y2 + h2)) && (y1 + h1) > y2)) {
    ret_val = 1;
    goto L_cleanup;
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long raylib_check_collision_circles(long long cx1, long long cy1, long long r1, long long cx2, long long cy2, long long r2) {
    long long dist_sq = 0;
    long long dx = 0;
    long long dy = 0;
    long long rad_sum = 0;
    long long ret_val = 0;

    dx = (cx1 - cx2);
    dy = (cy1 - cy2);
    dist_sq = ((dx * dx) + (dy * dy));
    rad_sum = (r1 + r2);
    if (dist_sq < (rad_sum * rad_sum)) {
    ret_val = 1;
    goto L_cleanup;
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long raylib_check_collision_point_rec(long long px, long long py, long long rx, long long ry, long long rw, long long rh) {
    long long ret_val = 0;

    if ((((px >= rx && px <= (rx + rw)) && py >= ry) && py <= (ry + rh))) {
    ret_val = 1;
    goto L_cleanup;
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long raylib_get_frame_time() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetFrameTime");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_get_time() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"GetTime");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long raylib_wait(long long seconds) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&seconds);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"WaitTime");
    ret_val = ep_dlcall1(fn, seconds);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_set_trace_log_level(long long level) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&level);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetTraceLogLevel");
    ret_val = ep_dlcall1(fn, level);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_take_screenshot(long long path) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"TakeScreenshot");
    ret_val = ep_dlcall1(fn, path);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_set_config_flags(long long flags) {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);
    ep_gc_push_root(&flags);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"SetConfigFlags");
    ret_val = ep_dlcall1(fn, flags);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long raylib_is_window_ready() {
    long long fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fn);

    ep_gc_maybe_collect();

    fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsWindowReady");
    ret_val = ep_dlcall0(fn);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long sql_open(long long filename) {
    long long db_addr = 0;
    long long db_ptr = 0;
    long long handle = 0;
    long long ok = 0;
    long long res = 0;
    long long ret_val = 0;

    ep_gc_push_root(&db_addr);
    ep_gc_push_root(&db_ptr);
    ep_gc_push_root(&filename);

    ep_gc_maybe_collect();

    db_ptr = create_list();
    ok = append_list(db_ptr, 0);
    db_addr = get_list_data_ptr(db_ptr);
    res = ep_sqlite3_open(filename, db_addr);
    if (res == 0) {
    handle = get_list(db_ptr, 0);
    ret_val = handle;
    goto L_cleanup;
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    free_list(db_ptr);
    db_ptr = 0;
    return ret_val;
}

long long sql_close(long long db) {
    long long ret_val = 0;

    ep_gc_push_root(&db);

    ep_gc_maybe_collect();

    ret_val = ep_sqlite3_close(db);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long sql_execute(long long db, long long sql) {
    long long ret_val = 0;

    ep_gc_push_root(&db);
    ep_gc_push_root(&sql);

    ep_gc_maybe_collect();

    ret_val = ep_sqlite3_exec(db, sql, 0, 0, 0);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long sql_query(long long db, long long sql) {
    long long cb = 0;
    long long res = 0;
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&cb);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&db);
    ep_gc_push_root(&sql);

    ep_gc_maybe_collect();

    rows = create_list();
    cb = sqlite_get_callback_ptr(0);
    res = ep_sqlite3_exec(db, sql, cb, rows, 0);
    ret_val = rows;
    rows = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long sql_bind_params(long long stmt, long long params) {
    long long i = 0;
    long long n = 0;
    long long ok = 0;
    long long v = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&v);
    ep_gc_push_root(&stmt);
    ep_gc_push_root(&params);

    ep_gc_maybe_collect();

    n = length_list(params);
    i = 0;
    while (i < n) {
    v = get_list(params, i);
    ok = ep_sqlite3_bind_text(stmt, (i + 1), str_to_ptr(ep_auto_to_string(v)));
    i = (i + 1);
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long sql_execute_params(long long db, long long sql, long long params) {
    long long done = 0;
    long long ok = 0;
    long long rc = 0;
    long long stmt = 0;
    long long ret_val = 0;

    ep_gc_push_root(&stmt);
    ep_gc_push_root(&db);
    ep_gc_push_root(&sql);
    ep_gc_push_root(&params);

    ep_gc_maybe_collect();

    stmt = ep_sqlite3_prepare_v2(db, str_to_ptr(sql));
    if (stmt == 0) {
    ret_val = -1;
    goto L_cleanup;
    }
    ok = sql_bind_params(stmt, params);
    rc = ep_sqlite3_step(stmt);
    done = ep_sqlite3_finalize(stmt);
    ret_val = rc;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long sql_query_params(long long db, long long sql, long long params) {
    long long c = 0;
    long long cell = 0;
    long long done = 0;
    long long ncol = 0;
    long long ok = 0;
    long long rc = 0;
    long long row = 0;
    long long rows = 0;
    long long stmt = 0;
    long long ret_val = 0;

    ep_gc_push_root(&c);
    ep_gc_push_root(&cell);
    ep_gc_push_root(&row);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&stmt);
    ep_gc_push_root(&db);
    ep_gc_push_root(&sql);
    ep_gc_push_root(&params);

    ep_gc_maybe_collect();

    rows = create_list();
    stmt = ep_sqlite3_prepare_v2(db, str_to_ptr(sql));
    if (stmt == 0) {
    ret_val = rows;
    rows = 0;
    goto L_cleanup;
    }
    ok = sql_bind_params(stmt, params);
    ncol = ep_sqlite3_column_count(stmt);
    rc = ep_sqlite3_step(stmt);
    while (rc == 100) {
    row = create_list();
    c = 0;
    while (c < ncol) {
    cell = ep_sqlite3_column_text(stmt, c);
    ok = append_list(row, cell);
    c = (c + 1);
    }
    ok = append_list(rows, row);
    rc = ep_sqlite3_step(stmt);
    }
    done = ep_sqlite3_finalize(stmt);
    ret_val = rows;
    rows = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long layout_boundary(long long text, long long position) {
    long long ret_val = 0;

    ep_gc_push_root(&text);
    ep_gc_push_root(&position);

    ep_gc_maybe_collect();

    while (((position > 0 && get_character((char*)text, position) >= 128) && get_character((char*)text, position) < 192)) {
    position = (position - 1);
    }
    ret_val = position;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long layout_prefix(long long text, long long width, long long size) {
    long long best = 0;
    long long boundary = 0;
    long long high = 0;
    long long low = 0;
    long long middle = 0;
    long long ret_val = 0;

    ep_gc_push_root(&best);
    ep_gc_push_root(&boundary);
    ep_gc_push_root(&middle);
    ep_gc_push_root(&text);
    ep_gc_push_root(&size);

    ep_gc_maybe_collect();

    low = 1;
    high = string_length((char*)text);
    best = 0;
    while (low <= high) {
    middle = ((low + high) / 2);
    boundary = layout_boundary(text, middle);
    if (font_measure((long long)substring((char*)text, 0, boundary), size) <= width) {
    best = boundary;
    low = (middle + 1);
    } else {
    high = (middle - 1);
    }
    }
    if ((best == 0 && string_length((char*)text) > 0)) {
    best = 1;
    while (((best < string_length((char*)text) && get_character((char*)text, best) >= 128) && get_character((char*)text, best) < 192)) {
    best = (best + 1);
    }
    }
    ret_val = best;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long layout_ranges(long long text, long long width, long long size) {
    long long count = 0;
    long long finish = 0;
    long long rows = 0;
    long long space = 0;
    long long start = 0;
    long long stop = 0;
    long long total = 0;
    long long ret_val = 0;

    ep_gc_push_root(&finish);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&space);
    ep_gc_push_root(&start);
    ep_gc_push_root(&stop);
    ep_gc_push_root(&total);
    ep_gc_push_root(&text);
    ep_gc_push_root(&width);
    ep_gc_push_root(&size);

    ep_gc_maybe_collect();

    rows = create_list();
    start = 0;
    total = string_length((char*)text);
    while (start < total) {
    finish = start;
    while ((finish < total && get_character((char*)text, finish) != 10)) {
    finish = (finish + 1);
    }
    if (finish == start) {
    append_list(rows, ({ long long _lit_list = create_list(); append_list(_lit_list, start); append_list(_lit_list, start); _lit_list; }));
    start = (start + 1);
    } else {
    count = layout_prefix((long long)substring((char*)text, start, (finish - start)), width, size);
    stop = (start + count);
    if (stop < finish) {
    space = stop;
    while ((space > start && get_character((char*)text, (space - 1)) != 32)) {
    space = (space - 1);
    }
    if (space > start) {
    stop = space;
    }
    }
    append_list(rows, ({ long long _lit_list = create_list(); append_list(_lit_list, start); append_list(_lit_list, stop); _lit_list; }));
    start = stop;
    if ((start == finish && start < total)) {
    start = (start + 1);
    }
    }
    }
    if ((total == 0 || get_character((char*)text, (total - 1)) == 10)) {
    append_list(rows, ({ long long _lit_list = create_list(); append_list(_lit_list, total); append_list(_lit_list, total); _lit_list; }));
    }
    ret_val = rows;
    rows = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    return ret_val;
}

long long layout_lines(long long text, long long width, long long size) {
    long long i = 0;
    long long lines = 0;
    long long row = 0;
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&lines);
    ep_gc_push_root(&row);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&text);
    ep_gc_push_root(&width);
    ep_gc_push_root(&size);

    ep_gc_maybe_collect();

    rows = layout_ranges(text, width, size);
    lines = create_list();
    i = 0;
    while (i < length_list(rows)) {
    row = get_list(rows, i);
    append_list(lines, (long long)substring((char*)text, get_list(row, 0), (get_list(row, 1) - get_list(row, 0))));
    i = (i + 1);
    }
    ret_val = lines;
    lines = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long chat_backspace(long long value) {
    long long end = 0;
    long long ret_val = 0;

    ep_gc_push_root(&end);
    ep_gc_push_root(&value);

    ep_gc_maybe_collect();

    end = string_length((char*)value);
    if (end == 0) {
    ret_val = value;
    goto L_cleanup;
    }
    end = (end - 1);
    while (((end > 0 && get_character((char*)value, end) >= 128) && get_character((char*)value, end) < 192)) {
    end = (end - 1);
    }
    ret_val = (long long)substring((char*)value, 0, end);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long chat_character(long long code) {
    long long count = 0;
    long long data = 0;
    long long value = 0;
    long long ret_val = 0;

    ep_gc_push_root(&count);
    ep_gc_push_root(&data);
    ep_gc_push_root(&value);
    ep_gc_push_root(&code);

    ep_gc_maybe_collect();

    data = alloc_bytes(5);
    count = 1;
    if (code < 128) {
    poke_byte(data, 0, code);
    } else {
    if (code < 2048) {
    poke_byte(data, 0, (192 + (code / 64)));
    poke_byte(data, 1, (128 + (code % 64)));
    count = 2;
    } else {
    if (code < 65536) {
    poke_byte(data, 0, (224 + (code / 4096)));
    poke_byte(data, 1, (128 + ((code / 64) % 64)));
    poke_byte(data, 2, (128 + (code % 64)));
    count = 3;
    } else {
    poke_byte(data, 0, (240 + (code / 262144)));
    poke_byte(data, 1, (128 + ((code / 4096) % 64)));
    poke_byte(data, 2, (128 + ((code / 64) % 64)));
    poke_byte(data, 3, (128 + (code % 64)));
    count = 4;
    }
    }
    }
    poke_byte(data, count, 0);
    value = ptr_to_str(data);
    free_bytes(data);
    ret_val = value;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long chat_sessions(long long db, long long project) {
    long long params = 0;
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&params);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&db);
    ep_gc_push_root(&project);

    ep_gc_maybe_collect();

    params = create_list();
    append_list(params, project);
    rows = sql_query_params(db, (long long)"SELECT s.memory,COALESCE((SELECT CASE WHEN u.source='scheduled-event' THEN 'Scheduled task' ELSE substr(u.body,1,24) END FROM session_turns st JOIN turns t ON t.id=st.turn_id JOIN memories u ON u.id=t.user_memory WHERE st.session=s.memory ORDER BY t.id LIMIT 1),m.body),COALESCE(s.closed,'') FROM sessions s JOIN memories m ON m.id=s.memory WHERE s.project=? ORDER BY s.memory DESC LIMIT 12", params);
    ret_val = rows;
    rows = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long chat_turns(long long db, long long session) {
    long long has_progress = 0;
    long long i = 0;
    long long input_source = 0;
    long long output = 0;
    long long params = 0;
    long long preview = 0;
    long long prior = 0;
    long long reasoning = 0;
    long long row = 0;
    long long rows = 0;
    long long snapshot = 0;
    long long sources = 0;
    long long ret_val = 0;

    ep_gc_push_root(&has_progress);
    ep_gc_push_root(&i);
    ep_gc_push_root(&input_source);
    ep_gc_push_root(&output);
    ep_gc_push_root(&params);
    ep_gc_push_root(&preview);
    ep_gc_push_root(&prior);
    ep_gc_push_root(&reasoning);
    ep_gc_push_root(&row);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&snapshot);
    ep_gc_push_root(&sources);
    ep_gc_push_root(&db);
    ep_gc_push_root(&session);

    ep_gc_maybe_collect();

    params = create_list();
    append_list(params, session);
    rows = sql_query_params(db, (long long)"SELECT t.id,CASE WHEN u.source='scheduled-event' THEN 'Scheduled task: '||coalesce((SELECT json_extract(m.body,'$.objective') FROM task_schedules s JOIN tasks k ON k.memory=s.task JOIN memories m ON m.id=k.current_memory WHERE s.turn_id=t.id),'Saved task') ELSE u.body END,COALESCE(a.body,''),t.status,COALESCE((SELECT group_concat(json_extract(g.response,'$.reasoning'),char(10)||char(10)) FROM generation_rounds g WHERE g.turn_id=t.id ORDER BY g.round),''),COALESCE((SELECT sum(json_extract(g.response,'$.completion_tokens')) FROM generation_rounds g WHERE g.turn_id=t.id),0),COALESCE((SELECT group_concat(r.name||' · '||r.status,', ') FROM tool_runs r WHERE r.turn_id=t.id),''),u.source FROM turns t JOIN session_turns st ON st.turn_id=t.id JOIN memories u ON u.id=t.user_memory LEFT JOIN memories a ON a.id=t.reply_memory WHERE st.session=? ORDER BY t.id", params);
    has_progress = result_cache_scalar(db, (long long)"SELECT count(*) FROM sqlite_master WHERE type='table' AND name='model_progress'", ({ long long _lit_list = create_list(); _lit_list; }));
    i = 0;
    while (i < length_list(rows)) {
    row = get_list(rows, i);
    input_source = get_list(row, 7);
    set_list(row, 7, (long long)"0");
    append_list(row, input_source);
    sources = chat_sources(db, get_list(row, 0));
    append_list(row, sources);
    set_list(row, 2, source_reply(db, get_list(row, 2), sources));
    if ((ep_str_equals(has_progress, (long long)"1") && ep_str_equals(get_list(row, 3), (long long)"pending"))) {
    snapshot = result_cache_scalar(db, (long long)"SELECT p.response FROM model_progress p JOIN turns t ON t.id=p.turn_id WHERE p.turn_id=? AND t.status='pending' AND p.epoch=(SELECT value FROM metadata WHERE key='cache_epoch')", ({ long long _lit_list = create_list(); append_list(_lit_list, get_list(row, 0)); _lit_list; }));
    if ((!ep_str_equals(snapshot, (long long)""))) {
    reasoning = result_cache_scalar(db, (long long)"SELECT COALESCE(json_extract(?,'$.reasoning'),'')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)snapshot); _lit_list; }));
    if ((!ep_str_equals(reasoning, (long long)""))) {
    prior = get_list(row, 4);
    if ((!ep_str_equals(prior, (long long)""))) {
    reasoning = concat(prior, concat((long long)"\n\n", reasoning));
    }
    set_list(row, 4, reasoning);
    }
    output = result_cache_scalar(db, (long long)"SELECT COALESCE(json_extract(?,'$.text'),'')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)snapshot); _lit_list; }));
    preview = progress_answer(db, output);
    if ((!ep_str_equals(preview, (long long)""))) {
    set_list(row, 2, concat((long long)"Draft while generating:\n", preview));
    }
    set_list(row, 7, (long long)"1");
    }
    }
    i = (i + 1);
    }
    ret_val = rows;
    rows = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(14);
    return ret_val;
}

long long chat_wheel(long long raylib) {
    long long amount = 0;
    long long bits = 0;
    long long exponent = 0;
    long long sign = 0;
    long long ret_val = 0;

    ep_gc_push_root(&raylib);

    ep_gc_maybe_collect();

    if (CHAT_WHEEL_CIF == 0) {
    CHAT_WHEEL_CIF = native_cif(ep_dlsym(FONT_FFI, (long long)"ffi_type_float"), ({ long long _lit_list = create_list(); _lit_list; }));
    CHAT_WHEEL_RESULT = alloc_bytes(8);
    }
    ep_dlcall4(FONT_CALL, CHAT_WHEEL_CIF, ep_dlsym(raylib, (long long)"GetMouseWheelMove"), CHAT_WHEEL_RESULT, 0);
    bits = process_integer(CHAT_WHEEL_RESULT, 4);
    sign = 1;
    if (bits >= 2147483648) {
    sign = -1;
    bits = (bits - 2147483648);
    }
    exponent = (((bits / 8388608) - 127) - 23);
    if (bits == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    amount = (((bits % 8388608) + 8388608) * 40);
    while (exponent < 0) {
    amount = (amount / 2);
    exponent = (exponent + 1);
    }
    while (exponent > 0) {
    amount = (amount + amount);
    exponent = (exponent - 1);
    }
    ret_val = (amount * sign);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long chat_sources(long long db, long long turn_id) {
    long long params = 0;
    long long ret_val = 0;

    ep_gc_push_root(&params);
    ep_gc_push_root(&db);
    ep_gc_push_root(&turn_id);

    ep_gc_maybe_collect();

    params = ({ long long _lit_list = create_list(); append_list(_lit_list, turn_id); _lit_list; });
    ret_val = result_cache_scalar(db, (long long)"WITH entries AS (SELECT r.id,j.key,json_extract(j.value,'$.url') url,coalesce(nullif(json_extract(j.value,'$.title'),''),nullif(json_extract(j.value,'$.word'),''),nullif(json_extract(m.body,'$.title'),''),'') title,coalesce(json_extract(m.body,'$.source_date'),'') snapshot,r.name tool FROM tool_runs r JOIN memories m ON m.id=r.observation JOIN json_each(CASE WHEN json_valid(m.body) THEN m.body ELSE '{}' END,'$.entries') j WHERE r.turn_id=? AND r.status='completed' AND json_valid(j.value) AND json_type(j.value,'$.url')='text'), unique_sources AS (SELECT url,max(title) title,max(snapshot) snapshot,min(id) receipt FROM entries GROUP BY url ORDER BY min(id),url) SELECT coalesce(json_group_array(json_object('url',url,'title',title,'snapshot',snapshot)),'[]') FROM unique_sources", params);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long source_rows(long long db, long long sources) {
    long long ret_val = 0;

    ep_gc_push_root(&db);
    ep_gc_push_root(&sources);

    ep_gc_maybe_collect();

    ret_val = sql_query_params(db, (long long)"SELECT json_extract(value,'$.url'),json_extract(value,'$.title'),json_extract(value,'$.snapshot') FROM json_each(?)", ({ long long _lit_list = create_list(); append_list(_lit_list, sources); _lit_list; }));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long source_reply(long long db, long long answer, long long sources) {
    long long citation = 0;
    long long clean = 0;
    long long i = 0;
    long long line = 0;
    long long row = 0;
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&citation);
    ep_gc_push_root(&clean);
    ep_gc_push_root(&i);
    ep_gc_push_root(&line);
    ep_gc_push_root(&row);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&db);
    ep_gc_push_root(&sources);

    ep_gc_maybe_collect();

    rows = sql_query_params(db, (long long)"SELECT json_extract(value,'$.url'),json_extract(value,'$.title'),json_extract(value,'$.snapshot') FROM json_each(?)", ({ long long _lit_list = create_list(); append_list(_lit_list, sources); _lit_list; }));
    clean = answer;
    i = 0;
    while (i < length_list(rows)) {
    row = get_list(rows, i);
    citation = get_list(row, 0);
    if ((!ep_str_equals(get_list(row, 2), (long long)""))) {
    citation = concat(citation, concat((long long)" (local snapshot ", concat(get_list(row, 2), (long long)")")));
    }
    line = concat((long long)"\nConsulted source: ", citation);
    clean = string_replace(clean, concat(line, (long long)"\n"), (long long)"\n");
    if (ends_with(clean, line)) {
    clean = (long long)substring((char*)clean, 0, (string_length((char*)clean) - string_length((char*)line)));
    }
    i = (i + 1);
    }
    ret_val = clean;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    free_list(rows);
    rows = 0;
    return ret_val;
}

long long source_target(long long url) {
    long long i = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&url);

    ep_gc_maybe_collect();

    if (string_length((char*)url) > 8192) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    if (((starts_with(url, (long long)"https://") == 0 && starts_with(url, (long long)"http://") == 0) && starts_with(url, (long long)"file:///") == 0)) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    i = 0;
    while (i < string_length((char*)url)) {
    if ((get_character((char*)url, i) < 32 || get_character((char*)url, i) == 127)) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    i = (i + 1);
    }
    ret_val = url;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long source_host(long long url) {
    long long pieces = 0;
    long long ret_val = 0;

    ep_gc_push_root(&pieces);
    ep_gc_push_root(&url);

    ep_gc_maybe_collect();

    if (starts_with(url, (long long)"file:///")) {
    ret_val = (long long)"Local file";
    goto L_cleanup;
    }
    pieces = string_split(url, (long long)"/");
    if (length_list(pieces) > 2) {
    ret_val = get_list(pieces, 2);
    goto L_cleanup;
    }
    ret_val = (long long)"Source";
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    free_list(pieces);
    pieces = 0;
    return ret_val;
}

long long source_title(long long url, long long title) {
    long long name = 0;
    long long pieces = 0;
    long long ret_val = 0;

    ep_gc_push_root(&name);
    ep_gc_push_root(&pieces);
    ep_gc_push_root(&url);
    ep_gc_push_root(&title);

    ep_gc_maybe_collect();

    if ((!ep_str_equals(string_trim(title), (long long)""))) {
    ret_val = string_replace(string_replace(title, (long long)"\n", (long long)" "), (long long)"\r", (long long)" ");
    goto L_cleanup;
    }
    pieces = string_split(url, (long long)"/");
    name = get_list(pieces, (length_list(pieces) - 1));
    name = get_list(string_split(name, (long long)"#"), 0);
    name = get_list(string_split(name, (long long)"?"), 0);
    name = string_replace(string_replace(string_replace(name, (long long)"%20", (long long)" "), (long long)"%28", (long long)"("), (long long)"%29", (long long)")");
    name = string_replace(name, (long long)"_", (long long)" ");
    if (ep_str_equals(name, (long long)"")) {
    ret_val = source_host(url);
    goto L_cleanup;
    }
    ret_val = name;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    free_list(pieces);
    pieces = 0;
    return ret_val;
}

long long source_open(long long url) {
    long long path = 0;
    long long sdl = 0;
    long long target = 0;
    long long ret_val = 0;

    ep_gc_push_root(&path);
    ep_gc_push_root(&sdl);
    ep_gc_push_root(&target);
    ep_gc_push_root(&url);

    ep_gc_maybe_collect();

    target = source_target(url);
    if (ep_str_equals(target, (long long)"")) {
    ret_val = 0;
    goto L_cleanup;
    }
    if (native_android()) {
    if (starts_with(target, (long long)"file:///")) {
    ret_val = 0;
    goto L_cleanup;
    }
    sdl = ep_dlopen((long long)"libSDL3.so");
    if ((sdl != 0 && ep_dlcall1(ep_dlsym(sdl, (long long)"SDL_OpenURL"), target))) {
    ret_val = -1;
    goto L_cleanup;
    }
    ret_val = 0;
    goto L_cleanup;
    }
    if (starts_with(target, (long long)"file:///")) {
    path = get_list(string_split(target, (long long)"#"), 0);
    if (((((ends_with(path, (long long)".pdf") || ends_with(path, (long long)".docx")) || ends_with(path, (long long)".png")) || ends_with(path, (long long)".jpg")) || ends_with(path, (long long)".jpeg"))) {
    ret_val = process_spawn_streams((long long)"/usr/bin/open", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)target); _lit_list; }), -1, -1, 0, (long long)"", 0);
    goto L_cleanup;
    }
    ret_val = process_spawn_streams((long long)"/usr/bin/open", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"-a"); append_list(_lit_list, (long long)(long long)"TextEdit"); append_list(_lit_list, (long long)target); _lit_list; }), -1, -1, 0, (long long)"", 0);
    goto L_cleanup;
    }
    ret_val = process_spawn_streams((long long)"/usr/bin/open", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)target); _lit_list; }), -1, -1, 0, (long long)"", 0);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long result_cache_error(long long text) {
    long long result = 0;
    long long values = 0;
    long long ret_val = 0;

    ep_gc_push_root(&result);
    ep_gc_push_root(&values);
    ep_gc_push_root(&text);

    ep_gc_maybe_collect();

    values = ({ long long _lit_list = create_list(); append_list(_lit_list, create_json_string((long long)"error")); append_list(_lit_list, create_json_string(text)); _lit_list; });
    result = json_stringify(create_json_object(({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"status"); append_list(_lit_list, (long long)(long long)"text"); _lit_list; }), values));
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    free_list(values);
    values = 0;
    return ret_val;
}

long long result_cache_scalar(long long db, long long statement, long long params) {
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&rows);
    ep_gc_push_root(&db);
    ep_gc_push_root(&statement);
    ep_gc_push_root(&params);

    ep_gc_maybe_collect();

    rows = sql_query_params(db, statement, params);
    if (length_list(rows) != 1) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    ret_val = get_list(get_list(rows, 0), 0);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    free_list(rows);
    rows = 0;
    return ret_val;
}

long long result_cache_key(long long db, long long namespace, long long request) {
    long long material = 0;
    long long ret_val = 0;

    ep_gc_push_root(&material);
    ep_gc_push_root(&db);
    ep_gc_push_root(&namespace);
    ep_gc_push_root(&request);

    ep_gc_maybe_collect();

    material = result_cache_scalar(db, (long long)"SELECT json_array(?,?)", ({ long long _lit_list = create_list(); append_list(_lit_list, namespace); append_list(_lit_list, request); _lit_list; }));
    ret_val = (long long)ep_sha256((char*)material);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long result_cache_epoch(long long db, long long epoch) {
    long long current = 0;
    long long ret_val = 0;

    ep_gc_push_root(&current);
    ep_gc_push_root(&db);
    ep_gc_push_root(&epoch);

    ep_gc_maybe_collect();

    if (ep_str_equals(epoch, (long long)"")) {
    ret_val = 0;
    goto L_cleanup;
    }
    current = result_cache_scalar(db, (long long)"SELECT value FROM metadata WHERE key='cache_epoch'", ({ long long _lit_list = create_list(); _lit_list; }));
    ret_val = string_equals(current, epoch);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long result_cache_get(long long db, long long namespace, long long request, long long epoch) {
    long long key = 0;
    long long payload = 0;
    long long rc = 0;
    long long result = 0;
    long long row = 0;
    long long rows = 0;
    long long valid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&key);
    ep_gc_push_root(&payload);
    ep_gc_push_root(&row);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&valid);
    ep_gc_push_root(&db);
    ep_gc_push_root(&namespace);
    ep_gc_push_root(&request);
    ep_gc_push_root(&epoch);

    ep_gc_maybe_collect();

    if (ep_sqlite3_exec(db, (long long)"BEGIN IMMEDIATE", 0, 0, 0) != 0) {
    ret_val = result_cache_error((long long)"Cannot acquire inference cache transaction");
    goto L_cleanup;
    }
    if (result_cache_epoch(db, epoch) == 0) {
    ep_sqlite3_exec(db, (long long)"ROLLBACK", 0, 0, 0);
    ret_val = result_cache_error((long long)"Memory changed through forgetting; rebuild the request");
    goto L_cleanup;
    }
    key = result_cache_key(db, namespace, request);
    rows = sql_query_params(db, (long long)"SELECT payload,digest FROM response_cache WHERE key=? AND epoch=?", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)key); append_list(_lit_list, epoch); _lit_list; }));
    result = (long long)"";
    rc = 101;
    if (length_list(rows) == 1) {
    row = get_list(rows, 0);
    payload = get_list(row, 0);
    valid = result_cache_scalar(db, (long long)"SELECT CASE WHEN json_valid(?) THEN json_extract(?,'$.status')='ok' AND json_type(?,'$.text')='text' ELSE 0 END", ({ long long _lit_list = create_list(); append_list(_lit_list, payload); append_list(_lit_list, payload); append_list(_lit_list, payload); _lit_list; }));
    if ((string_equals(sha256(payload), get_list(row, 1)) && ep_str_equals(valid, (long long)"1"))) {
    result = payload;
    rc = sql_execute_params(db, (long long)"UPDATE response_cache SET used=(SELECT coalesce(max(used),0)+1 FROM response_cache) WHERE key=?", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)key); _lit_list; }));
    } else {
    rc = sql_execute_params(db, (long long)"DELETE FROM response_cache WHERE key=?", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)key); _lit_list; }));
    }
    }
    if (rc != 101) {
    ep_sqlite3_exec(db, (long long)"ROLLBACK", 0, 0, 0);
    ret_val = result_cache_error((long long)"Cannot update inference cache");
    goto L_cleanup;
    }
    if (ep_sqlite3_exec(db, (long long)"COMMIT", 0, 0, 0) != 0) {
    ep_sqlite3_exec(db, (long long)"ROLLBACK", 0, 0, 0);
    ret_val = result_cache_error((long long)"Cannot commit inference cache read");
    goto L_cleanup;
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    free_list(rows);
    rows = 0;
    return ret_val;
}

long long result_cache_put(long long db, long long namespace, long long request, long long epoch, long long payload) {
    long long key = 0;
    long long over = 0;
    long long rc = 0;
    long long valid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&key);
    ep_gc_push_root(&over);
    ep_gc_push_root(&valid);
    ep_gc_push_root(&db);
    ep_gc_push_root(&namespace);
    ep_gc_push_root(&request);
    ep_gc_push_root(&epoch);
    ep_gc_push_root(&payload);

    ep_gc_maybe_collect();

    if (ep_sqlite3_exec(db, (long long)"BEGIN IMMEDIATE", 0, 0, 0) != 0) {
    ret_val = result_cache_error((long long)"Cannot acquire inference cache transaction");
    goto L_cleanup;
    }
    if (result_cache_epoch(db, epoch) == 0) {
    ep_sqlite3_exec(db, (long long)"ROLLBACK", 0, 0, 0);
    ret_val = result_cache_error((long long)"Memory forgotten during inference; result discarded");
    goto L_cleanup;
    }
    valid = result_cache_scalar(db, (long long)"SELECT CASE WHEN json_valid(?) THEN json_extract(?,'$.status')='ok' AND json_type(?,'$.text')='text' ELSE 0 END", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)payload); append_list(_lit_list, (long long)payload); append_list(_lit_list, (long long)payload); _lit_list; }));
    if (((!ep_str_equals(valid, (long long)"1")) || string_length((char*)payload) > 1048576)) {
    ep_sqlite3_exec(db, (long long)"ROLLBACK", 0, 0, 0);
    ret_val = result_cache_error((long long)"Incomplete or oversized result cannot enter inference cache");
    goto L_cleanup;
    }
    key = result_cache_key(db, namespace, request);
    rc = sql_execute_params(db, (long long)"INSERT OR REPLACE INTO response_cache(key,epoch,payload,digest,bytes,used) VALUES(?,?,?,?,?,(SELECT coalesce(max(used),0)+1 FROM response_cache))", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)key); append_list(_lit_list, epoch); append_list(_lit_list, (long long)payload); append_list(_lit_list, (long long)sha256(payload)); append_list(_lit_list, (long long)int_to_string(string_length((char*)payload))); _lit_list; }));
    if (rc != 101) {
    ep_sqlite3_exec(db, (long long)"ROLLBACK", 0, 0, 0);
    ret_val = result_cache_error((long long)"Cannot persist inference result");
    goto L_cleanup;
    }
    over = result_cache_scalar(db, (long long)"SELECT count(*)>1024 OR coalesce(sum(bytes),0)>67108864 FROM response_cache", ({ long long _lit_list = create_list(); _lit_list; }));
    while (ep_str_equals(over, (long long)"1")) {
    rc = sql_execute_params(db, (long long)"DELETE FROM response_cache WHERE key=(SELECT key FROM response_cache ORDER BY used,key LIMIT 1)", ({ long long _lit_list = create_list(); _lit_list; }));
    if (rc != 101) {
    ep_sqlite3_exec(db, (long long)"ROLLBACK", 0, 0, 0);
    ret_val = result_cache_error((long long)"Cannot enforce inference cache limit");
    goto L_cleanup;
    }
    over = result_cache_scalar(db, (long long)"SELECT count(*)>1024 OR coalesce(sum(bytes),0)>67108864 FROM response_cache", ({ long long _lit_list = create_list(); _lit_list; }));
    }
    if (ep_sqlite3_exec(db, (long long)"COMMIT", 0, 0, 0) != 0) {
    ep_sqlite3_exec(db, (long long)"ROLLBACK", 0, 0, 0);
    ret_val = result_cache_error((long long)"Cannot commit inference result");
    goto L_cleanup;
    }
    ret_val = payload;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long md5(long long s) {
    long long ret_val = 0;

    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    ret_val = (long long)ep_md5((char*)s);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long sha256(long long s) {
    long long ret_val = 0;

    ep_gc_push_root(&s);

    ep_gc_maybe_collect();

    ret_val = (long long)ep_sha256((char*)s);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long progress_scope(long long turn, long long round, long long epoch) {
    long long ret_val = 0;

    PROGRESS_TURN = turn;
    PROGRESS_ROUND = round;
    PROGRESS_EPOCH = epoch;
    PROGRESS_LAST = 0;
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long progress_initialize(long long db) {
    long long ret_val = 0;

    ep_gc_push_root(&db);

    ep_gc_maybe_collect();

    ret_val = ep_sqlite3_exec(db, (long long)"CREATE TABLE IF NOT EXISTS model_progress(turn_id INTEGER PRIMARY KEY REFERENCES turns(id) ON DELETE CASCADE,round INTEGER NOT NULL,epoch TEXT NOT NULL,response TEXT NOT NULL,updates INTEGER NOT NULL DEFAULT 1); CREATE TRIGGER IF NOT EXISTS progress_turn_finished AFTER UPDATE OF status ON turns WHEN new.status!='pending' BEGIN DELETE FROM model_progress WHERE turn_id=new.id; END;", 0, 0, 0);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long progress_publish(long long db, long long snapshot, long long now, long long force) {
    long long params = 0;
    long long rc = 0;
    long long ret_val = 0;

    ep_gc_push_root(&params);
    ep_gc_push_root(&db);
    ep_gc_push_root(&snapshot);

    ep_gc_maybe_collect();

    if (ep_str_equals(PROGRESS_TURN, (long long)"")) {
    ret_val = 0;
    goto L_cleanup;
    }
    if ((force == 0 && (now - PROGRESS_LAST) < 150)) {
    ret_val = 0;
    goto L_cleanup;
    }
    PROGRESS_LAST = now;
    params = ({ long long _lit_list = create_list(); append_list(_lit_list, PROGRESS_TURN); append_list(_lit_list, PROGRESS_ROUND); append_list(_lit_list, PROGRESS_EPOCH); append_list(_lit_list, snapshot); append_list(_lit_list, PROGRESS_TURN); append_list(_lit_list, PROGRESS_EPOCH); _lit_list; });
    rc = sql_execute_params(db, (long long)"INSERT INTO model_progress(turn_id,round,epoch,response) SELECT ?,CAST(? AS INTEGER),?,? WHERE EXISTS(SELECT 1 FROM turns WHERE id=? AND status='pending') AND (SELECT value FROM metadata WHERE key='cache_epoch')=? ON CONFLICT(turn_id) DO UPDATE SET round=excluded.round,epoch=excluded.epoch,response=excluded.response,updates=model_progress.updates+1", params);
    ret_val = rc == 101;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long progress_answer(long long db, long long action) {
    long long byte = 0;
    long long complete = 0;
    long long decoded = 0;
    long long depth = 0;
    long long encoded = 0;
    long long escaped = 0;
    long long expecting_key = 0;
    long long key = 0;
    long long kind = 0;
    long long pos = 0;
    long long safe_end = 0;
    long long size = 0;
    long long start = 0;
    long long ret_val = 0;

    ep_gc_push_root(&decoded);
    ep_gc_push_root(&encoded);
    ep_gc_push_root(&key);
    ep_gc_push_root(&kind);
    ep_gc_push_root(&pos);
    ep_gc_push_root(&safe_end);
    ep_gc_push_root(&start);
    ep_gc_push_root(&db);
    ep_gc_push_root(&action);

    ep_gc_maybe_collect();

    pos = 0;
    size = string_length((char*)action);
    depth = 0;
    key = (long long)"";
    kind = (long long)"";
    expecting_key = 0;
    while (pos < size) {
    byte = get_character((char*)action, pos);
    if (byte == 123) {
    depth = (depth + 1);
    if (depth == 1) {
    expecting_key = 1;
    }
    } else {
    if (byte == 125) {
    depth = (depth - 1);
    } else {
    if ((byte == 44 && depth == 1)) {
    expecting_key = 1;
    } else {
    if (byte == 34) {
    start = pos;
    pos = (pos + 1);
    escaped = 0;
    while (pos < size) {
    byte = get_character((char*)action, pos);
    if ((escaped == 0 && byte == 34)) {
    break;
    }
    if ((escaped == 0 && byte == 92)) {
    escaped = 1;
    } else {
    escaped = 0;
    }
    pos = (pos + 1);
    }
    complete = pos < size;
    encoded = (long long)substring((char*)action, start, (pos - start));
    encoded = concat(encoded, (long long)"\"");
    if (complete == 0) {
    safe_end = pos;
    while (((!ep_str_equals(result_cache_scalar(db, (long long)"SELECT json_valid(?)", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)encoded); _lit_list; })), (long long)"1")) && safe_end > (start + 1))) {
    safe_end = (safe_end - 1);
    encoded = concat((long long)substring((char*)action, start, (safe_end - start)), (long long)"\"");
    }
    }
    if (ep_str_equals(result_cache_scalar(db, (long long)"SELECT json_valid(?)", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)encoded); _lit_list; })), (long long)"1")) {
    decoded = result_cache_scalar(db, (long long)"SELECT json_extract(?,'$')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)encoded); _lit_list; }));
    if (depth == 1) {
    if (expecting_key == 1) {
    key = decoded;
    expecting_key = 0;
    } else {
    if ((ep_str_equals(key, (long long)"type") && complete)) {
    kind = decoded;
    }
    if ((ep_str_equals(key, (long long)"text") && ep_str_equals(kind, (long long)"answer"))) {
    ret_val = decoded;
    goto L_cleanup;
    }
    }
    }
    }
    if (complete == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    }
    }
    }
    }
    pos = (pos + 1);
    }
    ret_val = (long long)"";
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    return ret_val;
}

long long ui_sources(long long db, long long turn_id, long long sources, long long x, long long y, long long width) {
    long long arrow = 0;
    long long card_height = 0;
    long long detail = 0;
    long long fill = 0;
    long long hovered = 0;
    long long i = 0;
    long long inside = 0;
    long long line_i = 0;
    long long opened = 0;
    long long outcome = 0;
    long long row = 0;
    long long rows = 0;
    long long title = 0;
    long long title_lines = 0;
    long long url = 0;
    long long ret_val = 0;

    ep_gc_push_root(&arrow);
    ep_gc_push_root(&card_height);
    ep_gc_push_root(&detail);
    ep_gc_push_root(&fill);
    ep_gc_push_root(&i);
    ep_gc_push_root(&line_i);
    ep_gc_push_root(&row);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&title);
    ep_gc_push_root(&title_lines);
    ep_gc_push_root(&url);
    ep_gc_push_root(&db);
    ep_gc_push_root(&turn_id);
    ep_gc_push_root(&sources);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);

    ep_gc_maybe_collect();

    if (SOURCE_CHILD > 0) {
    outcome = process_poll(SOURCE_CHILD);
    if (outcome != -1) {
    SOURCE_CHILD = 0;
    if (outcome != 0) {
    SOURCE_NOTICE = (long long)"Could not open source. Copy its link and open it manually.";
    }
    }
    }
    rows = sql_query_params(db, (long long)"SELECT json_extract(value,'$.url'),json_extract(value,'$.title'),json_extract(value,'$.snapshot') FROM json_each(?)", ({ long long _lit_list = create_list(); append_list(_lit_list, sources); _lit_list; }));
    if (length_list(rows) == 0) {
    ret_val = y;
    goto L_cleanup;
    }
    y = (y + 18);
    opened = string_equals(SOURCES_OPEN, turn_id);
    hovered = ((((((raylib_get_mouse_x() / UI_SCALE) >= x && (raylib_get_mouse_x() / UI_SCALE) < (x + width)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= y) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < (y + 36)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= SELECT_TOP) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < SELECT_BOTTOM);
    fill = 4280754716;
    if (hovered) {
    fill = 4281281315;
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetMouseCursor"), 4);
    }
    ui_frame(x, y, width, 36, fill, ui_color(45, 53, 61));
    arrow = (long long)">";
    if (opened) {
    arrow = (long long)"v";
    }
    font_draw(concat(arrow, concat((long long)"  Sources / ", int_to_string(length_list(rows)))), (x + 14), (y + 11), 13, ui_color(189, 229, 201));
    if ((hovered && (UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0)))) {
    SOURCES_OPEN = (long long)"";
    if (opened == 0) {
    SOURCES_OPEN = turn_id;
    }
    opened = string_equals(SOURCES_OPEN, turn_id);
    }
    y = (y + 44);
    if (opened == 0) {
    ret_val = y;
    goto L_cleanup;
    }
    font_draw((long long)"Consulted references / click a title to open", (x + 14), y, 11, ui_color(148, 159, 169));
    y = (y + 26);
    i = 0;
    while (i < length_list(rows)) {
    row = get_list(rows, i);
    url = get_list(row, 0);
    title = source_title(url, get_list(row, 1));
    detail = source_host(url);
    if ((!ep_str_equals(get_list(row, 2), (long long)""))) {
    detail = concat(detail, concat((long long)" / snapshot ", get_list(row, 2)));
    }
    title_lines = layout_lines(title, (width - 88), 15);
    card_height = ((length_list(title_lines) * 24) + 42);
    inside = ((((((raylib_get_mouse_x() / UI_SCALE) >= x && (raylib_get_mouse_x() / UI_SCALE) < ((x + width) - 58)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= y) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < (y + card_height)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= SELECT_TOP) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < SELECT_BOTTOM);
    fill = 4280425752;
    if (inside) {
    fill = 4280756511;
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetMouseCursor"), 4);
    }
    ui_frame(x, y, width, card_height, fill, ui_color(45, 53, 61));
    line_i = 0;
    while (line_i < length_list(title_lines)) {
    font_draw(get_list(title_lines, line_i), (x + 16), ((y + 12) + (line_i * 24)), 15, ui_color(189, 229, 201));
    line_i = (line_i + 1);
    }
    font_draw(ui_text_fit(detail, (width - 40), 11), (x + 16), ((y + card_height) - 20), 11, ui_color(148, 159, 169));
    font_draw((long long)"Copy", ((x + width) - 48), (y + 14), 11, ui_color(148, 159, 169));
    if ((((UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= SELECT_TOP) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < SELECT_BOTTOM)) {
    if ((inside && SOURCE_CHILD == 0)) {
    SOURCE_CHILD = source_open(url);
    SOURCE_NOTICE = (long long)"";
    if (SOURCE_CHILD == 0) {
    SOURCE_NOTICE = (long long)"This source cannot be opened. Use Copy to inspect its link.";
    } else {
    if (SOURCE_CHILD == -1) {
    SOURCE_CHILD = 0;
    }
    }
    } else {
    if (((((raylib_get_mouse_x() / UI_SCALE) >= ((x + width) - 58) && (raylib_get_mouse_x() / UI_SCALE) < (x + width)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= y) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < (y + card_height))) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetClipboardText"), url);
    SOURCE_NOTICE = (long long)"Source link copied.";
    }
    }
    }
    y = ((y + card_height) + 8);
    i = (i + 1);
    }
    if ((!ep_str_equals(SOURCE_NOTICE, (long long)""))) {
    font_draw(ui_text_fit(SOURCE_NOTICE, (width - 24), 11), (x + 12), (y + 2), 11, ui_color(148, 159, 169));
    y = (y + 24);
    }
    ret_val = y;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(17);
    free_list(rows);
    rows = 0;
    free_list(title_lines);
    title_lines = 0;
    return ret_val;
}

long long ui_color(long long red, long long green, long long blue) {
    long long ret_val = 0;

    ret_val = (((red + (green * 256)) + (blue * 65536)) + 4278190080);
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long ui_frame(long long x, long long y, long long width, long long height, long long fill, long long edge) {
    long long ret_val = 0;

    raylib_draw_rectangle(x, y, width, height, edge);
    raylib_draw_rectangle((x + 1), (y + 1), (width - 2), (height - 2), fill);
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long ui_bitmap(long long bitmap, long long columns, long long x, long long y, long long scale, long long tint) {
    long long i = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&bitmap);

    ep_gc_maybe_collect();

    i = 0;
    while (i < string_length((char*)bitmap)) {
    if (get_character((char*)bitmap, i) == 49) {
    raylib_draw_rectangle((x + ((i % columns) * scale)), (y + ((i / columns) * scale)), scale, scale, tint);
    }
    i = (i + 1);
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long ui_letter(long long code) {
    long long ret_val = 0;

    if (code == 69) {
    ret_val = (long long)"11111100001000011110100001000011111";
    goto L_cleanup;
    }
    if (code == 67) {
    ret_val = (long long)"01111100001000010000100001000001111";
    goto L_cleanup;
    }
    if (code == 72) {
    ret_val = (long long)"10001100011000111111100011000110001";
    goto L_cleanup;
    }
    if (code == 79) {
    ret_val = (long long)"01110100011000110001100011000101110";
    goto L_cleanup;
    }
    if (code == 76) {
    ret_val = (long long)"10000100001000010000100001000011111";
    goto L_cleanup;
    }
    if (code == 73) {
    ret_val = (long long)"11111001000010000100001000010011111";
    goto L_cleanup;
    }
    if (code == 84) {
    ret_val = (long long)"11111001000010000100001000010000100";
    goto L_cleanup;
    }
    ret_val = (long long)"00000000000000000000000000000000000";
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long ui_wordmark(long long x, long long y, long long scale, long long tint) {
    long long i = 0;
    long long word = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&word);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&scale);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    word = (long long)"ECHOLITE";
    i = 0;
    while (i < string_length((char*)word)) {
    ui_bitmap(ui_letter(get_character((char*)word, i)), 5, (x + ((i * scale) * 6)), y, scale, tint);
    i = (i + 1);
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long ui_icon(long long name, long long x, long long y, long long scale, long long tint) {
    long long bitmap = 0;
    long long ret_val = 0;

    ep_gc_push_root(&bitmap);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&scale);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    bitmap = (long long)"01110100011011110100101111000001110";
    if (ep_str_equals(name, (long long)"plus")) {
    bitmap = (long long)"00000001000010011111001000010000000";
    }
    if (ep_str_equals(name, (long long)"chat")) {
    bitmap = (long long)"11111100011000110001111110100010000";
    }
    if (ep_str_equals(name, (long long)"tasks")) {
    bitmap = (long long)"11111100011010110001101011000111111";
    }
    if (ep_str_equals(name, (long long)"memory")) {
    bitmap = (long long)"01110100011111110001111111000101110";
    }
    if (ep_str_equals(name, (long long)"me")) {
    bitmap = (long long)"01110100010111000000011101000110001";
    }
    if (ep_str_equals(name, (long long)"up")) {
    bitmap = (long long)"00100011101111100100001000010000100";
    }
    if (ep_str_equals(name, (long long)"image")) {
    bitmap = (long long)"11111100011010110001101011101111111";
    }
    ui_bitmap(bitmap, 5, x, y, scale, tint);
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long ui_text_fit(long long text, long long width, long long size) {
    long long count = 0;
    long long ret_val = 0;

    ep_gc_push_root(&count);
    ep_gc_push_root(&text);
    ep_gc_push_root(&width);
    ep_gc_push_root(&size);

    ep_gc_maybe_collect();

    if (font_measure(text, size) <= width) {
    ret_val = text;
    goto L_cleanup;
    }
    count = layout_prefix(text, (width - font_measure((long long)"...", size)), size);
    ret_val = concat((long long)substring((char*)text, 0, count), (long long)"...");
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long ui_nav(long long text, long long icon, long long y, long long active) {
    long long fill = 0;
    long long hovered = 0;
    long long tint = 0;
    long long ret_val = 0;

    ep_gc_push_root(&tint);
    ep_gc_push_root(&text);
    ep_gc_push_root(&icon);
    ep_gc_push_root(&y);

    ep_gc_maybe_collect();

    fill = 4279768081;
    tint = 4289372824;
    hovered = ((((raylib_get_mouse_x() / UI_SCALE) >= 16 && (raylib_get_mouse_x() / UI_SCALE) < 232) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= y) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < (y + 38));
    if ((active || hovered)) {
    fill = 4280820766;
    tint = 4293848037;
    }
    raylib_draw_rectangle(16, y, 216, 38, fill);
    if (active) {
    raylib_draw_rectangle(16, y, 2, 38, ui_color(189, 229, 201));
    }
    ui_icon(icon, 30, (y + 11), 2, tint);
    font_draw(text, 56, (y + 11), 15, tint);
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long ui_plain_inline(long long text) {
    long long ret_val = 0;

    ep_gc_push_root(&text);

    ep_gc_maybe_collect();

    text = string_replace(text, (long long)"**", (long long)"");
    ret_val = string_replace(text, (long long)"`", (long long)"");
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long ui_code_block(long long text, long long language, long long x, long long y, long long width) {
    long long block_height = 0;
    long long lines = 0;
    long long title = 0;
    long long ret_val = 0;

    ep_gc_push_root(&block_height);
    ep_gc_push_root(&lines);
    ep_gc_push_root(&title);
    ep_gc_push_root(&text);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);

    ep_gc_maybe_collect();

    lines = layout_lines(text, (width - 32), 15);
    block_height = ((length_list(lines) * 24) + 56);
    ui_frame(x, y, width, block_height, ui_color(17, 21, 26), ui_color(47, 56, 64));
    raylib_draw_rectangle((x + 1), (y + 1), (width - 2), 30, ui_color(28, 34, 40));
    title = language;
    if (ep_str_equals(title, (long long)"")) {
    title = (long long)"CODE";
    }
    font_draw(ui_text_fit(title, (width - 110), 12), (x + 16), (y + 9), 12, ui_color(155, 174, 165));
    font_draw((long long)"Copy", ((x + width) - 52), (y + 9), 12, ui_color(189, 229, 201));
    if ((((((((UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0)) && (raylib_get_mouse_x() / UI_SCALE) >= ((x + width) - 64)) && (raylib_get_mouse_x() / UI_SCALE) <= (x + width)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= y) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < (y + 30)) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) >= SELECT_TOP) && ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP) < SELECT_BOTTOM)) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetClipboardText"), text);
    }
    selectable_text(text, (x + 16), (y + 42), (width - 32), 15, ui_color(216, 229, 220));
    ret_val = ((y + block_height) + 16);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    free_list(lines);
    lines = 0;
    return ret_val;
}

long long ui_response(long long text, long long x, long long y, long long width, long long tint) {
    long long code = 0;
    long long i = 0;
    long long in_code = 0;
    long long language = 0;
    long long line = 0;
    long long lines = 0;
    long long offset = 0;
    long long ret_val = 0;

    ep_gc_push_root(&code);
    ep_gc_push_root(&i);
    ep_gc_push_root(&language);
    ep_gc_push_root(&line);
    ep_gc_push_root(&lines);
    ep_gc_push_root(&offset);
    ep_gc_push_root(&text);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    if ((((((((string_contains(text, (long long)"```") == 0 && string_contains(text, (long long)"**") == 0) && starts_with(text, (long long)"#") == 0) && string_contains(text, (long long)"\n#") == 0) && starts_with(text, (long long)"- ") == 0) && starts_with(text, (long long)"* ") == 0) && string_contains(text, (long long)"\n- ") == 0) && string_contains(text, (long long)"\n* ") == 0)) {
    ret_val = selectable_text(text, x, y, width, 18, tint);
    goto L_cleanup;
    }
    lines = string_split(text, (long long)"\n");
    i = 0;
    code = (long long)"";
    language = (long long)"";
    in_code = 0;
    while (i < length_list(lines)) {
    line = get_list(lines, i);
    if (starts_with(string_trim(line), (long long)"```")) {
    if (in_code) {
    y = ui_code_block(code, language, x, y, width);
    code = (long long)"";
    in_code = 0;
    } else {
    language = string_trim((long long)substring((char*)string_trim(line), 3, (string_length((char*)string_trim(line)) - 3)));
    in_code = 1;
    }
    } else {
    if (in_code) {
    if ((!ep_str_equals(code, (long long)""))) {
    code = concat(code, (long long)"\n");
    }
    code = concat(code, line);
    } else {
    if (ep_str_equals(string_trim(line), (long long)"")) {
    y = (y + 12);
    } else {
    if (starts_with(line, (long long)"#")) {
    offset = 0;
    while ((offset < string_length((char*)line) && get_character((char*)line, offset) == 35)) {
    offset = (offset + 1);
    }
    y = selectable_text(ui_plain_inline(string_trim((long long)substring((char*)line, offset, (string_length((char*)line) - offset)))), x, (y + 4), width, 22, ui_color(218, 237, 225));
    y = (y + 8);
    } else {
    if ((starts_with(line, (long long)"- ") || starts_with(line, (long long)"* "))) {
    raylib_draw_rectangle((x + 2), (y + 8), 4, 4, ui_color(189, 229, 201));
    y = selectable_text(ui_plain_inline((long long)substring((char*)line, 2, (string_length((char*)line) - 2))), (x + 18), y, (width - 18), 18, tint);
    y = (y + 4);
    } else {
    y = selectable_text(ui_plain_inline(line), x, y, width, 18, tint);
    }
    }
    }
    }
    }
    i = (i + 1);
    }
    if (in_code) {
    y = ui_code_block(code, language, x, y, width);
    }
    ret_val = y;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(11);
    free_list(lines);
    lines = 0;
    return ret_val;
}

long long ui_capture(long long path) {
    long long filename = 0;
    long long height = 0;
    long long image_type = 0;
    long long int_type = 0;
    long long picture = 0;
    long long pixels = 0;
    long long pointer_type = 0;
    long long result = 0;
    long long signature = 0;
    long long values = 0;
    long long width = 0;
    long long ret_val = 0;

    ep_gc_push_root(&filename);
    ep_gc_push_root(&height);
    ep_gc_push_root(&image_type);
    ep_gc_push_root(&int_type);
    ep_gc_push_root(&picture);
    ep_gc_push_root(&pixels);
    ep_gc_push_root(&pointer_type);
    ep_gc_push_root(&result);
    ep_gc_push_root(&signature);
    ep_gc_push_root(&values);
    ep_gc_push_root(&width);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    width = ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"rlGetFramebufferWidth"));
    height = ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"rlGetFramebufferHeight"));
    pixels = ep_dlcall2(ep_dlsym(RAYLIB_HANDLE, (long long)"rlReadScreenPixels"), width, height);
    picture = alloc_bytes(24);
    native_bytes_write(picture, 0, pixels, 8);
    native_bytes_write(picture, 8, width, 4);
    native_bytes_write(picture, 12, height, 4);
    native_bytes_write(picture, 16, 1, 4);
    native_bytes_write(picture, 20, 7, 4);
    int_type = ep_dlsym(FONT_FFI, (long long)"ffi_type_sint32");
    pointer_type = ep_dlsym(FONT_FFI, (long long)"ffi_type_pointer");
    image_type = native_struct(({ long long _lit_list = create_list(); append_list(_lit_list, pointer_type); append_list(_lit_list, int_type); append_list(_lit_list, int_type); append_list(_lit_list, int_type); append_list(_lit_list, int_type); _lit_list; }));
    signature = native_cif(int_type, ({ long long _lit_list = create_list(); append_list(_lit_list, image_type); append_list(_lit_list, pointer_type); _lit_list; }));
    filename = ({ long long _lit_list = create_list(); append_list(_lit_list, str_to_ptr(path)); _lit_list; });
    values = ({ long long _lit_list = create_list(); append_list(_lit_list, picture); append_list(_lit_list, get_list_data_ptr(filename)); _lit_list; });
    result = alloc_bytes(8);
    ep_dlcall4(FONT_CALL, signature, ep_dlsym(RAYLIB_HANDLE, (long long)"ExportImage"), result, get_list_data_ptr(values));
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"MemFree"), pixels);
    free_bytes(picture);
    free_bytes(result);
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(12);
    free_list(filename);
    filename = 0;
    free_list(values);
    values = 0;
    return ret_val;
}

long long editor_previous(long long text, long long position) {
    long long ret_val = 0;

    ep_gc_push_root(&text);
    ep_gc_push_root(&position);

    ep_gc_maybe_collect();

    if (position <= 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    ret_val = layout_boundary(text, (position - 1));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long editor_next(long long text, long long position) {
    long long ret_val = 0;

    ep_gc_push_root(&text);
    ep_gc_push_root(&position);

    ep_gc_maybe_collect();

    position = (position + 1);
    while (((position < string_length((char*)text) && get_character((char*)text, position) >= 128) && get_character((char*)text, position) < 192)) {
    position = (position + 1);
    }
    ret_val = editor_min(position, string_length((char*)text));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long editor_selected(long long text, long long caret, long long anchor) {
    long long ret_val = 0;

    ep_gc_push_root(&text);
    ep_gc_push_root(&caret);
    ep_gc_push_root(&anchor);

    ep_gc_maybe_collect();

    ret_val = (long long)substring((char*)text, editor_min(caret, anchor), (editor_max(caret, anchor) - editor_min(caret, anchor)));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long editor_splice(long long text, long long caret, long long anchor, long long inserted) {
    long long finish = 0;
    long long start = 0;
    long long ret_val = 0;

    ep_gc_push_root(&finish);
    ep_gc_push_root(&start);
    ep_gc_push_root(&text);
    ep_gc_push_root(&caret);
    ep_gc_push_root(&anchor);
    ep_gc_push_root(&inserted);

    ep_gc_maybe_collect();

    start = editor_min(caret, anchor);
    finish = editor_max(caret, anchor);
    ret_val = concat((long long)substring((char*)text, 0, start), concat(inserted, (long long)substring((char*)text, finish, (string_length((char*)text) - finish))));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long editor_snapshot() {
    long long ret_val = 0;

    ep_gc_maybe_collect();

    if (length_list(EDIT_UNDO) >= 64) {
    remove_list(EDIT_UNDO, 0);
    }
    append_list(EDIT_UNDO, editor_state());
    EDIT_REDO = create_list();
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long editor_insert(long long text) {
    long long ret_val = 0;

    ep_gc_push_root(&text);

    ep_gc_maybe_collect();

    text = string_replace(string_replace(text, (long long)"\r\n", (long long)"\n"), (long long)"\r", (long long)"\n");
    if ((((string_length((char*)EDIT_TEXT) - editor_max(EDIT_CARET, EDIT_ANCHOR)) + editor_min(EDIT_CARET, EDIT_ANCHOR)) + string_length((char*)text)) > 6000) {
    EDIT_ERROR = (long long)"Message limit: 6000 UTF-8 bytes. Shorten the text or attach a document.";
    ret_val = 0;
    goto L_cleanup;
    }
    EDIT_ERROR = (long long)"";
    if ((ep_str_equals(text, (long long)"") && EDIT_CARET == EDIT_ANCHOR)) {
    ret_val = 1;
    goto L_cleanup;
    }
    editor_snapshot();
    EDIT_TEXT = editor_splice(EDIT_TEXT, EDIT_CARET, EDIT_ANCHOR, text);
    EDIT_CARET = (editor_min(EDIT_CARET, EDIT_ANCHOR) + string_length((char*)text));
    EDIT_ANCHOR = EDIT_CARET;
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long editor_history(long long redo) {
    long long row = 0;
    long long ret_val = 0;

    ep_gc_push_root(&row);

    ep_gc_maybe_collect();

    row = 0;
    if (redo) {
    if (length_list(EDIT_REDO) == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    row = get_list(EDIT_REDO, (length_list(EDIT_REDO) - 1));
    append_list(EDIT_UNDO, editor_state());
    remove_list(EDIT_REDO, (length_list(EDIT_REDO) - 1));
    } else {
    if (length_list(EDIT_UNDO) == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    row = get_list(EDIT_UNDO, (length_list(EDIT_UNDO) - 1));
    append_list(EDIT_REDO, editor_state());
    remove_list(EDIT_UNDO, (length_list(EDIT_UNDO) - 1));
    }
    EDIT_TEXT = get_list(row, 0);
    EDIT_CARET = get_list(row, 1);
    EDIT_ANCHOR = get_list(row, 2);
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long editor_row(long long rows, long long caret) {
    long long i = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&rows);

    ep_gc_maybe_collect();

    i = 0;
    while (i < (length_list(rows) - 1)) {
    if (caret < get_list(get_list(rows, (i + 1)), 0)) {
    ret_val = i;
    goto L_cleanup;
    }
    i = (i + 1);
    }
    ret_val = i;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long editor_hit(long long text, long long rows, long long x, long long y, long long size) {
    long long finish = 0;
    long long line = 0;
    long long next = 0;
    long long next_width = 0;
    long long pos = 0;
    long long previous_width = 0;
    long long row = 0;
    long long start = 0;
    long long ret_val = 0;

    ep_gc_push_root(&line);
    ep_gc_push_root(&next);
    ep_gc_push_root(&pos);
    ep_gc_push_root(&row);
    ep_gc_push_root(&start);
    ep_gc_push_root(&text);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&y);
    ep_gc_push_root(&size);

    ep_gc_maybe_collect();

    line = editor_min(editor_max(0, (y / (size + 9))), (length_list(rows) - 1));
    row = get_list(rows, line);
    start = get_list(row, 0);
    finish = get_list(row, 1);
    pos = start;
    previous_width = 0;
    while (pos < finish) {
    next = editor_next(text, pos);
    next_width = font_measure((long long)substring((char*)text, start, (next - start)), size);
    if (x < ((previous_width + next_width) / 2)) {
    ret_val = pos;
    goto L_cleanup;
    }
    previous_width = next_width;
    pos = next;
    }
    ret_val = finish;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    return ret_val;
}

long long editor_move(long long direction, long long shift, long long command, long long word, long long width) {
    long long delta = 0;
    long long destination = 0;
    long long line = 0;
    long long px = 0;
    long long row = 0;
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&delta);
    ep_gc_push_root(&destination);
    ep_gc_push_root(&line);
    ep_gc_push_root(&px);
    ep_gc_push_root(&row);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&width);

    ep_gc_maybe_collect();

    destination = EDIT_CARET;
    rows = layout_ranges(EDIT_TEXT, width, 18);
    line = editor_row(rows, EDIT_CARET);
    row = get_list(rows, line);
    if ((direction == 263 || direction == 262)) {
    if (command) {
    destination = get_list(row, 0);
    if (direction == 262) {
    destination = get_list(row, 1);
    }
    } else {
    if ((shift == 0 && EDIT_CARET != EDIT_ANCHOR)) {
    destination = editor_min(EDIT_CARET, EDIT_ANCHOR);
    if (direction == 262) {
    destination = editor_max(EDIT_CARET, EDIT_ANCHOR);
    }
    } else {
    if (direction == 263) {
    destination = editor_previous(EDIT_TEXT, destination);
    if (word) {
    while (((destination > 0 && get_character((char*)EDIT_TEXT, (destination - 1)) != 32) && get_character((char*)EDIT_TEXT, (destination - 1)) != 10)) {
    destination = editor_previous(EDIT_TEXT, destination);
    }
    }
    } else {
    destination = editor_next(EDIT_TEXT, destination);
    if (word) {
    while (((destination < string_length((char*)EDIT_TEXT) && get_character((char*)EDIT_TEXT, destination) != 32) && get_character((char*)EDIT_TEXT, destination) != 10)) {
    destination = editor_next(EDIT_TEXT, destination);
    }
    }
    }
    }
    }
    } else {
    if (direction == 268) {
    destination = get_list(row, 0);
    } else {
    if (direction == 269) {
    destination = get_list(row, 1);
    } else {
    delta = 1;
    if (direction == 265) {
    delta = -1;
    }
    px = font_measure((long long)substring((char*)EDIT_TEXT, get_list(row, 0), (EDIT_CARET - get_list(row, 0))), 18);
    destination = editor_hit(EDIT_TEXT, rows, px, ((line + delta) * 27), 18);
    if (command) {
    destination = string_length((char*)EDIT_TEXT);
    if (direction == 265) {
    destination = 0;
    }
    }
    }
    }
    }
    EDIT_CARET = destination;
    if (shift == 0) {
    EDIT_ANCHOR = destination;
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long editor_key(long long key) {
    long long repeat_fn = 0;
    long long ret_val = 0;

    ep_gc_push_root(&repeat_fn);
    ep_gc_push_root(&key);

    ep_gc_maybe_collect();

    if (raylib_is_key_pressed(key)) {
    ret_val = 1;
    goto L_cleanup;
    }
    repeat_fn = ep_dlsym(RAYLIB_HANDLE, (long long)"IsKeyPressedRepeat");
    if (repeat_fn != 0) {
    ret_val = ep_dlcall1(repeat_fn, key);
    goto L_cleanup;
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long editor_clipboard() {
    long long pointer = 0;
    long long ret_val = 0;

    ep_gc_push_root(&pointer);

    ep_gc_maybe_collect();

    pointer = ep_dlcall0(ep_dlsym(RAYLIB_HANDLE, (long long)"GetClipboardText"));
    if (pointer == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    ret_val = ptr_to_str(pointer);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long editor_handle(long long draft, long long x, long long y, long long width, long long height, long long enabled) {
    long long bounds = 0;
    long long clicked = 0;
    long long code = 0;
    long long command = 0;
    long long i = 0;
    long long inserted = 0;
    long long item = 0;
    long long keys = 0;
    long long mx = 0;
    long long my = 0;
    long long now = 0;
    long long rows = 0;
    long long shift = 0;
    long long word = 0;
    long long ret_val = 0;

    ep_gc_push_root(&bounds);
    ep_gc_push_root(&code);
    ep_gc_push_root(&command);
    ep_gc_push_root(&i);
    ep_gc_push_root(&inserted);
    ep_gc_push_root(&keys);
    ep_gc_push_root(&mx);
    ep_gc_push_root(&my);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&shift);
    ep_gc_push_root(&word);
    ep_gc_push_root(&draft);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);

    ep_gc_maybe_collect();

    if (string_equals(draft, EDIT_TEXT) == 0) {
    EDIT_TEXT = draft;
    EDIT_CARET = string_length((char*)draft);
    EDIT_ANCHOR = EDIT_CARET;
    EDIT_UNDO = create_list();
    EDIT_REDO = create_list();
    }
    EDIT_MENU_USED = 0;
    if ((EDIT_MENU && (UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0)))) {
    mx = (raylib_get_mouse_x() / UI_SCALE);
    my = ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP);
    if ((((mx >= EDIT_MENU_X && mx <= (EDIT_MENU_X + 190)) && my >= EDIT_MENU_Y) && my < (EDIT_MENU_Y + 160))) {
    item = ((my - EDIT_MENU_Y) / 32);
    if (item == 0) {
    if (EDIT_FOCUS) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetClipboardText"), editor_selected(EDIT_TEXT, EDIT_CARET, EDIT_ANCHOR));
    } else {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetClipboardText"), editor_selected(SELECT_TEXT, SELECT_CARET, SELECT_ANCHOR));
    }
    }
    if ((item == 1 && EDIT_FOCUS)) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetClipboardText"), editor_selected(EDIT_TEXT, EDIT_CARET, EDIT_ANCHOR));
    editor_insert((long long)"");
    }
    if ((item == 2 && EDIT_FOCUS)) {
    editor_insert(editor_clipboard());
    }
    if (item == 3) {
    if (EDIT_FOCUS) {
    EDIT_ANCHOR = 0;
    EDIT_CARET = string_length((char*)EDIT_TEXT);
    } else {
    SELECT_ANCHOR = 0;
    SELECT_CARET = string_length((char*)SELECT_TEXT);
    }
    }
    if ((item == 4 && EDIT_FOCUS)) {
    editor_history(0);
    }
    }
    EDIT_MENU = 0;
    EDIT_MENU_USED = 1;
    ret_val = EDIT_TEXT;
    goto L_cleanup;
    }
    if (raylib_is_key_pressed(256)) {
    EDIT_MENU = 0;
    }
    shift = (raylib_is_key_down(340) || raylib_is_key_down(344));
    command = (((raylib_is_key_down(343) || raylib_is_key_down(347)) || raylib_is_key_down(341)) || raylib_is_key_down(345));
    word = (raylib_is_key_down(342) || raylib_is_key_down(346));
    rows = layout_ranges(EDIT_TEXT, width, 18);
    mx = (raylib_get_mouse_x() / UI_SCALE);
    my = ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP);
    clicked = (UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0));
    if (((((enabled && mx >= x) && mx <= (x + width)) && my >= y) && my <= (y + height))) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetMouseCursor"), 2);
    }
    if ((((((raylib_is_mouse_button_pressed(1) && enabled) && mx >= x) && mx <= (x + width)) && my >= y) && my <= (y + height))) {
    EDIT_FOCUS = 1;
    editor_menu_open(mx, my);
    }
    if (clicked) {
    EDIT_FOCUS = ((((enabled && mx >= x) && mx <= (x + width)) && my >= y) && my <= (y + height));
    if (native_android()) {
    android_keyboard(EDIT_FOCUS);
    }
    EDIT_DRAG = EDIT_FOCUS;
    if (EDIT_FOCUS) {
    SELECT_TEXT = (long long)"";
    SELECT_DRAG = 0;
    EDIT_CARET = editor_hit(EDIT_TEXT, rows, (mx - x), ((my - y) + EDIT_SCROLL), 18);
    if (shift == 0) {
    EDIT_ANCHOR = EDIT_CARET;
    }
    now = transport_now(native_system());
    if (((now - EDIT_CLICK_TIME) < 400 && EDIT_CARET == EDIT_CLICK_POS)) {
    bounds = editor_word(EDIT_TEXT, EDIT_CARET);
    EDIT_ANCHOR = get_list(bounds, 0);
    EDIT_CARET = get_list(bounds, 1);
    }
    EDIT_CLICK_TIME = now;
    EDIT_CLICK_POS = EDIT_CARET;
    }
    }
    if ((((((native_android() && EDIT_DRAG) && EDIT_MENU == 0) && raylib_is_mouse_button_down(0)) && UI_TOUCH_MOVED == 0) && (transport_now(native_system()) - EDIT_CLICK_TIME) >= 550)) {
    if ((EDIT_CARET == EDIT_ANCHOR && (!ep_str_equals(EDIT_TEXT, (long long)"")))) {
    bounds = editor_word(EDIT_TEXT, EDIT_CARET);
    EDIT_ANCHOR = get_list(bounds, 0);
    EDIT_CARET = get_list(bounds, 1);
    }
    EDIT_DRAG = 0;
    editor_menu_open(mx, my);
    }
    if (((EDIT_DRAG && raylib_is_mouse_button_down(0)) && clicked == 0)) {
    if (my < y) {
    EDIT_SCROLL = editor_max(0, (EDIT_SCROLL - 8));
    }
    if (my > (y + height)) {
    EDIT_SCROLL = (EDIT_SCROLL + 8);
    }
    EDIT_CARET = editor_hit(EDIT_TEXT, rows, (mx - x), ((my - y) + EDIT_SCROLL), 18);
    }
    if (raylib_is_mouse_button_down(0) == 0) {
    EDIT_DRAG = 0;
    SELECT_DRAG = 0;
    }
    if ((enabled && EDIT_FOCUS)) {
    if ((command && raylib_is_key_pressed(65))) {
    EDIT_ANCHOR = 0;
    EDIT_CARET = string_length((char*)EDIT_TEXT);
    }
    if (((command && (raylib_is_key_pressed(67) || raylib_is_key_pressed(88))) && EDIT_CARET != EDIT_ANCHOR)) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetClipboardText"), editor_selected(EDIT_TEXT, EDIT_CARET, EDIT_ANCHOR));
    if (raylib_is_key_pressed(88)) {
    editor_insert((long long)"");
    }
    }
    if ((command && raylib_is_key_pressed(86))) {
    editor_insert(editor_clipboard());
    }
    if ((command && raylib_is_key_pressed(90))) {
    editor_history(shift);
    }
    if ((command && raylib_is_key_pressed(89))) {
    editor_history(1);
    }
    keys = ({ long long _lit_list = create_list(); append_list(_lit_list, 263); append_list(_lit_list, 262); append_list(_lit_list, 265); append_list(_lit_list, 264); append_list(_lit_list, 268); append_list(_lit_list, 269); _lit_list; });
    i = 0;
    while (i < length_list(keys)) {
    if (editor_key(get_list(keys, i))) {
    editor_move(get_list(keys, i), shift, command, word, width);
    }
    i = (i + 1);
    }
    if ((editor_key(259) || editor_key(261))) {
    if (EDIT_CARET == EDIT_ANCHOR) {
    if (editor_key(259)) {
    EDIT_ANCHOR = editor_previous(EDIT_TEXT, EDIT_CARET);
    } else {
    EDIT_ANCHOR = editor_next(EDIT_TEXT, EDIT_CARET);
    }
    }
    editor_insert((long long)"");
    }
    if ((shift && raylib_is_key_pressed(257))) {
    editor_insert((long long)"\n");
    }
    } else {
    if ((command && (!ep_str_equals(SELECT_TEXT, (long long)"")))) {
    if (raylib_is_key_pressed(65)) {
    SELECT_ANCHOR = 0;
    SELECT_CARET = string_length((char*)SELECT_TEXT);
    }
    if ((raylib_is_key_pressed(67) && SELECT_CARET != SELECT_ANCHOR)) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetClipboardText"), editor_selected(SELECT_TEXT, SELECT_CARET, SELECT_ANCHOR));
    }
    }
    }
    code = raylib_get_char_pressed();
    while (code > 0) {
    if (((((native_android() == 0 && enabled) && EDIT_FOCUS) && command == 0) && code >= 32)) {
    editor_insert(chat_character(code));
    }
    code = raylib_get_char_pressed();
    }
    if (native_android()) {
    inserted = android_input_take();
    if (((enabled && EDIT_FOCUS) && (!ep_str_equals(inserted, (long long)"")))) {
    editor_insert(inserted);
    EDIT_BLINK = transport_now(native_system());
    }
    }
    if ((clicked || raylib_get_key_pressed() != 0)) {
    EDIT_BLINK = transport_now(native_system());
    }
    ret_val = EDIT_TEXT;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(15);
    free_list(bounds);
    bounds = 0;
    free_list(keys);
    keys = 0;
    return ret_val;
}

long long editor_paint(long long text, long long rows, long long x, long long y, long long size, long long tint, long long anchor, long long caret, long long selected) {
    long long a = 0;
    long long b = 0;
    long long finish = 0;
    long long i = 0;
    long long left = 0;
    long long row = 0;
    long long span = 0;
    long long start = 0;
    long long ret_val = 0;

    ep_gc_push_root(&a);
    ep_gc_push_root(&b);
    ep_gc_push_root(&finish);
    ep_gc_push_root(&i);
    ep_gc_push_root(&row);
    ep_gc_push_root(&start);
    ep_gc_push_root(&text);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&size);
    ep_gc_push_root(&tint);
    ep_gc_push_root(&anchor);
    ep_gc_push_root(&caret);

    ep_gc_maybe_collect();

    i = 0;
    while (i < length_list(rows)) {
    row = get_list(rows, i);
    start = get_list(row, 0);
    finish = get_list(row, 1);
    if (((selected && editor_max(anchor, caret) > start) && editor_min(anchor, caret) < finish)) {
    a = editor_max(start, editor_min(anchor, caret));
    b = editor_min(finish, editor_max(anchor, caret));
    left = font_measure((long long)substring((char*)text, start, (a - start)), size);
    span = editor_max(3, font_measure((long long)substring((char*)text, a, (b - a)), size));
    raylib_draw_rectangle((x + left), (y + (i * (size + 9))), span, (size + 5), 4284117825);
    }
    font_draw((long long)substring((char*)text, start, (finish - start)), x, (y + (i * (size + 9))), size, tint);
    i = (i + 1);
    }
    ret_val = (y + (length_list(rows) * (size + 9)));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(14);
    return ret_val;
}

long long editor_draw(long long x, long long y, long long width, long long height, long long tint, long long caret_color) {
    long long line = 0;
    long long px = 0;
    long long row = 0;
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&line);
    ep_gc_push_root(&row);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    rows = layout_ranges(EDIT_TEXT, width, 18);
    line = editor_row(rows, EDIT_CARET);
    if ((line * 27) < EDIT_SCROLL) {
    EDIT_SCROLL = (line * 27);
    }
    if (((line * 27) + 23) > (EDIT_SCROLL + height)) {
    EDIT_SCROLL = (((line * 27) + 23) - height);
    }
    EDIT_SCROLL = editor_max(0, EDIT_SCROLL);
    editor_paint(EDIT_TEXT, rows, x, (y - EDIT_SCROLL), 18, tint, EDIT_ANCHOR, EDIT_CARET, EDIT_FOCUS);
    if ((EDIT_FOCUS && (((transport_now(native_system()) - EDIT_BLINK) / 500) % 2) == 0)) {
    row = get_list(rows, line);
    px = font_measure((long long)substring((char*)EDIT_TEXT, get_list(row, 0), (EDIT_CARET - get_list(row, 0))), 18);
    raylib_draw_rectangle((x + px), ((y + (line * 27)) - EDIT_SCROLL), 2, 23, caret_color);
    }
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long selectable_text(long long text, long long x, long long y, long long width, long long size, long long tint) {
    long long bottom = 0;
    long long bounds = 0;
    long long inside = 0;
    long long mx = 0;
    long long my = 0;
    long long now = 0;
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&bounds);
    ep_gc_push_root(&mx);
    ep_gc_push_root(&my);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&text);
    ep_gc_push_root(&x);
    ep_gc_push_root(&y);
    ep_gc_push_root(&width);
    ep_gc_push_root(&size);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    rows = layout_ranges(text, (width - 1), size);
    mx = (raylib_get_mouse_x() / UI_SCALE);
    my = ((raylib_get_mouse_y() / UI_SCALE) - UI_TOP);
    bottom = (y + (length_list(rows) * (size + 9)));
    inside = (((((mx >= x && mx <= (x + width)) && my >= y) && my < bottom) && my >= SELECT_TOP) && my < SELECT_BOTTOM);
    if (inside) {
    ep_dlcall1(ep_dlsym(RAYLIB_HANDLE, (long long)"SetMouseCursor"), 2);
    }
    if (((((UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0)) && inside) && EDIT_MENU == 0) && EDIT_MENU_USED == 0)) {
    SELECT_TEXT = text;
    SELECT_ANCHOR = editor_hit(text, rows, (mx - x), (my - y), size);
    SELECT_CARET = SELECT_ANCHOR;
    now = transport_now(native_system());
    if (((now - SELECT_CLICK_TIME) < 400 && SELECT_CARET == SELECT_CLICK_POS)) {
    bounds = editor_word(text, SELECT_CARET);
    SELECT_ANCHOR = get_list(bounds, 0);
    SELECT_CARET = get_list(bounds, 1);
    }
    SELECT_CLICK_TIME = now;
    SELECT_CLICK_POS = SELECT_CARET;
    SELECT_DRAG = 1;
    EDIT_FOCUS = 0;
    }
    if (((native_android() && SELECT_DRAG) && string_equals(SELECT_TEXT, text))) {
    if (UI_TOUCH_MOVED) {
    SELECT_DRAG = 0;
    } else {
    if (((EDIT_MENU == 0 && raylib_is_mouse_button_down(0)) && (transport_now(native_system()) - SELECT_CLICK_TIME) >= 550)) {
    bounds = editor_word(text, SELECT_CARET);
    SELECT_ANCHOR = get_list(bounds, 0);
    SELECT_CARET = get_list(bounds, 1);
    SELECT_DRAG = 0;
    editor_menu_open(mx, my);
    }
    }
    }
    if (((((native_android() == 0 && SELECT_DRAG) && raylib_is_mouse_button_down(0)) && (UI_POINTER_PRESSED || raylib_is_mouse_button_pressed(0)) == 0) && string_equals(SELECT_TEXT, text))) {
    SELECT_CARET = editor_hit(text, rows, (mx - x), (my - y), size);
    }
    if ((raylib_is_mouse_button_pressed(1) && inside)) {
    EDIT_FOCUS = 0;
    if (string_equals(SELECT_TEXT, text) == 0) {
    SELECT_TEXT = text;
    SELECT_ANCHOR = 0;
    SELECT_CARET = string_length((char*)text);
    }
    editor_menu_open(mx, my);
    }
    ret_val = editor_paint(text, rows, x, y, size, tint, SELECT_ANCHOR, SELECT_CARET, (EDIT_FOCUS == 0 && string_equals(SELECT_TEXT, text)));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(10);
    free_list(bounds);
    bounds = 0;
    return ret_val;
}

long long editor_min(long long a, long long b) {
    long long ret_val = 0;

    if (a < b) {
    ret_val = a;
    goto L_cleanup;
    }
    ret_val = b;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long editor_max(long long a, long long b) {
    long long ret_val = 0;

    if (a > b) {
    ret_val = a;
    goto L_cleanup;
    }
    ret_val = b;
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long editor_state() {
    long long row = 0;
    long long ret_val = 0;

    ep_gc_push_root(&row);

    ep_gc_maybe_collect();

    row = create_list();
    append_list(row, EDIT_TEXT);
    append_list(row, EDIT_CARET);
    append_list(row, EDIT_ANCHOR);
    ret_val = row;
    row = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long editor_word(long long text, long long position) {
    long long finish = 0;
    long long start = 0;
    long long ret_val = 0;

    ep_gc_push_root(&finish);
    ep_gc_push_root(&start);
    ep_gc_push_root(&text);

    ep_gc_maybe_collect();

    start = position;
    finish = position;
    while ((start > 0 && get_character((char*)text, (start - 1)) > 32)) {
    start = editor_previous(text, start);
    }
    while ((finish < string_length((char*)text) && get_character((char*)text, finish) > 32)) {
    finish = editor_next(text, finish);
    }
    ret_val = ({ long long _lit_list = create_list(); append_list(_lit_list, start); append_list(_lit_list, finish); _lit_list; });
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long editor_menu_open(long long x, long long y) {
    long long ret_val = 0;

    ep_gc_push_root(&x);
    ep_gc_push_root(&y);

    ep_gc_maybe_collect();

    EDIT_MENU = 1;
    EDIT_MENU_X = editor_min(x, (ui_screen_width() - 200));
    EDIT_MENU_Y = editor_max(10, editor_min(y, (ui_screen_height() - 170)));
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long editor_menu_draw() {
    long long i = 0;
    long long items = 0;
    long long tint = 0;
    long long ret_val = 0;

    ep_gc_push_root(&items);
    ep_gc_push_root(&tint);

    ep_gc_maybe_collect();

    if (EDIT_MENU == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    raylib_draw_rectangle(EDIT_MENU_X, EDIT_MENU_Y, 190, 160, 4281218857);
    items = ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"Copy"); append_list(_lit_list, (long long)(long long)"Cut"); append_list(_lit_list, (long long)(long long)"Paste"); append_list(_lit_list, (long long)(long long)"Select all"); append_list(_lit_list, (long long)(long long)"Undo"); _lit_list; });
    tint = 4293848808;
    font_draw(get_list(items, 0), (EDIT_MENU_X + 14), (EDIT_MENU_Y + 7), 16, tint);
    tint = 4293848808;
    if ((EDIT_FOCUS == 0 && 1)) {
    tint = 4286545791;
    }
    font_draw(get_list(items, 1), (EDIT_MENU_X + 14), ((EDIT_MENU_Y + 32) + 7), 16, tint);
    tint = 4293848808;
    if ((EDIT_FOCUS == 0 && 1)) {
    tint = 4286545791;
    }
    font_draw(get_list(items, 2), (EDIT_MENU_X + 14), ((EDIT_MENU_Y + 64) + 7), 16, tint);
    tint = 4293848808;
    font_draw(get_list(items, 3), (EDIT_MENU_X + 14), ((EDIT_MENU_Y + 96) + 7), 16, tint);
    tint = 4293848808;
    if ((EDIT_FOCUS == 0 && 1)) {
    tint = 4286545791;
    }
    font_draw(get_list(items, 4), (EDIT_MENU_X + 14), ((EDIT_MENU_Y + 128) + 7), 16, tint);
    i = 5;
    ret_val = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    free_list(items);
    items = 0;
    return ret_val;
}

long long attachment_pick() {
    long long appkit = 0;
    long long extensions = 0;
    long long get_class = 0;
    long long i = 0;
    long long panel = 0;
    long long path = 0;
    long long pool = 0;
    long long prompt = 0;
    long long strings = 0;
    long long title = 0;
    long long types = 0;
    long long url = 0;
    long long value = 0;
    long long ret_val = 0;

    ep_gc_push_root(&extensions);
    ep_gc_push_root(&get_class);
    ep_gc_push_root(&i);
    ep_gc_push_root(&panel);
    ep_gc_push_root(&path);
    ep_gc_push_root(&pool);
    ep_gc_push_root(&prompt);
    ep_gc_push_root(&strings);
    ep_gc_push_root(&title);
    ep_gc_push_root(&types);
    ep_gc_push_root(&url);
    ep_gc_push_root(&value);

    ep_gc_maybe_collect();

    PDF_OBJC = ep_dlopen((long long)"/usr/lib/libobjc.A.dylib");
    appkit = ep_dlopen((long long)"/System/Library/Frameworks/AppKit.framework/AppKit");
    if ((PDF_OBJC == 0 || appkit == 0)) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    get_class = ep_dlsym(PDF_OBJC, (long long)"objc_getClass");
    pool = pdf_message(pdf_message(ep_dlcall1(get_class, (long long)"NSAutoreleasePool"), (long long)"alloc"), (long long)"init");
    panel = pdf_message(ep_dlcall1(get_class, (long long)"NSOpenPanel"), (long long)"openPanel");
    pdf_argument(panel, (long long)"setCanChooseFiles:", 1);
    pdf_argument(panel, (long long)"setCanChooseDirectories:", 0);
    pdf_argument(panel, (long long)"setAllowsMultipleSelection:", 0);
    strings = ep_dlcall1(get_class, (long long)"NSString");
    title = pdf_argument(strings, (long long)"stringWithUTF8String:", (long long)"Attach an image");
    pdf_argument(panel, (long long)"setTitle:", title);
    prompt = pdf_argument(strings, (long long)"stringWithUTF8String:", (long long)"Attach");
    pdf_argument(panel, (long long)"setPrompt:", prompt);
    types = pdf_message(ep_dlcall1(get_class, (long long)"NSMutableArray"), (long long)"array");
    extensions = ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"png"); append_list(_lit_list, (long long)(long long)"jpg"); append_list(_lit_list, (long long)(long long)"jpeg"); append_list(_lit_list, (long long)(long long)"heic"); append_list(_lit_list, (long long)(long long)"heif"); _lit_list; });
    i = 0;
    while (i < length_list(extensions)) {
    pdf_argument(types, (long long)"addObject:", pdf_argument(strings, (long long)"stringWithUTF8String:", get_list(extensions, i)));
    i = (i + 1);
    }
    pdf_argument(panel, (long long)"setAllowedFileTypes:", types);
    path = (long long)"";
    if (pdf_message(panel, (long long)"runModal") == 1) {
    url = pdf_message(panel, (long long)"URL");
    if (url != 0) {
    value = pdf_message(url, (long long)"path");
    if (value != 0) {
    path = ptr_to_str(pdf_message(value, (long long)"UTF8String"));
    }
    }
    }
    pdf_message(pool, (long long)"drain");
    ret_val = path;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(12);
    free_list(extensions);
    extensions = 0;
    return ret_val;
}

long long attachment_begin(long long core, long long project, long long path) {
    long long fd = 0;
    long long file = 0;
    long long pid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fd);
    ep_gc_push_root(&file);
    ep_gc_push_root(&pid);
    ep_gc_push_root(&core);
    ep_gc_push_root(&project);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    file = ep_dlcall0(ep_dlsym(native_system(), (long long)"tmpfile"));
    pid = 0;
    if (file != 0) {
    fd = ep_dlcall1(ep_dlsym(native_system(), (long long)"fileno"), file);
    native_fcntl_int(fd, 2, 1);
    pid = process_spawn_streams(core, ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"image-import"); append_list(_lit_list, project); append_list(_lit_list, path); _lit_list; }), fd, fd, 0, (long long)"", 0);
    if (pid == 0) {
    ep_dlcall1(ep_dlsym(native_system(), (long long)"fclose"), file);
    file = 0;
    }
    }
    ret_val = ({ long long _lit_list = create_list(); append_list(_lit_list, pid); append_list(_lit_list, file); _lit_list; });
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    return ret_val;
}

long long attachment_finish(long long db, long long project, long long file, long long code) {
    long long bytes = 0;
    long long count = 0;
    long long fd = 0;
    long long id = 0;
    long long text = 0;
    long long ret_val = 0;

    ep_gc_push_root(&bytes);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&id);
    ep_gc_push_root(&text);
    ep_gc_push_root(&db);
    ep_gc_push_root(&project);
    ep_gc_push_root(&file);

    ep_gc_maybe_collect();

    if (file == 0) {
    ret_val = pdf_error(db, (long long)"Unable to start image import");
    goto L_cleanup;
    }
    fd = ep_dlcall1(ep_dlsym(native_system(), (long long)"fileno"), file);
    bytes = alloc_bytes(4097);
    count = ep_dlcall4(ep_dlsym(native_system(), (long long)"pread"), fd, bytes, 4096, 0);
    text = (long long)"";
    if ((count > 0 && count < 4096)) {
    text = string_trim(ptr_to_str(bytes));
    }
    free_bytes(bytes);
    ep_dlcall1(ep_dlsym(native_system(), (long long)"fclose"), file);
    if (code != 0) {
    if (ep_str_equals(text, (long long)"")) {
    text = (long long)"Image import failed; try a supported still image under 8 MiB";
    }
    ret_val = pdf_error(db, text);
    goto L_cleanup;
    }
    if (transport_number(text, 10, 999999999999999999) < 1) {
    ret_val = pdf_error(db, (long long)"Image import returned an invalid attachment");
    goto L_cleanup;
    }
    id = result_cache_scalar(db, (long long)"SELECT a.memory FROM image_assets a JOIN memories m ON m.id=a.memory WHERE a.memory=? AND a.project=? AND m.project=a.project AND m.status='active'", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)text); append_list(_lit_list, project); _lit_list; }));
    if (ep_str_equals(id, (long long)"")) {
    ret_val = pdf_error(db, (long long)"Imported image is no longer available");
    goto L_cleanup;
    }
    ret_val = result_cache_scalar(db, (long long)"SELECT json_object('status','ok','memory',?)", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)id); _lit_list; }));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(7);
    return ret_val;
}

long long pdf_message(long long object, long long method) {
    long long selector = 0;
    long long ret_val = 0;

    ep_gc_push_root(&selector);
    ep_gc_push_root(&object);
    ep_gc_push_root(&method);

    ep_gc_maybe_collect();

    selector = ep_dlcall1(ep_dlsym(PDF_OBJC, (long long)"sel_registerName"), method);
    ret_val = ep_dlcall2(ep_dlsym(PDF_OBJC, (long long)"objc_msgSend"), object, selector);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long pdf_argument(long long object, long long method, long long value) {
    long long selector = 0;
    long long ret_val = 0;

    ep_gc_push_root(&selector);
    ep_gc_push_root(&object);
    ep_gc_push_root(&method);
    ep_gc_push_root(&value);

    ep_gc_maybe_collect();

    selector = ep_dlcall1(ep_dlsym(PDF_OBJC, (long long)"sel_registerName"), method);
    ret_val = ep_dlcall3(ep_dlsym(PDF_OBJC, (long long)"objc_msgSend"), object, selector, value);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long pdf_error(long long db, long long text) {
    long long params = 0;
    long long ret_val = 0;

    ep_gc_push_root(&params);
    ep_gc_push_root(&db);
    ep_gc_push_root(&text);

    ep_gc_maybe_collect();

    params = ({ long long _lit_list = create_list(); append_list(_lit_list, text); _lit_list; });
    ret_val = result_cache_scalar(db, (long long)"SELECT json_object('status','error','text',?)", params);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long pdf_snapshot(long long db, long long path) {
    long long builder = 0;
    long long byte = 0;
    long long count = 0;
    long long crypto = 0;
    long long data = 0;
    long long digest = 0;
    long long digits = 0;
    long long fd = 0;
    long long i = 0;
    long long info = 0;
    long long libc = 0;
    long long result = 0;
    long long signature = 0;
    long long size = 0;
    long long used = 0;
    long long valid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&builder);
    ep_gc_push_root(&byte);
    ep_gc_push_root(&crypto);
    ep_gc_push_root(&data);
    ep_gc_push_root(&digest);
    ep_gc_push_root(&digits);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&i);
    ep_gc_push_root(&info);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&result);
    ep_gc_push_root(&signature);
    ep_gc_push_root(&size);
    ep_gc_push_root(&used);
    ep_gc_push_root(&db);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    result = create_list();
    append_list(result, 0);
    append_list(result, 0);
    append_list(result, (long long)"");
    append_list(result, (long long)"");
    libc = native_system();
    fd = native_open(path, 16777220, 0);
    if (fd < 0) {
    set_list(result, 3, (long long)"Cannot open local PDF");
    ret_val = result;
    result = 0;
    goto L_cleanup;
    }
    info = alloc_bytes(144);
    valid = (ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info) == 0 && (native_stat_mode(info) / 4096) == 8);
    size = native_stat_size(info);
    signature = filesystem_signature(db, info);
    if ((size < 5 || size > 8388608)) {
    valid = 0;
    }
    data = 0;
    if (valid == 1) {
    data = alloc_bytes((size + 1));
    used = 0;
    while ((valid == 1 && used < size)) {
    count = ep_dlcall4(ep_dlsym(libc, (long long)"pread"), fd, (data + used), (size - used), used);
    if (count == 0) {
    valid = 0;
    } else {
    if ((count < 0 || count > (size - used))) {
    if (transport_errno(libc) != 4) {
    valid = 0;
    }
    } else {
    used = (used + count);
    }
    }
    }
    if ((ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info) != 0 || string_equals(signature, filesystem_signature(db, info)) == 0)) {
    valid = 0;
    }
    }
    ep_dlcall1(ep_dlsym(libc, (long long)"close"), fd);
    free_bytes(info);
    if (valid == 0) {
    if (data != 0) {
    free_bytes(data);
    }
    set_list(result, 3, (long long)"PDF must be a stable regular file of at most 8 MiB");
    ret_val = result;
    result = 0;
    goto L_cleanup;
    }
    digest = alloc_bytes(32);
    crypto = ep_dlopen((long long)"/usr/lib/system/libcommonCrypto.dylib");
    ep_dlcall3(ep_dlsym(crypto, (long long)"CC_SHA256"), data, size, digest);
    builder = ep_sb_create(0);
    digits = (long long)"0123456789abcdef";
    i = 0;
    while (i < 32) {
    byte = peek_byte(digest, i);
    ep_sb_append(builder, (long long)substring((char*)digits, (byte / 16), 1));
    ep_sb_append(builder, (long long)substring((char*)digits, (byte % 16), 1));
    i = (i + 1);
    }
    free_bytes(digest);
    set_list(result, 0, data);
    set_list(result, 1, size);
    set_list(result, 2, builder_to_string(builder));
    ret_val = result;
    result = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(16);
    return ret_val;
}

long long pdf_extract(long long db, long long path, long long page) {
    long long bytes = 0;
    long long captured = 0;
    long long data = 0;
    long long document = 0;
    long long framework = 0;
    long long get_class = 0;
    long long item = 0;
    long long pages = 0;
    long long pool = 0;
    long long result = 0;
    long long selector = 0;
    long long snapshot = 0;
    long long text = 0;
    long long text_object = 0;
    long long ret_val = 0;

    ep_gc_push_root(&bytes);
    ep_gc_push_root(&captured);
    ep_gc_push_root(&data);
    ep_gc_push_root(&document);
    ep_gc_push_root(&get_class);
    ep_gc_push_root(&item);
    ep_gc_push_root(&pages);
    ep_gc_push_root(&pool);
    ep_gc_push_root(&result);
    ep_gc_push_root(&selector);
    ep_gc_push_root(&snapshot);
    ep_gc_push_root(&text);
    ep_gc_push_root(&text_object);
    ep_gc_push_root(&db);
    ep_gc_push_root(&path);
    ep_gc_push_root(&page);

    ep_gc_maybe_collect();

    if ((page < 1 || page > 1000)) {
    ret_val = pdf_error(db, (long long)"PDF page must be from 1 to 1000");
    goto L_cleanup;
    }
    snapshot = pdf_snapshot(db, path);
    if (get_list(snapshot, 0) == 0) {
    ret_val = pdf_error(db, get_list(snapshot, 3));
    goto L_cleanup;
    }
    PDF_OBJC = ep_dlopen((long long)"/usr/lib/libobjc.A.dylib");
    framework = ep_dlopen((long long)"/System/Library/Frameworks/PDFKit.framework/PDFKit");
    if ((PDF_OBJC == 0 || framework == 0)) {
    free_bytes(get_list(snapshot, 0));
    ret_val = pdf_error(db, (long long)"Native PDFKit is unavailable");
    goto L_cleanup;
    }
    get_class = ep_dlsym(PDF_OBJC, (long long)"objc_getClass");
    pool = pdf_message(pdf_message(ep_dlcall1(get_class, (long long)"NSAutoreleasePool"), (long long)"alloc"), (long long)"init");
    selector = ep_dlcall1(ep_dlsym(PDF_OBJC, (long long)"sel_registerName"), (long long)"dataWithBytes:length:");
    data = ep_dlcall4(ep_dlsym(PDF_OBJC, (long long)"objc_msgSend"), ep_dlcall1(get_class, (long long)"NSData"), selector, get_list(snapshot, 0), get_list(snapshot, 1));
    free_bytes(get_list(snapshot, 0));
    document = pdf_argument(pdf_message(ep_dlcall1(get_class, (long long)"PDFDocument"), (long long)"alloc"), (long long)"initWithData:", data);
    result = pdf_error(db, (long long)"Cannot parse PDF document");
    if (document != 0) {
    pages = pdf_message(document, (long long)"pageCount");
    if ((pdf_message(document, (long long)"isLocked") % 256) != 0) {
    result = pdf_error(db, (long long)"PDF is encrypted and locked");
    } else {
    if (page > pages) {
    result = pdf_error(db, (long long)"Requested page is beyond the PDF page count");
    } else {
    item = pdf_argument(document, (long long)"pageAtIndex:", (page - 1));
    text_object = pdf_message(item, (long long)"string");
    text = (long long)"";
    if (text_object != 0) {
    bytes = pdf_message(text_object, (long long)"UTF8String");
    if (bytes != 0) {
    text = ptr_to_str(bytes);
    }
    }
    captured = result_cache_scalar(db, (long long)"SELECT substr(?,1,20000)", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)text); _lit_list; }));
    result = result_cache_scalar(db, (long long)"SELECT json_object('status','ok','page',CAST(? AS INTEGER),'pages',CAST(? AS INTEGER),'text',?,'capture_truncated',json(CASE WHEN length(?)>20000 THEN 'true' ELSE 'false' END),'text_status',CASE WHEN length(trim(?))=0 THEN 'no_extractable_text' ELSE 'text' END,'source_sha256',?,'parser_version','macOS PDFKit via EP')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)int_to_string(page)); append_list(_lit_list, (long long)int_to_string(pages)); append_list(_lit_list, (long long)captured); append_list(_lit_list, (long long)text); append_list(_lit_list, (long long)captured); append_list(_lit_list, get_list(snapshot, 2)); _lit_list; }));
    }
    }
    pdf_message(document, (long long)"release");
    }
    pdf_message(pool, (long long)"drain");
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(16);
    free_list(snapshot);
    snapshot = 0;
    return ret_val;
}

long long filesystem_error(long long db, long long name, long long message) {
    long long params = 0;
    long long ret_val = 0;

    ep_gc_push_root(&params);
    ep_gc_push_root(&db);
    ep_gc_push_root(&name);
    ep_gc_push_root(&message);

    ep_gc_maybe_collect();

    params = ({ long long _lit_list = create_list(); append_list(_lit_list, name); append_list(_lit_list, message); _lit_list; });
    ret_val = result_cache_scalar(db, (long long)"SELECT json_object('status','ok','tool',?,'outcome','failed','text',?,'cache_hit',json('false'))", params);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long filesystem_signature(long long db, long long info) {
    long long i = 0;
    long long offsets = 0;
    long long parts = 0;
    long long width = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&offsets);
    ep_gc_push_root(&parts);
    ep_gc_push_root(&width);
    ep_gc_push_root(&db);
    ep_gc_push_root(&info);

    ep_gc_maybe_collect();

    parts = create_list();
    offsets = ({ long long _lit_list = create_list(); append_list(_lit_list, 0); append_list(_lit_list, 8); append_list(_lit_list, 96); append_list(_lit_list, 48); append_list(_lit_list, 56); append_list(_lit_list, 64); append_list(_lit_list, 72); _lit_list; });
    i = 0;
    while (i < length_list(offsets)) {
    width = 8;
    if (i == 0) {
    width = 4;
    }
    append_list(parts, int_to_string(lease_integer(info, get_list(offsets, i), width)));
    i = (i + 1);
    }
    ret_val = result_cache_scalar(db, (long long)"SELECT json_array(?,?,?,?,?,?,?)", parts);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(6);
    free_list(offsets);
    offsets = 0;
    return ret_val;
}

long long filesystem_uri(long long path) {
    long long alphabet = 0;
    long long byte = 0;
    long long i = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&alphabet);
    ep_gc_push_root(&byte);
    ep_gc_push_root(&i);
    ep_gc_push_root(&result);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    result = (long long)"file://";
    alphabet = (long long)"0123456789ABCDEF";
    i = 0;
    while (i < string_length((char*)path)) {
    byte = get_character((char*)path, i);
    if (((((((((byte >= 48 && byte <= 57) || (byte >= 65 && byte <= 90)) || (byte >= 97 && byte <= 122)) || byte == 47) || byte == 45) || byte == 46) || byte == 95) || byte == 126)) {
    result = concat(result, (long long)substring((char*)path, i, 1));
    } else {
    result = concat(result, (long long)"%");
    result = concat(result, (long long)substring((char*)alphabet, (byte / 16), 1));
    result = concat(result, (long long)substring((char*)alphabet, (byte % 16), 1));
    }
    i = (i + 1);
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long filesystem_partial_utf8(long long data, long long start, long long count) {
    long long byte = 0;
    long long i = 0;
    long long lead = 0;
    long long width = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&data);
    ep_gc_push_root(&start);

    ep_gc_maybe_collect();

    lead = peek_byte(data, start);
    width = 0;
    if ((lead >= 194 && lead <= 223)) {
    width = 2;
    } else {
    if ((lead >= 224 && lead <= 239)) {
    width = 3;
    } else {
    if ((lead >= 240 && lead <= 244)) {
    width = 4;
    }
    }
    }
    if ((width == 0 || count >= width)) {
    ret_val = 0;
    goto L_cleanup;
    }
    i = 1;
    while (i < count) {
    byte = peek_byte(data, (start + i));
    if ((byte < 128 || byte > 191)) {
    ret_val = 0;
    goto L_cleanup;
    }
    if (i == 1) {
    if (((((lead == 224 && byte < 160) || (lead == 237 && byte > 159)) || (lead == 240 && byte < 144)) || (lead == 244 && byte > 143))) {
    ret_val = 0;
    goto L_cleanup;
    }
    }
    i = (i + 1);
    }
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long filesystem_read(long long db, long long path, long long offset) {
    long long before = 0;
    long long consumed = 0;
    long long data = 0;
    long long fd = 0;
    long long info = 0;
    long long libc = 0;
    long long next = 0;
    long long problem = 0;
    long long read_status = 0;
    long long result = 0;
    long long size = 0;
    long long text = 0;
    long long trim = 0;
    long long used = 0;
    long long valid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&before);
    ep_gc_push_root(&consumed);
    ep_gc_push_root(&data);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&info);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&next);
    ep_gc_push_root(&problem);
    ep_gc_push_root(&read_status);
    ep_gc_push_root(&result);
    ep_gc_push_root(&size);
    ep_gc_push_root(&text);
    ep_gc_push_root(&trim);
    ep_gc_push_root(&db);
    ep_gc_push_root(&path);
    ep_gc_push_root(&offset);

    ep_gc_maybe_collect();

    libc = native_system();
    fd = native_open(path, 16777220, 0);
    if ((fd < 0 || fd > 2147483647)) {
    ret_val = filesystem_error(db, (long long)"file_read", (long long)"Cannot open the requested local file");
    goto L_cleanup;
    }
    info = alloc_bytes(144);
    problem = (long long)"";
    before = (long long)"";
    size = 0;
    if (ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info) != 0) {
    problem = (long long)"Cannot inspect the opened file";
    } else {
    if ((native_stat_mode(info) / 4096) != 8) {
    problem = (long long)"Only regular text files can be read";
    } else {
    before = filesystem_signature(db, info);
    size = native_stat_size(info);
    if (offset > size) {
    problem = (long long)"Offset is beyond the file end";
    }
    }
    }
    data = alloc_bytes(4097);
    used = 0;
    if (ep_str_equals(problem, (long long)"")) {
    used = ep_dlcall4(ep_dlsym(libc, (long long)"pread"), fd, data, 4096, offset);
    if ((used < 0 || used > 4096)) {
    problem = (long long)"File read failed";
    } else {
    if (ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info) != 0) {
    problem = (long long)"Cannot verify the file after reading";
    } else {
    if (string_equals(before, filesystem_signature(db, info)) == 0) {
    problem = (long long)"File changed during reading; retry";
    }
    }
    }
    }
    ep_dlcall1(ep_dlsym(libc, (long long)"close"), fd);
    free_bytes(info);
    consumed = used;
    if (ep_str_equals(problem, (long long)"")) {
    valid = document_utf8(data, consumed);
    if ((valid == 0 && (offset + used) < size)) {
    trim = 1;
    while (((trim <= 3 && trim <= used) && valid == 0)) {
    consumed = (used - trim);
    valid = (document_utf8(data, consumed) && filesystem_partial_utf8(data, consumed, trim));
    trim = (trim + 1);
    }
    }
    if (valid == 0) {
    problem = (long long)"The requested page is not UTF-8 text, contains binary data, or starts inside a character";
    }
    }
    result = (long long)"";
    if (ep_str_equals(problem, (long long)"")) {
    poke_byte(data, consumed, 0);
    text = ptr_to_str(data);
    next = (offset + consumed);
    read_status = (long long)"Read completed; all remaining file content returned";
    if (next < size) {
    read_status = (long long)"More bytes remain; continue using next_offset if needed";
    } else {
    if ((consumed == 0 && offset > 0)) {
    read_status = (long long)"End of file reached; earlier pages remain valid";
    }
    }
    result = result_cache_scalar(db, (long long)"SELECT json_object('text',?,'read_status',?,'offset',CAST(? AS INTEGER),'next_offset',CAST(? AS INTEGER),'total_bytes',CAST(? AS INTEGER),'truncated',json(CASE WHEN CAST(? AS INTEGER)<CAST(? AS INTEGER) THEN 'true' ELSE 'false' END),'page_sha256',?,'file_signature',json(?))", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)text); append_list(_lit_list, (long long)read_status); append_list(_lit_list, (long long)int_to_string(offset)); append_list(_lit_list, (long long)int_to_string(next)); append_list(_lit_list, (long long)int_to_string(size)); append_list(_lit_list, (long long)int_to_string(next)); append_list(_lit_list, (long long)int_to_string(size)); append_list(_lit_list, (long long)sha256(text)); append_list(_lit_list, (long long)before); _lit_list; }));
    } else {
    result = filesystem_error(db, (long long)"file_read", problem);
    }
    free_bytes(data);
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(16);
    return ret_val;
}

long long filesystem_list(long long db, long long path, long long after) {
    long long before = 0;
    long long count = 0;
    long long directory = 0;
    long long ended = 0;
    long long entry = 0;
    long long errno_pointer = 0;
    long long fd = 0;
    long long info = 0;
    long long libc = 0;
    long long name = 0;
    long long names = 0;
    long long problem = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&before);
    ep_gc_push_root(&directory);
    ep_gc_push_root(&entry);
    ep_gc_push_root(&errno_pointer);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&info);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&name);
    ep_gc_push_root(&names);
    ep_gc_push_root(&problem);
    ep_gc_push_root(&result);
    ep_gc_push_root(&db);
    ep_gc_push_root(&path);
    ep_gc_push_root(&after);

    ep_gc_maybe_collect();

    libc = native_system();
    directory = ep_dlcall1(ep_dlsym(libc, (long long)"opendir"), path);
    if (directory == 0) {
    ret_val = filesystem_error(db, (long long)"file_list", (long long)"Cannot open the requested directory");
    goto L_cleanup;
    }
    fd = ep_dlcall1(ep_dlsym(libc, (long long)"dirfd"), directory);
    info = alloc_bytes(144);
    before = (long long)"";
    problem = (long long)"";
    if (ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info) != 0) {
    problem = (long long)"Cannot inspect the opened directory";
    } else {
    before = filesystem_signature(db, info);
    }
    ep_sqlite3_exec(db, (long long)"CREATE TEMP TABLE IF NOT EXISTS ep_directory_page(name TEXT PRIMARY KEY COLLATE BINARY); DELETE FROM ep_directory_page;", 0, 0, 0);
    count = 0;
    ended = 0;
    errno_pointer = native_errno_pointer();
    while ((ended == 0 && ep_str_equals(problem, (long long)""))) {
    native_bytes_write(errno_pointer, 0, 0, 4);
    entry = ep_dlcall1(ep_dlsym(libc, (long long)"readdir"), directory);
    if (entry == 0) {
    ended = 1;
    if (lease_integer(errno_pointer, 0, 4) != 0) {
    problem = (long long)"Directory scan failed; retry";
    }
    } else {
    name = native_dirent_name(entry);
    if (((!ep_str_equals(name, (long long)".")) && (!ep_str_equals(name, (long long)"..")))) {
    count = (count + 1);
    if (count > 10000) {
    problem = (long long)"Directory exceeds the 10,000-entry scan budget; choose a narrower directory";
    } else {
    if (document_utf8(str_to_ptr(name), string_length((char*)name)) == 0) {
    problem = (long long)"Directory contains a name that is not valid UTF-8";
    } else {
    sql_execute_params(db, (long long)"INSERT OR IGNORE INTO ep_directory_page SELECT ? WHERE ?>? COLLATE BINARY", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)name); append_list(_lit_list, (long long)name); append_list(_lit_list, after); _lit_list; }));
    ep_sqlite3_exec(db, (long long)"DELETE FROM ep_directory_page WHERE name NOT IN(SELECT name FROM ep_directory_page ORDER BY name LIMIT 31)", 0, 0, 0);
    }
    }
    }
    }
    }
    if (ep_str_equals(problem, (long long)"")) {
    if (ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info) != 0) {
    problem = (long long)"Cannot verify the directory after listing";
    } else {
    if (string_equals(before, filesystem_signature(db, info)) == 0) {
    problem = (long long)"Directory changed during listing; retry";
    }
    }
    }
    free_bytes(info);
    ep_dlcall1(ep_dlsym(libc, (long long)"closedir"), directory);
    result = (long long)"";
    if (ep_str_equals(problem, (long long)"")) {
    names = result_cache_scalar(db, (long long)"SELECT json_group_array(name) FROM (SELECT name FROM ep_directory_page ORDER BY name LIMIT 30)", ({ long long _lit_list = create_list(); _lit_list; }));
    if (string_length((char*)names) > 8000) {
    problem = (long long)"Directory page exceeds the receipt budget";
    } else {
    result = result_cache_scalar(db, (long long)"SELECT json_object('text',?,'names',json(?),'next_after',CASE WHEN (SELECT count(*) FROM ep_directory_page)>30 THEN (SELECT name FROM ep_directory_page ORDER BY name LIMIT 1 OFFSET 29) ELSE NULL END,'truncated',json(CASE WHEN (SELECT count(*) FROM ep_directory_page)>30 THEN 'true' ELSE 'false' END),'directory_signature',json(?))", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)names); append_list(_lit_list, (long long)names); append_list(_lit_list, (long long)before); _lit_list; }));
    }
    }
    ep_sqlite3_exec(db, (long long)"DELETE FROM ep_directory_page", 0, 0, 0);
    if ((!ep_str_equals(problem, (long long)""))) {
    ret_val = filesystem_error(db, (long long)"file_list", problem);
    goto L_cleanup;
    }
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(14);
    return ret_val;
}

long long filesystem_lookup(long long db, long long name, long long expression, long long epoch) {
    long long after = 0;
    long long field = 0;
    long long found = 0;
    long long hit = 0;
    long long observed = 0;
    long long offset = 0;
    long long path = 0;
    long long request = 0;
    long long resolved = 0;
    long long result = 0;
    long long valid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&after);
    ep_gc_push_root(&field);
    ep_gc_push_root(&hit);
    ep_gc_push_root(&observed);
    ep_gc_push_root(&offset);
    ep_gc_push_root(&path);
    ep_gc_push_root(&request);
    ep_gc_push_root(&resolved);
    ep_gc_push_root(&result);
    ep_gc_push_root(&valid);
    ep_gc_push_root(&db);
    ep_gc_push_root(&name);
    ep_gc_push_root(&expression);
    ep_gc_push_root(&epoch);

    ep_gc_maybe_collect();

    if (((!ep_str_equals(name, (long long)"file_read")) && (!ep_str_equals(name, (long long)"file_list")))) {
    ret_val = filesystem_error(db, name, (long long)"Unsupported filesystem operation");
    goto L_cleanup;
    }
    if ((!ep_str_equals(result_cache_scalar(db, (long long)"SELECT json_valid(?)", ({ long long _lit_list = create_list(); append_list(_lit_list, expression); _lit_list; })), (long long)"1"))) {
    ret_val = filesystem_error(db, name, (long long)"File arguments must be JSON");
    goto L_cleanup;
    }
    field = (long long)"offset";
    if (ep_str_equals(name, (long long)"file_list")) {
    field = (long long)"after";
    }
    valid = result_cache_scalar(db, (long long)"SELECT json_type(?)='object' AND (SELECT count(*) FROM json_each(?))=2 AND (SELECT count(DISTINCT key) FROM json_each(?))=2 AND json_type(?,'$.path')='text' AND length(json_extract(?,'$.path')) BETWEEN 1 AND 1024 AND instr(json_extract(?,'$.path'),char(0))=0 AND json_type(?,'$.'||?) IS NOT NULL", ({ long long _lit_list = create_list(); append_list(_lit_list, expression); append_list(_lit_list, expression); append_list(_lit_list, expression); append_list(_lit_list, expression); append_list(_lit_list, expression); append_list(_lit_list, expression); append_list(_lit_list, expression); append_list(_lit_list, (long long)field); _lit_list; }));
    if ((!ep_str_equals(valid, (long long)"1"))) {
    ret_val = filesystem_error(db, name, (long long)"Invalid filesystem argument fields or path");
    goto L_cleanup;
    }
    path = result_cache_scalar(db, (long long)"SELECT json_extract(?,'$.path')", ({ long long _lit_list = create_list(); append_list(_lit_list, expression); _lit_list; }));
    if (starts_with(path, (long long)"~/")) {
    path = concat(get_env((long long)"HOME"), (long long)substring((char*)path, 1, (string_length((char*)path) - 1)));
    }
    if (starts_with(path, (long long)"/") == 0) {
    ret_val = filesystem_error(db, name, (long long)"Use an absolute file path");
    goto L_cleanup;
    }
    resolved = alloc_bytes(4096);
    found = ep_dlcall2(ep_dlsym(native_system(), (long long)"realpath"), path, resolved);
    if (found == 0) {
    free_bytes(resolved);
    ret_val = filesystem_error(db, name, (long long)"Requested path does not exist or cannot be resolved");
    goto L_cleanup;
    }
    path = ptr_to_str(resolved);
    free_bytes(resolved);
    observed = (long long)"";
    if (ep_str_equals(name, (long long)"file_read")) {
    if ((!ep_str_equals(result_cache_scalar(db, (long long)"SELECT json_type(?,'$.offset')='integer' AND json_extract(?,'$.offset') BETWEEN 0 AND 9007199254740992", ({ long long _lit_list = create_list(); append_list(_lit_list, expression); append_list(_lit_list, expression); _lit_list; })), (long long)"1"))) {
    ret_val = filesystem_error(db, name, (long long)"Offset must be a nonnegative integer byte position");
    goto L_cleanup;
    }
    offset = string_to_int(result_cache_scalar(db, (long long)"SELECT json_extract(?,'$.offset')", ({ long long _lit_list = create_list(); append_list(_lit_list, expression); _lit_list; })));
    observed = filesystem_read(db, path, offset);
    } else {
    if ((!ep_str_equals(result_cache_scalar(db, (long long)"SELECT json_type(?,'$.after')='text' AND length(json_extract(?,'$.after'))<=1024 AND instr(json_extract(?,'$.after'),char(0))=0", ({ long long _lit_list = create_list(); append_list(_lit_list, expression); append_list(_lit_list, expression); append_list(_lit_list, expression); _lit_list; })), (long long)"1"))) {
    ret_val = filesystem_error(db, name, (long long)"Invalid directory cursor");
    goto L_cleanup;
    }
    after = result_cache_scalar(db, (long long)"SELECT json_extract(?,'$.after')", ({ long long _lit_list = create_list(); append_list(_lit_list, expression); _lit_list; }));
    observed = filesystem_list(db, path, after);
    }
    if (ep_str_equals(result_cache_scalar(db, (long long)"SELECT COALESCE(json_extract(?,'$.outcome'),'')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)observed); _lit_list; })), (long long)"failed")) {
    ret_val = observed;
    goto L_cleanup;
    }
    request = result_cache_scalar(db, (long long)"SELECT json_array(?,?,json(?))", ({ long long _lit_list = create_list(); append_list(_lit_list, name); append_list(_lit_list, expression); append_list(_lit_list, (long long)observed); _lit_list; }));
    hit = result_cache_get(db, (long long)"ep-filesystem-v1", request, epoch);
    if ((!ep_str_equals(hit, (long long)""))) {
    if ((!ep_str_equals(result_cache_scalar(db, (long long)"SELECT json_extract(?,'$.status')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)hit); _lit_list; })), (long long)"ok"))) {
    ret_val = hit;
    goto L_cleanup;
    }
    ret_val = result_cache_scalar(db, (long long)"SELECT json_set(?,'$.cache_hit',json('true'))", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)hit); _lit_list; }));
    goto L_cleanup;
    }
    result = result_cache_scalar(db, (long long)"SELECT json_patch(json_object('status','ok','tool',?,'outcome','completed','path',?,'entries',json_array(json_object('url',?)),'cache_hit',json('false')),json(?))", ({ long long _lit_list = create_list(); append_list(_lit_list, name); append_list(_lit_list, (long long)path); append_list(_lit_list, (long long)filesystem_uri(path)); append_list(_lit_list, (long long)observed); _lit_list; }));
    if (string_length((char*)result) > 14000) {
    ret_val = filesystem_error(db, name, (long long)"Filesystem receipt exceeds its byte budget");
    goto L_cleanup;
    }
    ret_val = result_cache_put(db, (long long)"ep-filesystem-v1", request, epoch, result);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(14);
    return ret_val;
}

long long lease_error(long long message) {
    long long fields = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fields);
    ep_gc_push_root(&result);
    ep_gc_push_root(&message);

    ep_gc_maybe_collect();

    fields = ({ long long _lit_list = create_list(); append_list(_lit_list, create_json_string((long long)"error")); append_list(_lit_list, create_json_string(message)); _lit_list; });
    result = json_stringify(create_json_object(({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"status"); append_list(_lit_list, (long long)(long long)"text"); _lit_list; }), fields));
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    free_list(fields);
    fields = 0;
    return ret_val;
}

long long lease_integer(long long pointer, long long offset, long long count) {
    long long i = 0;
    long long value = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&pointer);
    ep_gc_push_root(&offset);

    ep_gc_maybe_collect();

    value = 0;
    i = (count - 1);
    while (i >= 0) {
    value = ((value * 256) + peek_byte(pointer, (offset + i)));
    i = (i - 1);
    }
    ret_val = value;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long private_lock(long long home, long long name) {
    long long canonical = 0;
    long long fd = 0;
    long long info = 0;
    long long libc = 0;
    long long links = 0;
    long long mode = 0;
    long long owner = 0;
    long long path = 0;
    long long rc = 0;
    long long resolved = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&canonical);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&info);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&path);
    ep_gc_push_root(&resolved);
    ep_gc_push_root(&home);
    ep_gc_push_root(&name);

    ep_gc_maybe_collect();

    libc = native_system();
    resolved = alloc_bytes(1024);
    result = ep_dlcall2(ep_dlsym(libc, (long long)"realpath"), home, resolved);
    if (result == 0) {
    free_bytes(resolved);
    ret_val = -1;
    goto L_cleanup;
    }
    canonical = ptr_to_str(resolved);
    free_bytes(resolved);
    path = concat(canonical, concat((long long)"/", name));
    if (string_length((char*)path) >= 1024) {
    ret_val = -1;
    goto L_cleanup;
    }
    libc = native_system();
    fd = native_open(path, 16777990, 384);
    if ((fd < 0 || fd > 2147483647)) {
    ret_val = -1;
    goto L_cleanup;
    }
    info = alloc_bytes(144);
    rc = ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info);
    mode = lease_integer(info, 4, 2);
    links = lease_integer(info, 6, 2);
    owner = lease_integer(info, 16, 4);
    if (native_android()) {
    mode = lease_integer(info, 16, 4);
    links = lease_integer(info, 20, 4);
    owner = lease_integer(info, 24, 4);
    }
    free_bytes(info);
    if ((((rc != 0 || (mode / 4096) != 8) || links != 1) || owner != ep_dlcall0(ep_dlsym(libc, (long long)"getuid")))) {
    ep_dlcall1(ep_dlsym(libc, (long long)"close"), fd);
    ret_val = -1;
    goto L_cleanup;
    }
    if (ep_dlcall2(ep_dlsym(libc, (long long)"fchmod"), fd, 384) != 0) {
    ep_dlcall1(ep_dlsym(libc, (long long)"close"), fd);
    ret_val = -1;
    goto L_cleanup;
    }
    ret_val = fd;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long state_lease(long long home, long long mode) {
    long long close_fn = 0;
    long long errno_ptr = 0;
    long long error_number = 0;
    long long fd = 0;
    long long flags = 0;
    long long info = 0;
    long long libc = 0;
    long long marker = 0;
    long long rc = 0;
    long long worker = 0;
    long long ret_val = 0;

    ep_gc_push_root(&close_fn);
    ep_gc_push_root(&errno_ptr);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&flags);
    ep_gc_push_root(&info);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&marker);
    ep_gc_push_root(&worker);
    ep_gc_push_root(&home);

    ep_gc_maybe_collect();

    if (((!ep_str_equals(mode, (long long)"shared")) && (!ep_str_equals(mode, (long long)"maintenance")))) {
    ret_val = lease_error((long long)"Invalid state lease request");
    goto L_cleanup;
    }
    if (STATE_LEASE_FD >= 0) {
    ret_val = lease_error((long long)"State lease already acquired in this process");
    goto L_cleanup;
    }
    libc = native_system();
    close_fn = ep_dlsym(libc, (long long)"close");
    fd = private_lock(home, (long long)"state.lock");
    if (fd < 0) {
    ret_val = lease_error((long long)"Cannot open private regular state lock");
    goto L_cleanup;
    }
    flags = 5;
    if (ep_str_equals(mode, (long long)"maintenance")) {
    flags = 6;
    }
    if (ep_dlcall2(ep_dlsym(libc, (long long)"flock"), fd, flags) != 0) {
    ep_dlcall1(close_fn, fd);
    ret_val = lease_error((long long)"State is busy with another command or offline maintenance");
    goto L_cleanup;
    }
    if (ep_str_equals(mode, (long long)"shared")) {
    marker = concat(home, (long long)"/.restore.pending");
    if (string_length((char*)marker) >= 1024) {
    ep_dlcall1(close_fn, fd);
    ret_val = lease_error((long long)"State path is too long");
    goto L_cleanup;
    }
    info = alloc_bytes(144);
    rc = ep_dlcall2(ep_dlsym(libc, (long long)"lstat"), marker, info);
    errno_ptr = native_errno_pointer();
    error_number = lease_integer(errno_ptr, 0, 4);
    free_bytes(info);
    if ((rc == 0 || error_number != 2)) {
    ep_dlcall1(close_fn, fd);
    ret_val = lease_error((long long)"Interrupted restore; rerun backup-restore with the original backup ID");
    goto L_cleanup;
    }
    } else {
    worker = private_lock(home, (long long)"worker.lock");
    if (worker < 0) {
    ep_dlcall1(close_fn, fd);
    ret_val = lease_error((long long)"Cannot open private regular worker lock");
    goto L_cleanup;
    }
    if (ep_dlcall2(ep_dlsym(libc, (long long)"flock"), worker, 6) != 0) {
    ep_dlcall1(close_fn, worker);
    ep_dlcall1(close_fn, fd);
    ret_val = lease_error((long long)"Stop the model worker before offline maintenance");
    goto L_cleanup;
    }
    WORKER_LEASE_FD = worker;
    }
    STATE_LEASE_FD = fd;
    ret_val = (long long)"{\"status\":\"ok\"}";
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    return ret_val;
}

long long native_stat_mode(long long info) {
    long long ret_val = 0;

    ep_gc_push_root(&info);

    ep_gc_maybe_collect();

    if (native_android()) {
    ret_val = lease_integer(info, 16, 4);
    goto L_cleanup;
    }
    ret_val = lease_integer(info, 4, 2);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long native_stat_links(long long info) {
    long long ret_val = 0;

    ep_gc_push_root(&info);

    ep_gc_maybe_collect();

    if (native_android()) {
    ret_val = lease_integer(info, 20, 4);
    goto L_cleanup;
    }
    ret_val = lease_integer(info, 6, 2);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long native_stat_owner(long long info) {
    long long ret_val = 0;

    ep_gc_push_root(&info);

    ep_gc_maybe_collect();

    if (native_android()) {
    ret_val = lease_integer(info, 24, 4);
    goto L_cleanup;
    }
    ret_val = lease_integer(info, 16, 4);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long native_stat_size(long long info) {
    long long ret_val = 0;

    ep_gc_push_root(&info);

    ep_gc_maybe_collect();

    if (native_android()) {
    ret_val = lease_integer(info, 48, 8);
    goto L_cleanup;
    }
    ret_val = lease_integer(info, 96, 8);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long native_stat_time(long long info, long long darwin_offset) {
    long long ret_val = 0;

    ep_gc_push_root(&info);
    ep_gc_push_root(&darwin_offset);

    ep_gc_maybe_collect();

    if (native_android()) {
    ret_val = lease_integer(info, (darwin_offset + 40), 8);
    goto L_cleanup;
    }
    ret_val = lease_integer(info, darwin_offset, 8);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long native_available_bytes(long long info) {
    long long ret_val = 0;

    ep_gc_push_root(&info);

    ep_gc_maybe_collect();

    if (native_android()) {
    ret_val = (lease_integer(info, 32, 8) * lease_integer(info, 8, 8));
    goto L_cleanup;
    }
    ret_val = (lease_integer(info, 24, 4) * lease_integer(info, 8, 8));
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long document_error(long long reason) {
    long long fields = 0;
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&fields);
    ep_gc_push_root(&result);
    ep_gc_push_root(&reason);

    ep_gc_maybe_collect();

    fields = ({ long long _lit_list = create_list(); append_list(_lit_list, create_json_string((long long)"error")); append_list(_lit_list, create_json_string(reason)); _lit_list; });
    result = json_stringify(create_json_object(({ long long _lit_list = create_list(); append_list(_lit_list, (long long)(long long)"status"); append_list(_lit_list, (long long)(long long)"text"); _lit_list; }), fields));
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    free_list(fields);
    fields = 0;
    return ret_val;
}

long long document_utf8(long long data, long long count) {
    long long c = 0;
    long long code = 0;
    long long i = 0;
    long long minimum = 0;
    long long more = 0;
    long long next = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&data);

    ep_gc_maybe_collect();

    i = 0;
    while (i < count) {
    c = peek_byte(data, i);
    i = (i + 1);
    if (c == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    if (c >= 128) {
    more = 0;
    minimum = 0;
    code = 0;
    if ((c >= 194 && c <= 223)) {
    more = 1;
    minimum = 128;
    code = (c % 32);
    } else {
    if ((c >= 224 && c <= 239)) {
    more = 2;
    minimum = 2048;
    code = (c % 16);
    } else {
    if ((c >= 240 && c <= 244)) {
    more = 3;
    minimum = 65536;
    code = (c % 8);
    } else {
    ret_val = 0;
    goto L_cleanup;
    }
    }
    }
    if (more > (count - i)) {
    ret_val = 0;
    goto L_cleanup;
    }
    while (more > 0) {
    next = peek_byte(data, i);
    if ((next < 128 || next > 191)) {
    ret_val = 0;
    goto L_cleanup;
    }
    code = ((code * 64) + (next % 64));
    i = (i + 1);
    more = (more - 1);
    }
    if (((code < minimum || code > 1114111) || (code >= 55296 && code <= 57343))) {
    ret_val = 0;
    goto L_cleanup;
    }
    }
    }
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long read_document(long long path) {
    long long body = 0;
    long long close_fn = 0;
    long long data = 0;
    long long errno_ptr = 0;
    long long fd = 0;
    long long i = 0;
    long long info = 0;
    long long libc = 0;
    long long mode = 0;
    long long n = 0;
    long long problem = 0;
    long long rc = 0;
    long long read_fn = 0;
    long long reading = 0;
    long long size = 0;
    long long used = 0;
    long long ret_val = 0;

    ep_gc_push_root(&body);
    ep_gc_push_root(&close_fn);
    ep_gc_push_root(&data);
    ep_gc_push_root(&errno_ptr);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&i);
    ep_gc_push_root(&info);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&problem);
    ep_gc_push_root(&read_fn);
    ep_gc_push_root(&used);
    ep_gc_push_root(&path);

    ep_gc_maybe_collect();

    if ((string_length((char*)path) == 0 || (!ep_str_equals((long long)substring((char*)path, 0, 1), (long long)"/")))) {
    ret_val = document_error((long long)"Document path must be absolute");
    goto L_cleanup;
    }
    libc = ep_dlopen((long long)"/usr/lib/libSystem.B.dylib");
    close_fn = ep_dlsym(libc, (long long)"close");
    fd = ep_dlcall2(ep_dlsym(libc, (long long)"open"), path, 16777220);
    if ((fd < 0 || fd > 2147483647)) {
    ret_val = document_error((long long)"Cannot open local document");
    goto L_cleanup;
    }
    info = alloc_bytes(144);
    rc = ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info);
    mode = (peek_byte(info, 4) + (peek_byte(info, 5) * 256));
    size = 0;
    i = 7;
    while (i >= 0) {
    size = ((size * 256) + peek_byte(info, (96 + i)));
    i = (i - 1);
    }
    free_bytes(info);
    if ((rc != 0 || (mode / 4096) != 8)) {
    ep_dlcall1(close_fn, fd);
    ret_val = document_error((long long)"Document must be a regular file");
    goto L_cleanup;
    }
    if ((size < 0 || size > 8388608)) {
    ep_dlcall1(close_fn, fd);
    ret_val = document_error((long long)"Document exceeds 8 MiB byte limit");
    goto L_cleanup;
    }
    data = alloc_bytes(8388610);
    if (data == 0) {
    ep_dlcall1(close_fn, fd);
    ret_val = document_error((long long)"Allocation failed");
    goto L_cleanup;
    }
    used = 0;
    reading = 1;
    problem = (long long)"";
    read_fn = ep_dlsym(libc, (long long)"read");
    while ((reading == 1 && used <= 8388608)) {
    n = ep_dlcall3(read_fn, fd, (data + used), (8388609 - used));
    if (n < 0) {
    errno_ptr = native_errno_pointer();
    if (peek_byte(errno_ptr, 0) != 4) {
    problem = (long long)"Document read failed";
    reading = 0;
    }
    } else {
    if (n == 0) {
    reading = 0;
    } else {
    used = (used + n);
    }
    }
    }
    ep_dlcall1(close_fn, fd);
    if (used > 8388608) {
    problem = (long long)"Document grew beyond 8 MiB byte limit";
    }
    if ((ep_str_equals(problem, (long long)"") && document_utf8(data, used) == 0)) {
    problem = (long long)"Document must be UTF-8 text without NUL bytes";
    }
    if ((!ep_str_equals(problem, (long long)""))) {
    free_bytes(data);
    ret_val = document_error(problem);
    goto L_cleanup;
    }
    poke_byte(data, used, 0);
    body = ptr_to_str(data);
    free_bytes(data);
    ret_val = concat((long long)"OK\n", body);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(12);
    return ret_val;
}

long long snapshot_hex(long long text, long long count) {
    long long byte = 0;
    long long i = 0;
    long long ret_val = 0;

    ep_gc_push_root(&i);
    ep_gc_push_root(&text);

    ep_gc_maybe_collect();

    if (string_length((char*)text) != count) {
    ret_val = 0;
    goto L_cleanup;
    }
    i = 0;
    while (i < count) {
    byte = get_character((char*)text, i);
    if (((byte < 48 || byte > 57) && (byte < 97 || byte > 102))) {
    ret_val = 0;
    goto L_cleanup;
    }
    i = (i + 1);
    }
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long snapshot_name(long long name) {
    long long ret_val = 0;

    ep_gc_push_root(&name);

    ep_gc_maybe_collect();

    if ((((ep_str_equals(name, (long long)"") || string_length((char*)name) > 88) || string_contains(name, (long long)"/")) || string_contains(name, (long long)".."))) {
    ret_val = 0;
    goto L_cleanup;
    }
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long snapshot_private(long long fd, long long info) {
    long long libc = 0;
    long long ret_val = 0;

    ep_gc_push_root(&libc);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&info);

    ep_gc_maybe_collect();

    libc = native_system();
    if (ep_dlcall2(ep_dlsym(libc, (long long)"fstat"), fd, info) != 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    if (((((native_stat_mode(info) / 4096) != 8 || native_stat_owner(info) != ep_dlcall0(ep_dlsym(libc, (long long)"getuid"))) || native_stat_links(info) != 1) || (native_stat_mode(info) % 64) != 0)) {
    ret_val = 0;
    goto L_cleanup;
    }
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long snapshot_hash(long long directory, long long name) {
    long long after = 0;
    long long before = 0;
    long long buffer = 0;
    long long builder = 0;
    long long byte = 0;
    long long bytes = 0;
    long long crypto = 0;
    long long crypto_path = 0;
    long long ctx = 0;
    long long deadline = 0;
    long long digest = 0;
    long long digits = 0;
    long long fd = 0;
    long long field = 0;
    long long final_name = 0;
    long long finished = 0;
    long long i = 0;
    long long init_name = 0;
    long long libc = 0;
    long long output = 0;
    long long total = 0;
    long long update_name = 0;
    long long valid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&after);
    ep_gc_push_root(&before);
    ep_gc_push_root(&buffer);
    ep_gc_push_root(&builder);
    ep_gc_push_root(&byte);
    ep_gc_push_root(&bytes);
    ep_gc_push_root(&crypto);
    ep_gc_push_root(&crypto_path);
    ep_gc_push_root(&ctx);
    ep_gc_push_root(&digest);
    ep_gc_push_root(&digits);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&field);
    ep_gc_push_root(&final_name);
    ep_gc_push_root(&i);
    ep_gc_push_root(&init_name);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&output);
    ep_gc_push_root(&update_name);
    ep_gc_push_root(&directory);
    ep_gc_push_root(&name);

    ep_gc_maybe_collect();

    if (snapshot_name(name) == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    fd = native_openat(directory, name, 16777476, 0);
    if (fd < 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    libc = native_system();
    crypto_path = (long long)"/usr/lib/system/libcommonCrypto.dylib";
    init_name = (long long)"CC_SHA256_Init";
    update_name = (long long)"CC_SHA256_Update";
    final_name = (long long)"CC_SHA256_Final";
    if (native_android()) {
    crypto_path = (long long)"libecholite_crypto.so";
    init_name = (long long)"SHA256_Init";
    update_name = (long long)"SHA256_Update";
    final_name = (long long)"SHA256_Final";
    }
    crypto = ep_dlopen(crypto_path);
    before = alloc_bytes(144);
    after = alloc_bytes(144);
    ctx = alloc_bytes(256);
    buffer = alloc_bytes(131072);
    digest = alloc_bytes(32);
    valid = snapshot_private(fd, before);
    if (crypto == 0) {
    valid = 0;
    } else {
    if (ep_dlcall1(ep_dlsym(crypto, init_name), ctx) != 1) {
    valid = 0;
    }
    }
    total = 0;
    finished = 0;
    deadline = (transport_now(libc) + 120000);
    while ((valid == 1 && finished == 0)) {
    if (transport_now(libc) >= deadline) {
    valid = 0;
    } else {
    bytes = ep_dlcall3(ep_dlsym(libc, (long long)"read"), fd, buffer, 131072);
    if (bytes == 0) {
    finished = 1;
    } else {
    if ((bytes < 0 || bytes > 131072)) {
    if (transport_errno(libc) != 4) {
    valid = 0;
    }
    } else {
    if (ep_dlcall3(ep_dlsym(crypto, update_name), ctx, buffer, bytes) != 1) {
    valid = 0;
    }
    total = (total + bytes);
    }
    }
    }
    }
    if (((snapshot_private(fd, after) == 0 || total != native_stat_size(before)) || native_stat_size(before) != native_stat_size(after))) {
    valid = 0;
    }
    field = 48;
    while (field <= 72) {
    if (native_stat_time(before, field) != native_stat_time(after, field)) {
    valid = 0;
    }
    field = (field + 8);
    }
    ep_dlcall1(ep_dlsym(libc, (long long)"close"), fd);
    output = (long long)"";
    if ((valid == 1 && ep_dlcall2(ep_dlsym(crypto, final_name), digest, ctx) == 1)) {
    builder = ep_sb_create(0);
    digits = (long long)"0123456789abcdef";
    i = 0;
    while (i < 32) {
    byte = peek_byte(digest, i);
    ep_sb_append(builder, (long long)substring((char*)digits, (byte / 16), 1));
    ep_sb_append(builder, (long long)substring((char*)digits, (byte % 16), 1));
    i = (i + 1);
    }
    output = ep_sb_to_string(builder);
    }
    free_bytes(before);
    free_bytes(after);
    free_bytes(ctx);
    free_bytes(buffer);
    free_bytes(digest);
    ret_val = output;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(21);
    return ret_val;
}

long long snapshot_read_hex(long long directory, long long name) {
    long long count = 0;
    long long data = 0;
    long long fd = 0;
    long long info = 0;
    long long libc = 0;
    long long output = 0;
    long long used = 0;
    long long valid = 0;
    long long value = 0;
    long long ret_val = 0;

    ep_gc_push_root(&data);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&info);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&output);
    ep_gc_push_root(&used);
    ep_gc_push_root(&value);
    ep_gc_push_root(&directory);
    ep_gc_push_root(&name);

    ep_gc_maybe_collect();

    if (snapshot_name(name) == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    fd = native_openat(directory, name, 16777476, 0);
    if (fd < 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    libc = native_system();
    info = alloc_bytes(144);
    valid = snapshot_private(fd, info);
    if (native_stat_size(info) != 65) {
    valid = 0;
    }
    free_bytes(info);
    data = alloc_bytes(67);
    used = 0;
    while ((valid == 1 && used < 66)) {
    count = ep_dlcall3(ep_dlsym(libc, (long long)"read"), fd, (data + used), (66 - used));
    if (count == 0) {
    break;
    } else {
    if ((count < 0 || count > (66 - used))) {
    if (transport_errno(libc) != 4) {
    valid = 0;
    }
    } else {
    used = (used + count);
    }
    }
    }
    ep_dlcall1(ep_dlsym(libc, (long long)"close"), fd);
    output = (long long)"";
    if (((valid == 1 && used == 65) && peek_byte(data, 64) == 10)) {
    poke_byte(data, 64, 0);
    value = ptr_to_str(data);
    if (snapshot_hex(value, 64)) {
    output = value;
    }
    }
    free_bytes(data);
    ret_val = output;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(9);
    return ret_val;
}

long long snapshot_seal_verify(long long directory, long long name) {
    long long actual = 0;
    long long expected = 0;
    long long ret_val = 0;

    ep_gc_push_root(&actual);
    ep_gc_push_root(&expected);
    ep_gc_push_root(&directory);
    ep_gc_push_root(&name);

    ep_gc_maybe_collect();

    if (snapshot_name(name) == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    expected = snapshot_read_hex(directory, concat(name, (long long)".sha256"));
    if (ep_str_equals(expected, (long long)"")) {
    ret_val = 0;
    goto L_cleanup;
    }
    actual = snapshot_hash(directory, name);
    ret_val = string_equals(expected, actual);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long snapshot_seal_create(long long directory, long long name) {
    long long count = 0;
    long long data = 0;
    long long digest = 0;
    long long fd = 0;
    long long libc = 0;
    long long sidecar = 0;
    long long used = 0;
    long long valid = 0;
    long long ret_val = 0;

    ep_gc_push_root(&data);
    ep_gc_push_root(&digest);
    ep_gc_push_root(&fd);
    ep_gc_push_root(&libc);
    ep_gc_push_root(&sidecar);
    ep_gc_push_root(&used);
    ep_gc_push_root(&directory);
    ep_gc_push_root(&name);

    ep_gc_maybe_collect();

    digest = snapshot_hash(directory, name);
    if (ep_str_equals(digest, (long long)"")) {
    ret_val = 0;
    goto L_cleanup;
    }
    sidecar = concat(name, (long long)".sha256");
    if (snapshot_name(sidecar) == 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    fd = native_openat(directory, sidecar, 16780033, 384);
    if (fd < 0) {
    ret_val = 0;
    goto L_cleanup;
    }
    libc = native_system();
    data = concat(digest, (long long)"\n");
    used = 0;
    valid = 1;
    while ((used < 65 && valid == 1)) {
    count = ep_dlcall3(ep_dlsym(libc, (long long)"write"), fd, (str_to_ptr(data) + used), (65 - used));
    if (count == 0) {
    valid = 0;
    } else {
    if ((count < 0 || count > (65 - used))) {
    if (transport_errno(libc) != 4) {
    valid = 0;
    }
    } else {
    used = (used + count);
    }
    }
    }
    if (ep_dlcall1(ep_dlsym(libc, (long long)"fsync"), fd) != 0) {
    valid = 0;
    }
    ep_dlcall1(ep_dlsym(libc, (long long)"close"), fd);
    if (valid == 0) {
    ep_dlcall3(ep_dlsym(libc, (long long)"unlinkat"), directory, sidecar, 0);
    }
    ret_val = valid;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long ui_schedule_ready(long long now, long long activity, long long dispatched, long long busy, long long ready, long long draft, long long attachment) {
    long long ret_val = 0;

    ep_gc_push_root(&draft);

    ep_gc_maybe_collect();

    if ((((busy || ready != 1) || (!ep_str_equals(string_trim(draft), (long long)""))) || (!ep_str_equals(attachment, (long long)"")))) {
    ret_val = 0;
    goto L_cleanup;
    }
    ret_val = ((now - activity) >= 10000 && (now - dispatched) >= 60000);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long ui_schedule_rows(long long db, long long project) {
    long long parameters = 0;
    long long rows = 0;
    long long ret_val = 0;

    ep_gc_push_root(&parameters);
    ep_gc_push_root(&rows);
    ep_gc_push_root(&db);
    ep_gc_push_root(&project);

    ep_gc_maybe_collect();

    parameters = ({ long long _lit_list = create_list(); append_list(_lit_list, project); _lit_list; });
    rows = sql_query_params(db, (long long)"SELECT coalesce(s.memory,''),t.memory,coalesce(s.status,'unscheduled'),coalesce(strftime('%Y-%m-%d %H:%M UTC',s.due_at,'unixepoch'),''),substr(json_extract(m.body,'$.objective'),1,180),t.status,coalesce(s.turn_id,''),coalesce(r.status,'') FROM tasks t JOIN memories m ON m.id=t.current_memory LEFT JOIN task_schedules s ON s.memory=(SELECT max(memory) FROM task_schedules WHERE task=t.memory) LEFT JOIN turns r ON r.id=s.turn_id WHERE t.project=? ORDER BY t.status IN ('planned','running','waiting') DESC,s.due_at,t.memory DESC LIMIT 32", parameters);
    ret_val = rows;
    rows = 0;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(4);
    return ret_val;
}

long long schedule_init(long long db) {
    long long ret_val = 0;

    ep_gc_push_root(&db);

    ep_gc_maybe_collect();

    ret_val = ep_sqlite3_exec(db, (long long)"CREATE TABLE IF NOT EXISTS task_schedules(memory INTEGER PRIMARY KEY REFERENCES memories(id) ON DELETE CASCADE,task INTEGER NOT NULL REFERENCES tasks(memory) ON DELETE CASCADE,task_revision INTEGER NOT NULL,due_at INTEGER NOT NULL,status TEXT NOT NULL CHECK(status IN ('armed','cancelled','dispatched')),turn_id INTEGER REFERENCES turns(id) ON DELETE SET NULL); CREATE UNIQUE INDEX IF NOT EXISTS schedule_one_armed ON task_schedules(task) WHERE status='armed'; CREATE INDEX IF NOT EXISTS schedule_due ON task_schedules(status,due_at); CREATE TRIGGER IF NOT EXISTS schedule_task_changed AFTER UPDATE OF revision,status ON tasks BEGIN UPDATE task_schedules SET status='cancelled' WHERE task=new.memory AND status='armed'; END;", 0, 0, 0);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(1);
    return ret_val;
}

long long schedule_error(long long db, long long message) {
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&result);
    ep_gc_push_root(&db);
    ep_gc_push_root(&message);

    ep_gc_maybe_collect();

    if (db == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    result = result_cache_scalar(db, (long long)"SELECT json_object('status','ok','outcome','failed','text',?)", ({ long long _lit_list = create_list(); append_list(_lit_list, message); _lit_list; }));
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long schedule_result(long long db, long long project) {
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&result);
    ep_gc_push_root(&db);
    ep_gc_push_root(&project);

    ep_gc_maybe_collect();

    if (db == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    result = result_cache_scalar(db, (long long)"SELECT json_object('status','ok','outcome','completed','text','Armed schedules and recent history (up to 20); due work runs while EchoLite is open and idle. Dispatched does not mean the task succeeded.','schedules',json((SELECT coalesce(json_group_array(json_object('schedule_id',s.memory,'task_id',s.task,'task_revision',s.task_revision,'due_at_utc',strftime('%Y-%m-%dT%H:%M:%SZ',s.due_at,'unixepoch'),'status',s.status,'turn_id',s.turn_id)), '[]') FROM (SELECT s.* FROM task_schedules s JOIN tasks t ON t.memory=s.task WHERE t.project=? ORDER BY s.status='armed' DESC,s.memory DESC LIMIT 20) s)))", ({ long long _lit_list = create_list(); append_list(_lit_list, project); _lit_list; }));
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long schedule_set(long long db, long long project, long long task, long long revision, long long delay, long long origin) {
    long long body = 0;
    long long identifier = 0;
    long long ret_val = 0;

    ep_gc_push_root(&body);
    ep_gc_push_root(&identifier);
    ep_gc_push_root(&db);
    ep_gc_push_root(&project);
    ep_gc_push_root(&task);
    ep_gc_push_root(&revision);
    ep_gc_push_root(&delay);
    ep_gc_push_root(&origin);

    ep_gc_maybe_collect();

    if ((!ep_str_equals(result_cache_scalar(db, (long long)"SELECT length(?) BETWEEN 1 AND 8 AND ? NOT GLOB '*[^0-9]*' AND CAST(? AS INTEGER) BETWEEN 0 AND 31536000 AND EXISTS(SELECT 1 FROM tasks WHERE memory=? AND project=? AND revision=? AND status='planned') AND EXISTS(SELECT 1 FROM memories WHERE id=? AND project=? AND status='active')", ({ long long _lit_list = create_list(); append_list(_lit_list, delay); append_list(_lit_list, delay); append_list(_lit_list, delay); append_list(_lit_list, task); append_list(_lit_list, project); append_list(_lit_list, revision); append_list(_lit_list, origin); append_list(_lit_list, project); _lit_list; })), (long long)"1"))) {
    ret_val = schedule_error(db, (long long)"Schedule needs a planned task at its current revision, an active source in this project, and delay_seconds 0-31536000.");
    goto L_cleanup;
    }
    if (ep_str_equals(result_cache_scalar(db, (long long)"SELECT EXISTS(SELECT 1 FROM task_schedules WHERE task=? AND status='armed')", ({ long long _lit_list = create_list(); append_list(_lit_list, task); _lit_list; })), (long long)"1")) {
    ret_val = schedule_error(db, (long long)"Task already has an armed schedule; cancel it explicitly before replacing it.");
    goto L_cleanup;
    }
    body = result_cache_scalar(db, (long long)"SELECT json_object('task_id',?,'task_revision',?,'delay_seconds',CAST(? AS INTEGER),'due_at_utc',strftime('%Y-%m-%dT%H:%M:%SZ','now','+'||?||' seconds'),'kind','one-shot scheduled task')", ({ long long _lit_list = create_list(); append_list(_lit_list, task); append_list(_lit_list, revision); append_list(_lit_list, delay); append_list(_lit_list, delay); _lit_list; }));
    if (sql_execute_params(db, (long long)"INSERT INTO memories(layer,project,source,body) VALUES('episodic',?,'task-schedule',?)", ({ long long _lit_list = create_list(); append_list(_lit_list, project); append_list(_lit_list, (long long)body); _lit_list; })) != 101) {
    ret_val = schedule_error(db, (long long)"Cannot record schedule");
    goto L_cleanup;
    }
    identifier = result_cache_scalar(db, (long long)"SELECT last_insert_rowid()", ({ long long _lit_list = create_list(); _lit_list; }));
    if (sql_execute_params(db, (long long)"INSERT INTO task_schedules(memory,task,task_revision,due_at,status) VALUES(?,?,CAST(? AS INTEGER),CAST(strftime('%s','now') AS INTEGER)+CAST(? AS INTEGER),'armed')", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)identifier); append_list(_lit_list, task); append_list(_lit_list, revision); append_list(_lit_list, delay); _lit_list; })) != 101) {
    ret_val = schedule_error(db, (long long)"Cannot arm schedule");
    goto L_cleanup;
    }
    sql_execute_params(db, (long long)"INSERT OR IGNORE INTO derivations(parent,child) VALUES(?,?),(?,?)", ({ long long _lit_list = create_list(); append_list(_lit_list, origin); append_list(_lit_list, (long long)identifier); append_list(_lit_list, task); append_list(_lit_list, (long long)identifier); _lit_list; }));
    sql_execute_params(db, (long long)"INSERT OR IGNORE INTO derivations(parent,child) SELECT current_memory,? FROM tasks WHERE memory=?", ({ long long _lit_list = create_list(); append_list(_lit_list, (long long)identifier); append_list(_lit_list, task); _lit_list; }));
    ret_val = schedule_result(db, project);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(8);
    return ret_val;
}

long long schedule_cancel(long long db, long long project, long long identifier) {
    long long ret_val = 0;

    ep_gc_push_root(&db);
    ep_gc_push_root(&project);
    ep_gc_push_root(&identifier);

    ep_gc_maybe_collect();

    if ((!ep_str_equals(result_cache_scalar(db, (long long)"SELECT EXISTS(SELECT 1 FROM task_schedules s JOIN tasks t ON t.memory=s.task WHERE s.memory=? AND t.project=? AND s.status IN ('armed','cancelled'))", ({ long long _lit_list = create_list(); append_list(_lit_list, identifier); append_list(_lit_list, project); _lit_list; })), (long long)"1"))) {
    ret_val = schedule_error(db, (long long)"No cancellable schedule in this project. A dispatched turn must be stopped using its turn ID.");
    goto L_cleanup;
    }
    sql_execute_params(db, (long long)"UPDATE task_schedules SET status='cancelled' WHERE memory=? AND status='armed'", ({ long long _lit_list = create_list(); append_list(_lit_list, identifier); _lit_list; }));
    ret_val = schedule_result(db, project);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long schedule_due(long long db, long long project) {
    long long result = 0;
    long long ret_val = 0;

    ep_gc_push_root(&result);
    ep_gc_push_root(&db);
    ep_gc_push_root(&project);

    ep_gc_maybe_collect();

    if (db == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    result = result_cache_scalar(db, (long long)"SELECT s.memory FROM task_schedules s JOIN tasks t ON t.memory=s.task WHERE t.project=? AND t.status='planned' AND t.revision=s.task_revision AND s.status='armed' AND s.due_at<=CAST(strftime('%s','now') AS INTEGER) AND NOT EXISTS(SELECT 1 FROM turns WHERE status='pending') ORDER BY s.due_at,s.memory LIMIT 1", ({ long long _lit_list = create_list(); append_list(_lit_list, project); _lit_list; }));
    ret_val = result;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long schedule_claim(long long db, long long identifier, long long project, long long turn, long long input) {
    long long ret_val = 0;

    ep_gc_push_root(&db);
    ep_gc_push_root(&identifier);
    ep_gc_push_root(&project);
    ep_gc_push_root(&turn);
    ep_gc_push_root(&input);

    ep_gc_maybe_collect();

    sql_execute_params(db, (long long)"UPDATE task_schedules SET status='dispatched',turn_id=? WHERE memory=? AND status='armed' AND due_at<=CAST(strftime('%s','now') AS INTEGER) AND EXISTS(SELECT 1 FROM tasks t WHERE t.memory=task_schedules.task AND t.project=? AND t.status='planned' AND t.revision=task_schedules.task_revision) AND EXISTS(SELECT 1 FROM turns WHERE id=? AND project=? AND status='pending' AND user_memory=?) AND NOT EXISTS(SELECT 1 FROM turns WHERE status='pending' AND id<>?)", ({ long long _lit_list = create_list(); append_list(_lit_list, turn); append_list(_lit_list, identifier); append_list(_lit_list, project); append_list(_lit_list, turn); append_list(_lit_list, project); append_list(_lit_list, input); append_list(_lit_list, turn); _lit_list; }));
    if ((!ep_str_equals(result_cache_scalar(db, (long long)"SELECT changes()", ({ long long _lit_list = create_list(); _lit_list; })), (long long)"1"))) {
    ret_val = 0;
    goto L_cleanup;
    }
    sql_execute_params(db, (long long)"UPDATE memories SET source='scheduled-event' WHERE id=?", ({ long long _lit_list = create_list(); append_list(_lit_list, input); _lit_list; }));
    sql_execute_params(db, (long long)"INSERT INTO derivations(parent,child) VALUES(?,?)", ({ long long _lit_list = create_list(); append_list(_lit_list, identifier); append_list(_lit_list, input); _lit_list; }));
    ret_val = 1;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}

long long schedule_needs_work(long long db, long long turn) {
    long long pending = 0;
    long long ret_val = 0;

    ep_gc_push_root(&pending);
    ep_gc_push_root(&db);
    ep_gc_push_root(&turn);

    ep_gc_maybe_collect();

    if (db == 0) {
    ret_val = 1;
    goto L_cleanup;
    }
    pending = result_cache_scalar(db, (long long)"SELECT EXISTS(SELECT 1 FROM task_schedules s JOIN tasks t ON t.memory=s.task WHERE s.turn_id=? AND s.status='dispatched' AND t.status IN ('planned','running'))", ({ long long _lit_list = create_list(); append_list(_lit_list, turn); _lit_list; }));
    ret_val = ep_str_equals(pending, (long long)"1");
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(3);
    return ret_val;
}

long long network_mode(long long home) {
    long long ret_val = 0;

    ret_val = (long long)"automatic";
    goto L_cleanup;
L_cleanup:
    return ret_val;
}

long long android_files_directory() {
    long long library = 0;
    long long pointer = 0;
    long long ret_val = 0;

    ep_gc_push_root(&library);
    ep_gc_push_root(&pointer);

    ep_gc_maybe_collect();

    library = ep_dlopen((long long)"libSDL3.so");
    if (library == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    pointer = ep_dlcall0(ep_dlsym(library, (long long)"SDL_GetAndroidInternalStoragePath"));
    if (pointer == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    ret_val = ptr_to_str(pointer);
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(2);
    return ret_val;
}

long long android_library_directory(long long library) {
    long long directory = 0;
    long long found = 0;
    long long info = 0;
    long long name = 0;
    long long symbol = 0;
    long long ret_val = 0;

    ep_gc_push_root(&directory);
    ep_gc_push_root(&info);
    ep_gc_push_root(&name);
    ep_gc_push_root(&symbol);
    ep_gc_push_root(&library);

    ep_gc_maybe_collect();

    symbol = ep_dlsym(library, (long long)"SDL_main");
    if (symbol == 0) {
    ret_val = (long long)"";
    goto L_cleanup;
    }
    info = alloc_bytes(32);
    found = ep_dlcall2(ep_dlsym(ep_dlopen((long long)"libdl.so"), (long long)"dladdr"), symbol, info);
    directory = (long long)"";
    if (found != 0) {
    name = process_integer(info, 8);
    if (name != 0) {
    directory = path_dirname(ptr_to_str(name));
    }
    }
    free_bytes(info);
    ret_val = directory;
    goto L_cleanup;
L_cleanup:
    ep_gc_pop_roots(5);
    return ret_val;
}


static void __ep_mark_globals_major(void) {
    if (UI_POINTER_PRESSED != 0) ep_gc_mark_object((void*)UI_POINTER_PRESSED);
    if (UI_TOUCH_START_X != 0) ep_gc_mark_object((void*)UI_TOUCH_START_X);
    if (UI_TOUCH_START_Y != 0) ep_gc_mark_object((void*)UI_TOUCH_START_Y);
    if (UI_TOUCH_LAST_Y != 0) ep_gc_mark_object((void*)UI_TOUCH_LAST_Y);
    if (UI_TOUCH_MOVED != 0) ep_gc_mark_object((void*)UI_TOUCH_MOVED);
    if (UI_TOUCH_DELTA != 0) ep_gc_mark_object((void*)UI_TOUCH_DELTA);
    if (UI_TOUCH_STARTED != 0) ep_gc_mark_object((void*)UI_TOUCH_STARTED);
    if (UI_SCALE != 0) ep_gc_mark_object((void*)UI_SCALE);
    if (UI_TOP != 0) ep_gc_mark_object((void*)UI_TOP);
    if (UI_BOTTOM != 0) ep_gc_mark_object((void*)UI_BOTTOM);
    if (UI_TRANSFORM_CIF != 0) ep_gc_mark_object((void*)UI_TRANSFORM_CIF);
    if (ANDROID_SDL != 0) ep_gc_mark_object((void*)ANDROID_SDL);
    if (ANDROID_INPUT_MUTEX != 0) ep_gc_mark_object((void*)ANDROID_INPUT_MUTEX);
    if (ANDROID_INPUT_BUFFER != 0) ep_gc_mark_object((void*)ANDROID_INPUT_BUFFER);
    if (ANDROID_INPUT_USED != 0) ep_gc_mark_object((void*)ANDROID_INPUT_USED);
    if (ANDROID_INPUT_OVERFLOW != 0) ep_gc_mark_object((void*)ANDROID_INPUT_OVERFLOW);
    if (ANDROID_INPUT_WATCH != 0) ep_gc_mark_object((void*)ANDROID_INPUT_WATCH);
    if (ANDROID_INPUT_WINDOW != 0) ep_gc_mark_object((void*)ANDROID_INPUT_WINDOW);
    if (ANDROID_INPUT_LOCK != 0) ep_gc_mark_object((void*)ANDROID_INPUT_LOCK);
    if (ANDROID_INPUT_UNLOCK != 0) ep_gc_mark_object((void*)ANDROID_INPUT_UNLOCK);
    if (ANDROID_INPUT_COPY != 0) ep_gc_mark_object((void*)ANDROID_INPUT_COPY);
    if (ANDROID_INPUT_LENGTH != 0) ep_gc_mark_object((void*)ANDROID_INPUT_LENGTH);
    if (ANDROID_POINTER_PENDING != 0) ep_gc_mark_object((void*)ANDROID_POINTER_PENDING);
    if (NATIVE_SYSTEM != 0) ep_gc_mark_object((void*)NATIVE_SYSTEM);
    if (NATIVE_ANDROID != 0) ep_gc_mark_object((void*)NATIVE_ANDROID);
    if (NATIVE_VARIADIC_FFI != 0) ep_gc_mark_object((void*)NATIVE_VARIADIC_FFI);
    if (ANDROID_JNI_ENV != 0) ep_gc_mark_object((void*)ANDROID_JNI_ENV);
    if (ANDROID_JNI_TABLE != 0) ep_gc_mark_object((void*)ANDROID_JNI_TABLE);
    if (FONT_FFI != 0) ep_gc_mark_object((void*)FONT_FFI);
    if (FONT_CALL != 0) ep_gc_mark_object((void*)FONT_CALL);
    if (FONT_DRAW_CIF != 0) ep_gc_mark_object((void*)FONT_DRAW_CIF);
    if (FONT_MEASURE_CIF != 0) ep_gc_mark_object((void*)FONT_MEASURE_CIF);
    if (FONT_VALUE != 0) ep_gc_mark_object((void*)FONT_VALUE);
    if (FONT_TEXT != 0) ep_gc_mark_object((void*)FONT_TEXT);
    if (FONT_POSITION != 0) ep_gc_mark_object((void*)FONT_POSITION);
    if (FONT_SIZE != 0) ep_gc_mark_object((void*)FONT_SIZE);
    if (FONT_SPACE != 0) ep_gc_mark_object((void*)FONT_SPACE);
    if (FONT_COLOR != 0) ep_gc_mark_object((void*)FONT_COLOR);
    if (FONT_DRAW_ARGS != 0) ep_gc_mark_object((void*)FONT_DRAW_ARGS);
    if (FONT_MEASURE_ARGS != 0) ep_gc_mark_object((void*)FONT_MEASURE_ARGS);
    if (FONT_DRAW != 0) ep_gc_mark_object((void*)FONT_DRAW);
    if (FONT_MEASURE != 0) ep_gc_mark_object((void*)FONT_MEASURE);
    if (FONT_RESULT != 0) ep_gc_mark_object((void*)FONT_RESULT);
    if (RAYLIB_HANDLE != 0) ep_gc_mark_object((void*)RAYLIB_HANDLE);
    if (RAYLIB_WHITE != 0) ep_gc_mark_object((void*)RAYLIB_WHITE);
    if (RAYLIB_BLACK != 0) ep_gc_mark_object((void*)RAYLIB_BLACK);
    if (RAYLIB_RED != 0) ep_gc_mark_object((void*)RAYLIB_RED);
    if (RAYLIB_GREEN != 0) ep_gc_mark_object((void*)RAYLIB_GREEN);
    if (RAYLIB_BLUE != 0) ep_gc_mark_object((void*)RAYLIB_BLUE);
    if (RAYLIB_YELLOW != 0) ep_gc_mark_object((void*)RAYLIB_YELLOW);
    if (RAYLIB_ORANGE != 0) ep_gc_mark_object((void*)RAYLIB_ORANGE);
    if (RAYLIB_PURPLE != 0) ep_gc_mark_object((void*)RAYLIB_PURPLE);
    if (RAYLIB_PINK != 0) ep_gc_mark_object((void*)RAYLIB_PINK);
    if (RAYLIB_LIGHTGRAY != 0) ep_gc_mark_object((void*)RAYLIB_LIGHTGRAY);
    if (RAYLIB_DARKGRAY != 0) ep_gc_mark_object((void*)RAYLIB_DARKGRAY);
    if (RAYLIB_GRAY != 0) ep_gc_mark_object((void*)RAYLIB_GRAY);
    if (RAYLIB_MAROON != 0) ep_gc_mark_object((void*)RAYLIB_MAROON);
    if (RAYLIB_LIME != 0) ep_gc_mark_object((void*)RAYLIB_LIME);
    if (RAYLIB_DARKBLUE != 0) ep_gc_mark_object((void*)RAYLIB_DARKBLUE);
    if (RAYLIB_DARKGREEN != 0) ep_gc_mark_object((void*)RAYLIB_DARKGREEN);
    if (RAYLIB_DARKPURPLE != 0) ep_gc_mark_object((void*)RAYLIB_DARKPURPLE);
    if (RAYLIB_BEIGE != 0) ep_gc_mark_object((void*)RAYLIB_BEIGE);
    if (RAYLIB_MAGENTA != 0) ep_gc_mark_object((void*)RAYLIB_MAGENTA);
    if (RAYLIB_SKYBLUE != 0) ep_gc_mark_object((void*)RAYLIB_SKYBLUE);
    if (RAYLIB_GOLD != 0) ep_gc_mark_object((void*)RAYLIB_GOLD);
    if (RAYLIB_BROWN != 0) ep_gc_mark_object((void*)RAYLIB_BROWN);
    if (RAYLIB_DARKBROWN != 0) ep_gc_mark_object((void*)RAYLIB_DARKBROWN);
    if (RAYLIB_VIOLET != 0) ep_gc_mark_object((void*)RAYLIB_VIOLET);
    if (RAYLIB_RAYWHITE != 0) ep_gc_mark_object((void*)RAYLIB_RAYWHITE);
    if (RAYLIB_BLANK != 0) ep_gc_mark_object((void*)RAYLIB_BLANK);
    if (KEY_SPACE != 0) ep_gc_mark_object((void*)KEY_SPACE);
    if (KEY_ESCAPE != 0) ep_gc_mark_object((void*)KEY_ESCAPE);
    if (KEY_ENTER != 0) ep_gc_mark_object((void*)KEY_ENTER);
    if (KEY_TAB != 0) ep_gc_mark_object((void*)KEY_TAB);
    if (KEY_BACKSPACE != 0) ep_gc_mark_object((void*)KEY_BACKSPACE);
    if (KEY_DELETE != 0) ep_gc_mark_object((void*)KEY_DELETE);
    if (KEY_RIGHT != 0) ep_gc_mark_object((void*)KEY_RIGHT);
    if (KEY_LEFT != 0) ep_gc_mark_object((void*)KEY_LEFT);
    if (KEY_DOWN != 0) ep_gc_mark_object((void*)KEY_DOWN);
    if (KEY_UP != 0) ep_gc_mark_object((void*)KEY_UP);
    if (KEY_PAGE_UP != 0) ep_gc_mark_object((void*)KEY_PAGE_UP);
    if (KEY_PAGE_DOWN != 0) ep_gc_mark_object((void*)KEY_PAGE_DOWN);
    if (KEY_HOME != 0) ep_gc_mark_object((void*)KEY_HOME);
    if (KEY_END != 0) ep_gc_mark_object((void*)KEY_END);
    if (KEY_F1 != 0) ep_gc_mark_object((void*)KEY_F1);
    if (KEY_F2 != 0) ep_gc_mark_object((void*)KEY_F2);
    if (KEY_F3 != 0) ep_gc_mark_object((void*)KEY_F3);
    if (KEY_F4 != 0) ep_gc_mark_object((void*)KEY_F4);
    if (KEY_F5 != 0) ep_gc_mark_object((void*)KEY_F5);
    if (KEY_F6 != 0) ep_gc_mark_object((void*)KEY_F6);
    if (KEY_F7 != 0) ep_gc_mark_object((void*)KEY_F7);
    if (KEY_F8 != 0) ep_gc_mark_object((void*)KEY_F8);
    if (KEY_F9 != 0) ep_gc_mark_object((void*)KEY_F9);
    if (KEY_F10 != 0) ep_gc_mark_object((void*)KEY_F10);
    if (KEY_F11 != 0) ep_gc_mark_object((void*)KEY_F11);
    if (KEY_F12 != 0) ep_gc_mark_object((void*)KEY_F12);
    if (KEY_LEFT_SHIFT != 0) ep_gc_mark_object((void*)KEY_LEFT_SHIFT);
    if (KEY_LEFT_CONTROL != 0) ep_gc_mark_object((void*)KEY_LEFT_CONTROL);
    if (KEY_LEFT_ALT != 0) ep_gc_mark_object((void*)KEY_LEFT_ALT);
    if (KEY_RIGHT_SHIFT != 0) ep_gc_mark_object((void*)KEY_RIGHT_SHIFT);
    if (KEY_RIGHT_CONTROL != 0) ep_gc_mark_object((void*)KEY_RIGHT_CONTROL);
    if (KEY_RIGHT_ALT != 0) ep_gc_mark_object((void*)KEY_RIGHT_ALT);
    if (KEY_A != 0) ep_gc_mark_object((void*)KEY_A);
    if (KEY_B != 0) ep_gc_mark_object((void*)KEY_B);
    if (KEY_C != 0) ep_gc_mark_object((void*)KEY_C);
    if (KEY_D != 0) ep_gc_mark_object((void*)KEY_D);
    if (KEY_E != 0) ep_gc_mark_object((void*)KEY_E);
    if (KEY_F != 0) ep_gc_mark_object((void*)KEY_F);
    if (KEY_G != 0) ep_gc_mark_object((void*)KEY_G);
    if (KEY_H != 0) ep_gc_mark_object((void*)KEY_H);
    if (KEY_I != 0) ep_gc_mark_object((void*)KEY_I);
    if (KEY_J != 0) ep_gc_mark_object((void*)KEY_J);
    if (KEY_K != 0) ep_gc_mark_object((void*)KEY_K);
    if (KEY_L != 0) ep_gc_mark_object((void*)KEY_L);
    if (KEY_M != 0) ep_gc_mark_object((void*)KEY_M);
    if (KEY_N != 0) ep_gc_mark_object((void*)KEY_N);
    if (KEY_O != 0) ep_gc_mark_object((void*)KEY_O);
    if (KEY_P != 0) ep_gc_mark_object((void*)KEY_P);
    if (KEY_Q != 0) ep_gc_mark_object((void*)KEY_Q);
    if (KEY_R != 0) ep_gc_mark_object((void*)KEY_R);
    if (KEY_S != 0) ep_gc_mark_object((void*)KEY_S);
    if (KEY_T != 0) ep_gc_mark_object((void*)KEY_T);
    if (KEY_U != 0) ep_gc_mark_object((void*)KEY_U);
    if (KEY_V != 0) ep_gc_mark_object((void*)KEY_V);
    if (KEY_W != 0) ep_gc_mark_object((void*)KEY_W);
    if (KEY_X != 0) ep_gc_mark_object((void*)KEY_X);
    if (KEY_Y != 0) ep_gc_mark_object((void*)KEY_Y);
    if (KEY_Z != 0) ep_gc_mark_object((void*)KEY_Z);
    if (KEY_ZERO != 0) ep_gc_mark_object((void*)KEY_ZERO);
    if (KEY_ONE != 0) ep_gc_mark_object((void*)KEY_ONE);
    if (KEY_TWO != 0) ep_gc_mark_object((void*)KEY_TWO);
    if (KEY_THREE != 0) ep_gc_mark_object((void*)KEY_THREE);
    if (KEY_FOUR != 0) ep_gc_mark_object((void*)KEY_FOUR);
    if (KEY_FIVE != 0) ep_gc_mark_object((void*)KEY_FIVE);
    if (KEY_SIX != 0) ep_gc_mark_object((void*)KEY_SIX);
    if (KEY_SEVEN != 0) ep_gc_mark_object((void*)KEY_SEVEN);
    if (KEY_EIGHT != 0) ep_gc_mark_object((void*)KEY_EIGHT);
    if (KEY_NINE != 0) ep_gc_mark_object((void*)KEY_NINE);
    if (MOUSE_LEFT != 0) ep_gc_mark_object((void*)MOUSE_LEFT);
    if (MOUSE_RIGHT != 0) ep_gc_mark_object((void*)MOUSE_RIGHT);
    if (MOUSE_MIDDLE != 0) ep_gc_mark_object((void*)MOUSE_MIDDLE);
    if (FLAG_VSYNC_HINT != 0) ep_gc_mark_object((void*)FLAG_VSYNC_HINT);
    if (FLAG_FULLSCREEN_MODE != 0) ep_gc_mark_object((void*)FLAG_FULLSCREEN_MODE);
    if (FLAG_WINDOW_RESIZABLE != 0) ep_gc_mark_object((void*)FLAG_WINDOW_RESIZABLE);
    if (FLAG_WINDOW_UNDECORATED != 0) ep_gc_mark_object((void*)FLAG_WINDOW_UNDECORATED);
    if (FLAG_WINDOW_TRANSPARENT != 0) ep_gc_mark_object((void*)FLAG_WINDOW_TRANSPARENT);
    if (FLAG_MSAA_4X_HINT != 0) ep_gc_mark_object((void*)FLAG_MSAA_4X_HINT);
    if (FLAG_WINDOW_ALWAYS_RUN != 0) ep_gc_mark_object((void*)FLAG_WINDOW_ALWAYS_RUN);
    if (LOG_NONE != 0) ep_gc_mark_object((void*)LOG_NONE);
    if (LOG_ERROR != 0) ep_gc_mark_object((void*)LOG_ERROR);
    if (LOG_WARNING != 0) ep_gc_mark_object((void*)LOG_WARNING);
    if (LOG_INFO != 0) ep_gc_mark_object((void*)LOG_INFO);
    if (LOG_DEBUG != 0) ep_gc_mark_object((void*)LOG_DEBUG);
    if (LOG_TRACE != 0) ep_gc_mark_object((void*)LOG_TRACE);
    if (CHAT_WHEEL_CIF != 0) ep_gc_mark_object((void*)CHAT_WHEEL_CIF);
    if (CHAT_WHEEL_RESULT != 0) ep_gc_mark_object((void*)CHAT_WHEEL_RESULT);
    if (PROGRESS_TURN != 0) ep_gc_mark_object((void*)PROGRESS_TURN);
    if (PROGRESS_ROUND != 0) ep_gc_mark_object((void*)PROGRESS_ROUND);
    if (PROGRESS_EPOCH != 0) ep_gc_mark_object((void*)PROGRESS_EPOCH);
    if (PROGRESS_LAST != 0) ep_gc_mark_object((void*)PROGRESS_LAST);
    if (SOURCES_OPEN != 0) ep_gc_mark_object((void*)SOURCES_OPEN);
    if (SOURCE_CHILD != 0) ep_gc_mark_object((void*)SOURCE_CHILD);
    if (SOURCE_NOTICE != 0) ep_gc_mark_object((void*)SOURCE_NOTICE);
    if (EDIT_TEXT != 0) ep_gc_mark_object((void*)EDIT_TEXT);
    if (EDIT_CARET != 0) ep_gc_mark_object((void*)EDIT_CARET);
    if (EDIT_ANCHOR != 0) ep_gc_mark_object((void*)EDIT_ANCHOR);
    if (EDIT_FOCUS != 0) ep_gc_mark_object((void*)EDIT_FOCUS);
    if (EDIT_DRAG != 0) ep_gc_mark_object((void*)EDIT_DRAG);
    if (EDIT_SCROLL != 0) ep_gc_mark_object((void*)EDIT_SCROLL);
    if (EDIT_BLINK != 0) ep_gc_mark_object((void*)EDIT_BLINK);
    if (EDIT_ERROR != 0) ep_gc_mark_object((void*)EDIT_ERROR);
    if (EDIT_CLICK_TIME != 0) ep_gc_mark_object((void*)EDIT_CLICK_TIME);
    if (EDIT_CLICK_POS != 0) ep_gc_mark_object((void*)EDIT_CLICK_POS);
    if (SELECT_CLICK_TIME != 0) ep_gc_mark_object((void*)SELECT_CLICK_TIME);
    if (SELECT_CLICK_POS != 0) ep_gc_mark_object((void*)SELECT_CLICK_POS);
    if (EDIT_UNDO != 0) ep_gc_mark_object((void*)EDIT_UNDO);
    if (EDIT_REDO != 0) ep_gc_mark_object((void*)EDIT_REDO);
    if (SELECT_TOP != 0) ep_gc_mark_object((void*)SELECT_TOP);
    if (SELECT_BOTTOM != 0) ep_gc_mark_object((void*)SELECT_BOTTOM);
    if (SELECT_TEXT != 0) ep_gc_mark_object((void*)SELECT_TEXT);
    if (SELECT_CARET != 0) ep_gc_mark_object((void*)SELECT_CARET);
    if (SELECT_ANCHOR != 0) ep_gc_mark_object((void*)SELECT_ANCHOR);
    if (SELECT_DRAG != 0) ep_gc_mark_object((void*)SELECT_DRAG);
    if (EDIT_MENU != 0) ep_gc_mark_object((void*)EDIT_MENU);
    if (EDIT_MENU_X != 0) ep_gc_mark_object((void*)EDIT_MENU_X);
    if (EDIT_MENU_Y != 0) ep_gc_mark_object((void*)EDIT_MENU_Y);
    if (EDIT_MENU_USED != 0) ep_gc_mark_object((void*)EDIT_MENU_USED);
    if (PDF_OBJC != 0) ep_gc_mark_object((void*)PDF_OBJC);
    if (STATE_LEASE_FD != 0) ep_gc_mark_object((void*)STATE_LEASE_FD);
    if (WORKER_LEASE_FD != 0) ep_gc_mark_object((void*)WORKER_LEASE_FD);
}
static void __ep_mark_globals_minor(void) {
    if (UI_POINTER_PRESSED != 0) ep_gc_mark_object_minor((void*)UI_POINTER_PRESSED);
    if (UI_TOUCH_START_X != 0) ep_gc_mark_object_minor((void*)UI_TOUCH_START_X);
    if (UI_TOUCH_START_Y != 0) ep_gc_mark_object_minor((void*)UI_TOUCH_START_Y);
    if (UI_TOUCH_LAST_Y != 0) ep_gc_mark_object_minor((void*)UI_TOUCH_LAST_Y);
    if (UI_TOUCH_MOVED != 0) ep_gc_mark_object_minor((void*)UI_TOUCH_MOVED);
    if (UI_TOUCH_DELTA != 0) ep_gc_mark_object_minor((void*)UI_TOUCH_DELTA);
    if (UI_TOUCH_STARTED != 0) ep_gc_mark_object_minor((void*)UI_TOUCH_STARTED);
    if (UI_SCALE != 0) ep_gc_mark_object_minor((void*)UI_SCALE);
    if (UI_TOP != 0) ep_gc_mark_object_minor((void*)UI_TOP);
    if (UI_BOTTOM != 0) ep_gc_mark_object_minor((void*)UI_BOTTOM);
    if (UI_TRANSFORM_CIF != 0) ep_gc_mark_object_minor((void*)UI_TRANSFORM_CIF);
    if (ANDROID_SDL != 0) ep_gc_mark_object_minor((void*)ANDROID_SDL);
    if (ANDROID_INPUT_MUTEX != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_MUTEX);
    if (ANDROID_INPUT_BUFFER != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_BUFFER);
    if (ANDROID_INPUT_USED != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_USED);
    if (ANDROID_INPUT_OVERFLOW != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_OVERFLOW);
    if (ANDROID_INPUT_WATCH != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_WATCH);
    if (ANDROID_INPUT_WINDOW != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_WINDOW);
    if (ANDROID_INPUT_LOCK != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_LOCK);
    if (ANDROID_INPUT_UNLOCK != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_UNLOCK);
    if (ANDROID_INPUT_COPY != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_COPY);
    if (ANDROID_INPUT_LENGTH != 0) ep_gc_mark_object_minor((void*)ANDROID_INPUT_LENGTH);
    if (ANDROID_POINTER_PENDING != 0) ep_gc_mark_object_minor((void*)ANDROID_POINTER_PENDING);
    if (NATIVE_SYSTEM != 0) ep_gc_mark_object_minor((void*)NATIVE_SYSTEM);
    if (NATIVE_ANDROID != 0) ep_gc_mark_object_minor((void*)NATIVE_ANDROID);
    if (NATIVE_VARIADIC_FFI != 0) ep_gc_mark_object_minor((void*)NATIVE_VARIADIC_FFI);
    if (ANDROID_JNI_ENV != 0) ep_gc_mark_object_minor((void*)ANDROID_JNI_ENV);
    if (ANDROID_JNI_TABLE != 0) ep_gc_mark_object_minor((void*)ANDROID_JNI_TABLE);
    if (FONT_FFI != 0) ep_gc_mark_object_minor((void*)FONT_FFI);
    if (FONT_CALL != 0) ep_gc_mark_object_minor((void*)FONT_CALL);
    if (FONT_DRAW_CIF != 0) ep_gc_mark_object_minor((void*)FONT_DRAW_CIF);
    if (FONT_MEASURE_CIF != 0) ep_gc_mark_object_minor((void*)FONT_MEASURE_CIF);
    if (FONT_VALUE != 0) ep_gc_mark_object_minor((void*)FONT_VALUE);
    if (FONT_TEXT != 0) ep_gc_mark_object_minor((void*)FONT_TEXT);
    if (FONT_POSITION != 0) ep_gc_mark_object_minor((void*)FONT_POSITION);
    if (FONT_SIZE != 0) ep_gc_mark_object_minor((void*)FONT_SIZE);
    if (FONT_SPACE != 0) ep_gc_mark_object_minor((void*)FONT_SPACE);
    if (FONT_COLOR != 0) ep_gc_mark_object_minor((void*)FONT_COLOR);
    if (FONT_DRAW_ARGS != 0) ep_gc_mark_object_minor((void*)FONT_DRAW_ARGS);
    if (FONT_MEASURE_ARGS != 0) ep_gc_mark_object_minor((void*)FONT_MEASURE_ARGS);
    if (FONT_DRAW != 0) ep_gc_mark_object_minor((void*)FONT_DRAW);
    if (FONT_MEASURE != 0) ep_gc_mark_object_minor((void*)FONT_MEASURE);
    if (FONT_RESULT != 0) ep_gc_mark_object_minor((void*)FONT_RESULT);
    if (RAYLIB_HANDLE != 0) ep_gc_mark_object_minor((void*)RAYLIB_HANDLE);
    if (RAYLIB_WHITE != 0) ep_gc_mark_object_minor((void*)RAYLIB_WHITE);
    if (RAYLIB_BLACK != 0) ep_gc_mark_object_minor((void*)RAYLIB_BLACK);
    if (RAYLIB_RED != 0) ep_gc_mark_object_minor((void*)RAYLIB_RED);
    if (RAYLIB_GREEN != 0) ep_gc_mark_object_minor((void*)RAYLIB_GREEN);
    if (RAYLIB_BLUE != 0) ep_gc_mark_object_minor((void*)RAYLIB_BLUE);
    if (RAYLIB_YELLOW != 0) ep_gc_mark_object_minor((void*)RAYLIB_YELLOW);
    if (RAYLIB_ORANGE != 0) ep_gc_mark_object_minor((void*)RAYLIB_ORANGE);
    if (RAYLIB_PURPLE != 0) ep_gc_mark_object_minor((void*)RAYLIB_PURPLE);
    if (RAYLIB_PINK != 0) ep_gc_mark_object_minor((void*)RAYLIB_PINK);
    if (RAYLIB_LIGHTGRAY != 0) ep_gc_mark_object_minor((void*)RAYLIB_LIGHTGRAY);
    if (RAYLIB_DARKGRAY != 0) ep_gc_mark_object_minor((void*)RAYLIB_DARKGRAY);
    if (RAYLIB_GRAY != 0) ep_gc_mark_object_minor((void*)RAYLIB_GRAY);
    if (RAYLIB_MAROON != 0) ep_gc_mark_object_minor((void*)RAYLIB_MAROON);
    if (RAYLIB_LIME != 0) ep_gc_mark_object_minor((void*)RAYLIB_LIME);
    if (RAYLIB_DARKBLUE != 0) ep_gc_mark_object_minor((void*)RAYLIB_DARKBLUE);
    if (RAYLIB_DARKGREEN != 0) ep_gc_mark_object_minor((void*)RAYLIB_DARKGREEN);
    if (RAYLIB_DARKPURPLE != 0) ep_gc_mark_object_minor((void*)RAYLIB_DARKPURPLE);
    if (RAYLIB_BEIGE != 0) ep_gc_mark_object_minor((void*)RAYLIB_BEIGE);
    if (RAYLIB_MAGENTA != 0) ep_gc_mark_object_minor((void*)RAYLIB_MAGENTA);
    if (RAYLIB_SKYBLUE != 0) ep_gc_mark_object_minor((void*)RAYLIB_SKYBLUE);
    if (RAYLIB_GOLD != 0) ep_gc_mark_object_minor((void*)RAYLIB_GOLD);
    if (RAYLIB_BROWN != 0) ep_gc_mark_object_minor((void*)RAYLIB_BROWN);
    if (RAYLIB_DARKBROWN != 0) ep_gc_mark_object_minor((void*)RAYLIB_DARKBROWN);
    if (RAYLIB_VIOLET != 0) ep_gc_mark_object_minor((void*)RAYLIB_VIOLET);
    if (RAYLIB_RAYWHITE != 0) ep_gc_mark_object_minor((void*)RAYLIB_RAYWHITE);
    if (RAYLIB_BLANK != 0) ep_gc_mark_object_minor((void*)RAYLIB_BLANK);
    if (KEY_SPACE != 0) ep_gc_mark_object_minor((void*)KEY_SPACE);
    if (KEY_ESCAPE != 0) ep_gc_mark_object_minor((void*)KEY_ESCAPE);
    if (KEY_ENTER != 0) ep_gc_mark_object_minor((void*)KEY_ENTER);
    if (KEY_TAB != 0) ep_gc_mark_object_minor((void*)KEY_TAB);
    if (KEY_BACKSPACE != 0) ep_gc_mark_object_minor((void*)KEY_BACKSPACE);
    if (KEY_DELETE != 0) ep_gc_mark_object_minor((void*)KEY_DELETE);
    if (KEY_RIGHT != 0) ep_gc_mark_object_minor((void*)KEY_RIGHT);
    if (KEY_LEFT != 0) ep_gc_mark_object_minor((void*)KEY_LEFT);
    if (KEY_DOWN != 0) ep_gc_mark_object_minor((void*)KEY_DOWN);
    if (KEY_UP != 0) ep_gc_mark_object_minor((void*)KEY_UP);
    if (KEY_PAGE_UP != 0) ep_gc_mark_object_minor((void*)KEY_PAGE_UP);
    if (KEY_PAGE_DOWN != 0) ep_gc_mark_object_minor((void*)KEY_PAGE_DOWN);
    if (KEY_HOME != 0) ep_gc_mark_object_minor((void*)KEY_HOME);
    if (KEY_END != 0) ep_gc_mark_object_minor((void*)KEY_END);
    if (KEY_F1 != 0) ep_gc_mark_object_minor((void*)KEY_F1);
    if (KEY_F2 != 0) ep_gc_mark_object_minor((void*)KEY_F2);
    if (KEY_F3 != 0) ep_gc_mark_object_minor((void*)KEY_F3);
    if (KEY_F4 != 0) ep_gc_mark_object_minor((void*)KEY_F4);
    if (KEY_F5 != 0) ep_gc_mark_object_minor((void*)KEY_F5);
    if (KEY_F6 != 0) ep_gc_mark_object_minor((void*)KEY_F6);
    if (KEY_F7 != 0) ep_gc_mark_object_minor((void*)KEY_F7);
    if (KEY_F8 != 0) ep_gc_mark_object_minor((void*)KEY_F8);
    if (KEY_F9 != 0) ep_gc_mark_object_minor((void*)KEY_F9);
    if (KEY_F10 != 0) ep_gc_mark_object_minor((void*)KEY_F10);
    if (KEY_F11 != 0) ep_gc_mark_object_minor((void*)KEY_F11);
    if (KEY_F12 != 0) ep_gc_mark_object_minor((void*)KEY_F12);
    if (KEY_LEFT_SHIFT != 0) ep_gc_mark_object_minor((void*)KEY_LEFT_SHIFT);
    if (KEY_LEFT_CONTROL != 0) ep_gc_mark_object_minor((void*)KEY_LEFT_CONTROL);
    if (KEY_LEFT_ALT != 0) ep_gc_mark_object_minor((void*)KEY_LEFT_ALT);
    if (KEY_RIGHT_SHIFT != 0) ep_gc_mark_object_minor((void*)KEY_RIGHT_SHIFT);
    if (KEY_RIGHT_CONTROL != 0) ep_gc_mark_object_minor((void*)KEY_RIGHT_CONTROL);
    if (KEY_RIGHT_ALT != 0) ep_gc_mark_object_minor((void*)KEY_RIGHT_ALT);
    if (KEY_A != 0) ep_gc_mark_object_minor((void*)KEY_A);
    if (KEY_B != 0) ep_gc_mark_object_minor((void*)KEY_B);
    if (KEY_C != 0) ep_gc_mark_object_minor((void*)KEY_C);
    if (KEY_D != 0) ep_gc_mark_object_minor((void*)KEY_D);
    if (KEY_E != 0) ep_gc_mark_object_minor((void*)KEY_E);
    if (KEY_F != 0) ep_gc_mark_object_minor((void*)KEY_F);
    if (KEY_G != 0) ep_gc_mark_object_minor((void*)KEY_G);
    if (KEY_H != 0) ep_gc_mark_object_minor((void*)KEY_H);
    if (KEY_I != 0) ep_gc_mark_object_minor((void*)KEY_I);
    if (KEY_J != 0) ep_gc_mark_object_minor((void*)KEY_J);
    if (KEY_K != 0) ep_gc_mark_object_minor((void*)KEY_K);
    if (KEY_L != 0) ep_gc_mark_object_minor((void*)KEY_L);
    if (KEY_M != 0) ep_gc_mark_object_minor((void*)KEY_M);
    if (KEY_N != 0) ep_gc_mark_object_minor((void*)KEY_N);
    if (KEY_O != 0) ep_gc_mark_object_minor((void*)KEY_O);
    if (KEY_P != 0) ep_gc_mark_object_minor((void*)KEY_P);
    if (KEY_Q != 0) ep_gc_mark_object_minor((void*)KEY_Q);
    if (KEY_R != 0) ep_gc_mark_object_minor((void*)KEY_R);
    if (KEY_S != 0) ep_gc_mark_object_minor((void*)KEY_S);
    if (KEY_T != 0) ep_gc_mark_object_minor((void*)KEY_T);
    if (KEY_U != 0) ep_gc_mark_object_minor((void*)KEY_U);
    if (KEY_V != 0) ep_gc_mark_object_minor((void*)KEY_V);
    if (KEY_W != 0) ep_gc_mark_object_minor((void*)KEY_W);
    if (KEY_X != 0) ep_gc_mark_object_minor((void*)KEY_X);
    if (KEY_Y != 0) ep_gc_mark_object_minor((void*)KEY_Y);
    if (KEY_Z != 0) ep_gc_mark_object_minor((void*)KEY_Z);
    if (KEY_ZERO != 0) ep_gc_mark_object_minor((void*)KEY_ZERO);
    if (KEY_ONE != 0) ep_gc_mark_object_minor((void*)KEY_ONE);
    if (KEY_TWO != 0) ep_gc_mark_object_minor((void*)KEY_TWO);
    if (KEY_THREE != 0) ep_gc_mark_object_minor((void*)KEY_THREE);
    if (KEY_FOUR != 0) ep_gc_mark_object_minor((void*)KEY_FOUR);
    if (KEY_FIVE != 0) ep_gc_mark_object_minor((void*)KEY_FIVE);
    if (KEY_SIX != 0) ep_gc_mark_object_minor((void*)KEY_SIX);
    if (KEY_SEVEN != 0) ep_gc_mark_object_minor((void*)KEY_SEVEN);
    if (KEY_EIGHT != 0) ep_gc_mark_object_minor((void*)KEY_EIGHT);
    if (KEY_NINE != 0) ep_gc_mark_object_minor((void*)KEY_NINE);
    if (MOUSE_LEFT != 0) ep_gc_mark_object_minor((void*)MOUSE_LEFT);
    if (MOUSE_RIGHT != 0) ep_gc_mark_object_minor((void*)MOUSE_RIGHT);
    if (MOUSE_MIDDLE != 0) ep_gc_mark_object_minor((void*)MOUSE_MIDDLE);
    if (FLAG_VSYNC_HINT != 0) ep_gc_mark_object_minor((void*)FLAG_VSYNC_HINT);
    if (FLAG_FULLSCREEN_MODE != 0) ep_gc_mark_object_minor((void*)FLAG_FULLSCREEN_MODE);
    if (FLAG_WINDOW_RESIZABLE != 0) ep_gc_mark_object_minor((void*)FLAG_WINDOW_RESIZABLE);
    if (FLAG_WINDOW_UNDECORATED != 0) ep_gc_mark_object_minor((void*)FLAG_WINDOW_UNDECORATED);
    if (FLAG_WINDOW_TRANSPARENT != 0) ep_gc_mark_object_minor((void*)FLAG_WINDOW_TRANSPARENT);
    if (FLAG_MSAA_4X_HINT != 0) ep_gc_mark_object_minor((void*)FLAG_MSAA_4X_HINT);
    if (FLAG_WINDOW_ALWAYS_RUN != 0) ep_gc_mark_object_minor((void*)FLAG_WINDOW_ALWAYS_RUN);
    if (LOG_NONE != 0) ep_gc_mark_object_minor((void*)LOG_NONE);
    if (LOG_ERROR != 0) ep_gc_mark_object_minor((void*)LOG_ERROR);
    if (LOG_WARNING != 0) ep_gc_mark_object_minor((void*)LOG_WARNING);
    if (LOG_INFO != 0) ep_gc_mark_object_minor((void*)LOG_INFO);
    if (LOG_DEBUG != 0) ep_gc_mark_object_minor((void*)LOG_DEBUG);
    if (LOG_TRACE != 0) ep_gc_mark_object_minor((void*)LOG_TRACE);
    if (CHAT_WHEEL_CIF != 0) ep_gc_mark_object_minor((void*)CHAT_WHEEL_CIF);
    if (CHAT_WHEEL_RESULT != 0) ep_gc_mark_object_minor((void*)CHAT_WHEEL_RESULT);
    if (PROGRESS_TURN != 0) ep_gc_mark_object_minor((void*)PROGRESS_TURN);
    if (PROGRESS_ROUND != 0) ep_gc_mark_object_minor((void*)PROGRESS_ROUND);
    if (PROGRESS_EPOCH != 0) ep_gc_mark_object_minor((void*)PROGRESS_EPOCH);
    if (PROGRESS_LAST != 0) ep_gc_mark_object_minor((void*)PROGRESS_LAST);
    if (SOURCES_OPEN != 0) ep_gc_mark_object_minor((void*)SOURCES_OPEN);
    if (SOURCE_CHILD != 0) ep_gc_mark_object_minor((void*)SOURCE_CHILD);
    if (SOURCE_NOTICE != 0) ep_gc_mark_object_minor((void*)SOURCE_NOTICE);
    if (EDIT_TEXT != 0) ep_gc_mark_object_minor((void*)EDIT_TEXT);
    if (EDIT_CARET != 0) ep_gc_mark_object_minor((void*)EDIT_CARET);
    if (EDIT_ANCHOR != 0) ep_gc_mark_object_minor((void*)EDIT_ANCHOR);
    if (EDIT_FOCUS != 0) ep_gc_mark_object_minor((void*)EDIT_FOCUS);
    if (EDIT_DRAG != 0) ep_gc_mark_object_minor((void*)EDIT_DRAG);
    if (EDIT_SCROLL != 0) ep_gc_mark_object_minor((void*)EDIT_SCROLL);
    if (EDIT_BLINK != 0) ep_gc_mark_object_minor((void*)EDIT_BLINK);
    if (EDIT_ERROR != 0) ep_gc_mark_object_minor((void*)EDIT_ERROR);
    if (EDIT_CLICK_TIME != 0) ep_gc_mark_object_minor((void*)EDIT_CLICK_TIME);
    if (EDIT_CLICK_POS != 0) ep_gc_mark_object_minor((void*)EDIT_CLICK_POS);
    if (SELECT_CLICK_TIME != 0) ep_gc_mark_object_minor((void*)SELECT_CLICK_TIME);
    if (SELECT_CLICK_POS != 0) ep_gc_mark_object_minor((void*)SELECT_CLICK_POS);
    if (EDIT_UNDO != 0) ep_gc_mark_object_minor((void*)EDIT_UNDO);
    if (EDIT_REDO != 0) ep_gc_mark_object_minor((void*)EDIT_REDO);
    if (SELECT_TOP != 0) ep_gc_mark_object_minor((void*)SELECT_TOP);
    if (SELECT_BOTTOM != 0) ep_gc_mark_object_minor((void*)SELECT_BOTTOM);
    if (SELECT_TEXT != 0) ep_gc_mark_object_minor((void*)SELECT_TEXT);
    if (SELECT_CARET != 0) ep_gc_mark_object_minor((void*)SELECT_CARET);
    if (SELECT_ANCHOR != 0) ep_gc_mark_object_minor((void*)SELECT_ANCHOR);
    if (SELECT_DRAG != 0) ep_gc_mark_object_minor((void*)SELECT_DRAG);
    if (EDIT_MENU != 0) ep_gc_mark_object_minor((void*)EDIT_MENU);
    if (EDIT_MENU_X != 0) ep_gc_mark_object_minor((void*)EDIT_MENU_X);
    if (EDIT_MENU_Y != 0) ep_gc_mark_object_minor((void*)EDIT_MENU_Y);
    if (EDIT_MENU_USED != 0) ep_gc_mark_object_minor((void*)EDIT_MENU_USED);
    if (PDF_OBJC != 0) ep_gc_mark_object_minor((void*)PDF_OBJC);
    if (STATE_LEASE_FD != 0) ep_gc_mark_object_minor((void*)STATE_LEASE_FD);
    if (WORKER_LEASE_FD != 0) ep_gc_mark_object_minor((void*)WORKER_LEASE_FD);
}

void __ep_init_constants(void) {
    ep_gc_mark_globals_major = __ep_mark_globals_major;
    ep_gc_mark_globals_minor = __ep_mark_globals_minor;
    UI_POINTER_PRESSED = 0;
    UI_TOUCH_START_X = 0;
    UI_TOUCH_START_Y = 0;
    UI_TOUCH_LAST_Y = 0;
    UI_TOUCH_MOVED = 0;
    UI_TOUCH_DELTA = 0;
    UI_TOUCH_STARTED = 0;
    UI_SCALE = 1;
    UI_TOP = 0;
    UI_BOTTOM = 0;
    UI_TRANSFORM_CIF = 0;
    ANDROID_SDL = 0;
    ANDROID_INPUT_MUTEX = 0;
    ANDROID_INPUT_BUFFER = 0;
    ANDROID_INPUT_USED = 0;
    ANDROID_INPUT_OVERFLOW = 0;
    ANDROID_INPUT_WATCH = 0;
    ANDROID_INPUT_WINDOW = 0;
    ANDROID_INPUT_LOCK = 0;
    ANDROID_INPUT_UNLOCK = 0;
    ANDROID_INPUT_COPY = 0;
    ANDROID_INPUT_LENGTH = 0;
    ANDROID_POINTER_PENDING = 0;
    NATIVE_SYSTEM = 0;
    NATIVE_ANDROID = 0;
    NATIVE_VARIADIC_FFI = 0;
    ANDROID_JNI_ENV = 0;
    ANDROID_JNI_TABLE = 0;
    FONT_FFI = 0;
    FONT_CALL = 0;
    FONT_DRAW_CIF = 0;
    FONT_MEASURE_CIF = 0;
    FONT_VALUE = 0;
    FONT_TEXT = 0;
    FONT_POSITION = 0;
    FONT_SIZE = 0;
    FONT_SPACE = 0;
    FONT_COLOR = 0;
    FONT_DRAW_ARGS = 0;
    FONT_MEASURE_ARGS = 0;
    FONT_DRAW = 0;
    FONT_MEASURE = 0;
    FONT_RESULT = 0;
    RAYLIB_HANDLE = 0;
    RAYLIB_WHITE = 4294967295;
    RAYLIB_BLACK = 255;
    RAYLIB_RED = 4278190335;
    RAYLIB_GREEN = 4278255360;
    RAYLIB_BLUE = 4294901760;
    RAYLIB_YELLOW = 4278255615;
    RAYLIB_ORANGE = 4278233343;
    RAYLIB_PURPLE = 4286578943;
    RAYLIB_PINK = 4290825215;
    RAYLIB_LIGHTGRAY = 4291348680;
    RAYLIB_DARKGRAY = 4283716692;
    RAYLIB_GRAY = 4286611584;
    RAYLIB_MAROON = 4278190208;
    RAYLIB_LIME = 4278255104;
    RAYLIB_DARKBLUE = 4289069056;
    RAYLIB_DARKGREEN = 4278222848;
    RAYLIB_DARKPURPLE = 4285595648;
    RAYLIB_BEIGE = 4292854067;
    RAYLIB_MAGENTA = 4294902015;
    RAYLIB_SKYBLUE = 4294945254;
    RAYLIB_GOLD = 4278236159;
    RAYLIB_BROWN = 4281543807;
    RAYLIB_DARKBROWN = 4279638016;
    RAYLIB_VIOLET = 4294887783;
    RAYLIB_RAYWHITE = 4294572537;
    RAYLIB_BLANK = 0;
    KEY_SPACE = 32;
    KEY_ESCAPE = 256;
    KEY_ENTER = 257;
    KEY_TAB = 258;
    KEY_BACKSPACE = 259;
    KEY_DELETE = 261;
    KEY_RIGHT = 262;
    KEY_LEFT = 263;
    KEY_DOWN = 264;
    KEY_UP = 265;
    KEY_PAGE_UP = 266;
    KEY_PAGE_DOWN = 267;
    KEY_HOME = 268;
    KEY_END = 269;
    KEY_F1 = 290;
    KEY_F2 = 291;
    KEY_F3 = 292;
    KEY_F4 = 293;
    KEY_F5 = 294;
    KEY_F6 = 295;
    KEY_F7 = 296;
    KEY_F8 = 297;
    KEY_F9 = 298;
    KEY_F10 = 299;
    KEY_F11 = 300;
    KEY_F12 = 301;
    KEY_LEFT_SHIFT = 340;
    KEY_LEFT_CONTROL = 341;
    KEY_LEFT_ALT = 342;
    KEY_RIGHT_SHIFT = 344;
    KEY_RIGHT_CONTROL = 345;
    KEY_RIGHT_ALT = 346;
    KEY_A = 65;
    KEY_B = 66;
    KEY_C = 67;
    KEY_D = 68;
    KEY_E = 69;
    KEY_F = 70;
    KEY_G = 71;
    KEY_H = 72;
    KEY_I = 73;
    KEY_J = 74;
    KEY_K = 75;
    KEY_L = 76;
    KEY_M = 77;
    KEY_N = 78;
    KEY_O = 79;
    KEY_P = 80;
    KEY_Q = 81;
    KEY_R = 82;
    KEY_S = 83;
    KEY_T = 84;
    KEY_U = 85;
    KEY_V = 86;
    KEY_W = 87;
    KEY_X = 88;
    KEY_Y = 89;
    KEY_Z = 90;
    KEY_ZERO = 48;
    KEY_ONE = 49;
    KEY_TWO = 50;
    KEY_THREE = 51;
    KEY_FOUR = 52;
    KEY_FIVE = 53;
    KEY_SIX = 54;
    KEY_SEVEN = 55;
    KEY_EIGHT = 56;
    KEY_NINE = 57;
    MOUSE_LEFT = 0;
    MOUSE_RIGHT = 1;
    MOUSE_MIDDLE = 2;
    FLAG_VSYNC_HINT = 64;
    FLAG_FULLSCREEN_MODE = 2;
    FLAG_WINDOW_RESIZABLE = 4;
    FLAG_WINDOW_UNDECORATED = 8;
    FLAG_WINDOW_TRANSPARENT = 16;
    FLAG_MSAA_4X_HINT = 32;
    FLAG_WINDOW_ALWAYS_RUN = 256;
    LOG_NONE = 7;
    LOG_ERROR = 5;
    LOG_WARNING = 4;
    LOG_INFO = 3;
    LOG_DEBUG = 2;
    LOG_TRACE = 1;
    CHAT_WHEEL_CIF = 0;
    CHAT_WHEEL_RESULT = 0;
    PROGRESS_TURN = (long long)"";
    PROGRESS_ROUND = (long long)"";
    PROGRESS_EPOCH = (long long)"";
    PROGRESS_LAST = 0;
    SOURCES_OPEN = (long long)"";
    SOURCE_CHILD = 0;
    SOURCE_NOTICE = (long long)"";
    EDIT_TEXT = (long long)"";
    EDIT_CARET = 0;
    EDIT_ANCHOR = 0;
    EDIT_FOCUS = 1;
    EDIT_DRAG = 0;
    EDIT_SCROLL = 0;
    EDIT_BLINK = 0;
    EDIT_ERROR = (long long)"";
    EDIT_CLICK_TIME = 0;
    EDIT_CLICK_POS = 0;
    SELECT_CLICK_TIME = 0;
    SELECT_CLICK_POS = 0;
    EDIT_UNDO = create_list();
    EDIT_REDO = create_list();
    SELECT_TOP = 110;
    SELECT_BOTTOM = 600;
    SELECT_TEXT = (long long)"";
    SELECT_CARET = 0;
    SELECT_ANCHOR = 0;
    SELECT_DRAG = 0;
    EDIT_MENU = 0;
    EDIT_MENU_X = 0;
    EDIT_MENU_Y = 0;
    EDIT_MENU_USED = 0;
    PDF_OBJC = 0;
    STATE_LEASE_FD = (0 - 1);
    WORKER_LEASE_FD = (0 - 1);
}

/* Bootstrapper C main */
int main(int argc, char** argv) {
    {
        unsigned int seed;
        FILE* urand = fopen("/dev/urandom", "rb");
        if (urand && fread(&seed, sizeof(seed), 1, urand) == 1) {
            fclose(urand);
        } else {
            if (urand) fclose(urand);
            seed = (unsigned int)time(NULL) ^ (unsigned int)getpid();
        }
        srand(seed);
    }
    init_ep_args(argc, argv);
    __ep_init_constants();
    int result = (int)_main();
    ep_async_loop_run();
    ep_gc_shutdown();
    return result;
}
